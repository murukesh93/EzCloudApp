
/**
* @swagger 

* /dashboard/getDashboard:
 *   get:
 *     tags:
 *       - dashboard
 *     name: dashboard
 *     summary: Get dashboard details
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: senderEmail
 *         type: string
 *       - in: query
 *         name: year
 *         type: string
 *       - in: query
 *         name: userId
 *         type: integer 
 * 
 * 
 *     responses:
 *       200:
 *        description: Return dashboard object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 
 */

 // Import Node modules
 var express = require('express');
 const router = express.Router();
 var jwtAuth=require('../dao/jwt');
 const objDashboard=require('../dao/dashboard');

router.get('/getDashboard',jwtAuth.VerifyToken, function(req, res,next) {
    try {    // validate input fields data
      if(req.query.teamId=='' || req.query.teamId==undefined  ){
        req.query.teamId =0;
      }    
     if(req.query.senderEmail=='' || req.query.senderEmail==undefined  ){
         req.query.senderEmail ="";
        } 
        if(req.query.userId=='' || req.query.userId==undefined  ){
          req.query.userId =0;
        }  
    
        var obj = objDashboard.getDashboard(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result); //Method call Success
          }
        },
        function (err) { //promise  call error 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse); //Exception error
    } 
  }); 

  module.exports = router;