if (!err) {
    var jsonResponse = {};

    jsonResponse = {
      status: 'Success',
      data: rows[0],
    };
}