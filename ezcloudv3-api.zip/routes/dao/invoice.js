const pool=require('../dao/connectionPool'); 
const oic = require('./oic');
const objOIC=require('./oic');
objCommon=require('../dao/common');
const logger=require('../dao/logger');
var invoice = {
  
deleteInvoice: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spDeleteInvoice(?)";  
     var param = [req.query.invoiceId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                 
                    jsonResponse ={
                        status: 'Success', 
                        data: "Record deleted successfully"
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

getInvoiceById: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spGetInvoiceDetailById(?,?)";  
     var param = [req.query.invoiceId,req.query.userId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if(rows[0].length >0 && rows[0][0].message=="Success" ){
               rows[0][0].invoiceLine=JSON.parse(rows[0][0].invoiceLine); 
               jsonResponse ={
                status: 'Success', 
                data: rows[0]
                }
             }  else{
              var jsonResponse ={
                message: rows[0][0].message,
                status: 'Error'
            };
          
             }   
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

updateInvoiceStatus: async function(req,res,next){ 
        try{   

 
  return new Promise(function(resolve, reject) {    
    logger.info("Method Name: updateInvoiceStatus, Input Data: "+JSON.stringify(req.body));

    var query = "CALL spUpdateInvoiceStatus(?,?,?)";  
     var param = [req.body.invoiceId,req.body.userId,req.body.status];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if (rows[0][0].message=="Success" )
                {
                    jsonResponse ={
                        status: 'Success',
                        message: 'Status updated successfully'
                    }; 
                    logger.info("Method Name: updateInvoiceStatus, Message: Status updated successfully");

                }
                else{
                    jsonResponse ={
                        status: 'Error',
                        message: rows[0][0].message
                    }; 
                }
               
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                 logger.error("Method Name: updateInvoiceStatus, Error: "+err.message);

                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: updateInvoiceStatus, Error: "+ex.message);

         var result = { status: 'Error', message: ex.message }; 
         return  (result);  
        }
      }, 

     
getInvoice: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   
     var query = "CALL spGetInvoice(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
     var param = [req.query.teamId,req.query.approvalAmountFrom,req.query.approvalAmountTo,
      req.query.count,req.query.offset,req.query.status,req.query.companyName,req.query.invoiceNumber,
    req.query.totalAmount,req.query.receiverEmail,req.query.senderEmail,req.query.dueAmount,req.query.supplierCompanyName,
  req.query.name,req.query.invoiceAmount,req.query.supplierEmail];
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                for(i=0; i<rows[0].length;i++){
                  rows[0][i].invoiceLine=JSON.parse(rows[0][i].invoiceLine);
                 }
                    jsonResponse ={
                        status: 'Success', 
                        data: rows[0],
                        count: rows[1][0].totalCount
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
              logger.error("Method Name: getInvoice, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: getInvoice, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },
     
getNextInvoice: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   
     var query = "CALL spGetNextInvoice(?,?,?,?,?)";  
     var param = [req.query.teamId,req.query.approvalAmountFrom,req.query.approvalAmountTo,
     req.query.currentInvoiceId,req.query.senderEmail];
     
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
        if (!err) {
          var jsonResponse ={};
          var data=[];
          if(rows[0].length >0){
         rows[0][0].invoiceLine=JSON.parse(rows[0][0].invoiceLine);
         data=rows[0];
          }
          else if(rows[1].length >0){
            rows[1][0].invoiceLine=JSON.parse(rows[1][0].invoiceLine);
            data=rows[1];
             }
              jsonResponse ={
                  status: 'Success', 
                  data: data
              } 
           connection.release();
           return resolve(jsonResponse); 
       }
             else { 
              logger.error("Method Name: getNextInvoice, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: getNextInvoice, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },

createInvoice: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
    
     var query = "CALL spcreateinvoicedetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
     var param = [req.body.invoiceNumber,req.body.senderEmail,req.body.dueDate,
       req.body.dueAmount,req.body.textractJson,req.body.textTractStatus,req.body.filePath,
       req.body.orderNumber,req.body.success,req.body.textractFailed,req.body.manualExtractFaile,
       req.body.status,req.body.invoiceType,req.body.name,req.body.phoneNumber,req.body.createdBy,
       req.body.invoiceDate,req.body.supplierSite,req.body.taxNumber,req.body.bankAccount,req.body.sortCode,
       req.body.swift,req.body.iban,req.body.supplierAddress,req.body.invoiceCurrency,req.body.invoiceAmount,
       req.body.paidAmount,req.body.taxTotal,req.body.invoiceDescription,req.body.receiverEmail];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={
                     message: 'Success',
                     status: 'Record saved successfully',
                     invoiceId: rows[0][0].invoiceId
                 };
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

updateInvoice: async function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
  logger.info("Method Name: updateInvoice, Input Data: "+JSON.stringify(req.body));

     var query = "CALL spupdateinvoicedetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
     var param = [req.body.invoiceId,req.body.invoiceNumber,req.body.senderEmail,req.body.dueDate,
       req.body.dueAmount,req.body.textractJson,req.body.textTractStatus,req.body.filePath,
       req.body.orderNumber,req.body.success,req.body.textractFailed,req.body.manualExtractFaile,
       req.body.status,req.body.invoiceType,req.body.name,req.body.phoneNumber, req.body.invoiceDate,req.body.supplierSite,req.body.taxNumber,req.body.bankAccount,req.body.sortCode,
       req.body.swift,req.body.iban,req.body.supplierAddress,req.body.invoiceCurrency,req.body.invoiceAmount,
       req.body.paidAmount,req.body.taxTotal,req.body.invoiceDescription,req.body.receiverEmail,req.body.totalAmount,
      req.body.documentType,req.body.updateBy];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, async function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={
                     status: 'Success',
                     message: 'Record saved successfully'
                 };
                 logger.info("Method Name: updateInvoice, Message: Record updated successfully");

                     // validation service
               if((req.body.invoiceNumber !="" && req.body.invoiceNumber !=undefined ) ||
               (req.body.orderNumber !="" && req.body.orderNumber !=undefined )  ){
                var invoiceArr=[];
                invoiceArr.push({"invoiceNumber": req.body.invoiceNumber,"orderNumber":req.body.orderNumber,"name":req.body.name});
              req.body.invoiceData={data:invoiceArr };
                var validationobj=  await oic.validationsInvoice(req,res);              
              } 

              // Lookup service
              if((req.body.name !="" && req.body.name !=undefined ) ||
              (req.body.orderNumber !="" && req.body.orderNumber !=undefined )  ){
               var invoiceArr=[];
               invoiceArr.push({"supplier": req.body.name,"PO number":req.body.orderNumber});
             req.body.lookupData={data:invoiceArr };
               var lookupobj= await oic.lookupService(req,res);              
             } 


                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                
                 logger.error("Method Name: updateInvoice, Error: "+err.message);

                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: updateInvoice, Error: "+ex.message); 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 
      
getInvoiceList: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   
     var query = "SELECT * FROM vwgetinvoicedetails where invoiceId IN(2910,2909,2908,2907,2906)";  
     var param = [];
     
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                for(i=0; i<rows.length;i++){
                  rows[i].invoiceLine=JSON.parse(rows[i].invoiceLine);
                 }
                    jsonResponse ={
                        status: 'Success', 
                        data: rows 
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },

 saveInvoiceLine: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
  logger.info("Method Name: saveInvoiceLine, Input Data: "+JSON.stringify(req.body));

     var query = "CALL saveinvoiceline(?,?,?,?,?,?,?)";  
     var param = [req.body.invoiceLineId,req.body.invoiceId,req.body.operatingUnit,
       req.body.invoiceLineNumber,req.body.invoiceLineType,
       req.body.invoiceLineAmount, req.body.action];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={
                     message: 'Success',
                     status: 'Record saved successfully',
                     invoiceLineId: rows[0][0].invoiceLineId
                 };
                 logger.info("Method Name: saveInvoiceLine, Message: Record saved successfully");
  
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                 logger.error("Method Name: saveInvoiceLine, Error: "+err.message);
  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: saveInvoiceLine, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

getInvoiceLine: function(req,res,next){ 
  try{   
return new Promise(function(resolve, reject) {   
var query = "CALL spselectinvoiceline(?,?)";  
var param = [req.query.invoiceId,req.query.invoiceLineId];

pool.getConnection(function (err, connection) {
 connection.query(query, param, function (err, rows, fields) {
       if (!err) {
          var jsonResponse ={};
          
              jsonResponse ={
                  status: 'Success', 
                  data: rows[0] 
              } 
           connection.release();
           return resolve(jsonResponse); 
       }
       else { 
         var jsonResponse ={
               message: err.message,
               status: 'Error'
           };
            
           connection.release();
           return reject(jsonResponse);
       }
          
   });
   
});

      }) ; 
}
  catch(ex){ 
   var result = { status: 'Error', message: ex.message }; 
   return  reject(result);  
  }
},

deleteInvoiceLine: function(req,res,next){ 
  try{   

return new Promise(function(resolve, reject) {   

var query = "CALL spdeleteinvoiceline(?)";  
var param = [req.query.invoiceLineId];
 
pool.getConnection(function (err, connection) {
 connection.query(query, param, function (err, rows, fields) {
       if (!err) {
          var jsonResponse ={}; 
          if (rows[0][0].message=="Success" )
          {
              jsonResponse ={
                  status: 'Success',
                  message: 'Record deleted successfully'
              }; 
          }
          else{
              jsonResponse ={
                  status: 'Error',
                  message: "Error in delete invoice line"
              }; 
          }
           connection.release();
           return resolve(jsonResponse);
                
       }
       else { 
         var jsonResponse ={
               message: err.message,
               status: 'Error'
           };
            
           connection.release();
           return reject(jsonResponse);
       }
          
   });
   
});

      }) ; 
}
  catch(ex){ 
   var result = { status: 'Error', message: ex.message }; 
   return  reject(result);  
  }
}, 

lockInvoice: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {  
  logger.info("Method Name: lockInvoice, Input Data: "+JSON.stringify(req.body));
     var query = "CALL splockinvoice(?,?)";  
     var param = [req.body.invoiceId,req.body.lockedBy];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                 
                    jsonResponse ={
                        status: 'Success',
                        data:rows[0][0]
                    };  
                    logger.info("Method Name: lockInvoice, Response Data: "+JSON.stringify(rows[0][0]));
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                 logger.error("Method Name: lockInvoice, Error: "+err.message);
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: lockInvoice, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 
      
unLockInvoice: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
  
     var query = "CALL spunlockinvoice(?,?)";  
     var param = [req.query.invoiceId,req.query.lockedBy];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
               
              if (rows[0][0].message == 'Success') {
                var jsonResponse ={
                     message: 'Success',
                     status: 'Invoice unlocked successfully'
                     
                 };
                 logger.info("Method Name: unLockInvoice, Message: Invoice unlocked successfully");
                }
                else{
                  var jsonResponse ={
                    message: 'Error',
                    status: rows[0][0].message
                    
                };
                }
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
              logger.error("Method Name: unLockInvoice, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: unLockInvoice, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },

getInvoiceFieldList: function(req,res,next){ 

  try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spgetinvoicefieldlist(?)";  
     var param = [req.query.teamId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                 
                    jsonResponse ={
                        status: 'Success', 
                        data: rows[0]
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

 }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

saveInvoiceFieldList: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
    
     var query = "CALL spsaveinvoicemandatoryfields(?,?)";   
     var param = [JSON.stringify(req.body.fieldList),req.body.teamId];
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={
                     message: 'Record saved successfully',
                     status: 'Success' 
                 };
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 


 getInvoiceByIdApproval: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spGetInvoiceDetailByIdApproval(?)";  
     var param = [req.query.invoiceId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if(rows[0].length >0 ){
               rows[0][0].invoiceLine=JSON.parse(rows[0][0].invoiceLine); 
               jsonResponse ={
                status: 'Success', 
                data: rows[0]
                }
             }  else{
              var jsonResponse ={
                message: rows[0][0].message,
                status: 'Error'
            };
          
             }   
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },

getAudits: function(req,res,next){ 
        try{   
    return new Promise(function(resolve, reject) {   
    
     var query = "SELECT * FROM vwgetaudit WHERE invoiceId="+req.query.invoiceId;  
     var param = [];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
            var jsonResponse ={}; 
               jsonResponse ={
                status: 'Success', 
                data: rows 
             }   
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });
    
            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

saveSettings: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
    logger.info("Method Name: saveSettings, Input Data: "+JSON.stringify(req.body));
     var query = "CALL spsavesetting(?,?)";  
     var param = [req.body.teamId,req.body.dateFormat];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if (rows[0][0].message=="Success" )
                {
                    jsonResponse ={
                        status: 'Success',
                        message: 'Record saved successfully'
                    }; 
                    logger.info("Method Name: saveSettings, Message: Record saved successfully");
                }
                else{
                    jsonResponse ={
                        status: 'Error',
                        message:"Error in record save"
                    }; 
                }
               
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
                logger.error("Method Name: saveSettings, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
            
      logger.error("Method Name: saveSettings, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },


getSettings: function(req,res,next){ 
        try{   
      return new Promise(function(resolve, reject) {   
      
      var query=`SELECT * FROM tblsettings WHERE teamId=`+req.query.teamId+``; 
      var param = [];
      pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) { 
             if (!err) {
                var jsonResponse ={
                     message: 'Success',
                     data: rows[0] || []
                 };
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
      });
      
            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

};




module.exports=invoice;