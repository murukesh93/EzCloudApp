const pool = require('../dao/connectionPool');
const objCommon=require('../dao/common');
const objConfig=require('../appconfig/config');
const { config } = require('../dao/connectionPool');
const logger=require('../dao/logger');
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');
const { stubFalse } = require('lodash');

var user = {
  saveUser: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        logger.info("Method Name: saveUser, Input Data: "+JSON.stringify(req.body));
        var query = 'CALL spSaveUser(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
        var param = [
          req.body.userId,
          req.body.firstName,
          req.body.lastName,
          req.body.email,
          req.body.password,
          req.body.phoneNumber,
          req.body.approvalAmountFrom,
          req.body.approvalAmountTo,
          req.body.profileLogo,
          req.body.createdBy,
          req.body.userRole,
          req.body.action,
          req.body.invoiceSenderEmail,
          req.body.teamType,
          req.body.companyLogo,
          req.body.companyName,
          req.body.planId,
          req.body.isDefaultPassword,
          req.body.isEmailVerified,
          req.body.hashKey,
          req.body.countryCode,
          req.body.entityType,
          req.body.expiryDate
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {}; 
              if (rows[0][0].message == 'Success') {

                if( req.body.entityType=="Customer" &&  req.body.teamType=="Created By Admin" && req.body.action=="Add"){

                  // var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.email,'EZ Cloud Successful Registration',
                  //  `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
                  //  </br><div></br></br>`+ '<p> </br></br>Hi '+req.body.firstName+`, <br> <br>  Thank you for registering with EZ Cloud! Your account is now ready to use. <br> <br>
                  //  Please use the below credentials to access EZ Cloud: <br>Username: `
                  //  +req.body.email + '<br>Password: '+ req.body.originalPassword+`<br><br> Thanks<br>
                  //  EZ Cloud Team </p></div>`);

                  req.body.subject="EZ Cloud Successful Registration";
                  req.body.createdByName=rows[0][0].createdByName;
                   
                  createTeamMemberEmail(req,res);
      
                     }

            if( req.body.userRole=="Team Member" && req.body.action=="Add"){

            // var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.email,'Account successfully created',
            //  `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
            //  <div></br></br></br></br>`+ '<p></br></br>Hi '+req.body.firstName+`, <br> <br>  Thank you for registering with EZ Cloud! Your account is now ready to use. <br> <br>
            //  Please use the below credentials to access EZ Cloud: <br>Username: `
            //  +req.body.email + '<br>Password: '+ req.body.originalPassword+`<br><br> Thanks<br>
            //  EZ Cloud Team </p></div>`);

           req.body.subject="Your EZ Cloud Account Has Been Successfully Created";
            req.body.createdByName=rows[0][0].createdByName;
             
            createTeamMemberEmail(req,res);
               }

           if( (req.body.teamType=="Open Registration" && req.body.action=="Add") && (req.body.entityType=="Customer" || req.body.entityType=="Supplier")){
             var url=objConfig.adminUrl+"/verifyemail?email="+req.body.email+"&hashKey="+req.body.hashKey
             req.body.subject='Confirm Your Account – EZ Cloud';
             req.body.url=url; 
             accountConfirmationEmail(req,res);

             // var href='<a href='+url+'>click here</a>';
              //   var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.email,'EZ Cloud–Confirm Your Account',
              //   `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
              //   <div></br></br>`+ 
              //   '<br>Hi '+req.body.firstName+`,  <br><br>Thanks for signing up with EZ Cloud. To verify your email address, please `+href+`
              //    `
              //   +`<br><br> Thanks<br> EZ Cloud Team </div>`);
    
                   }
                logger.info("Method Name: saveUser, Message: User saved successfully");
                jsonResponse = {
                  status: 'Success',
                  message: 'User saved successfully',
                };
              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              }

              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: saveUser, Error: "+err.message);

              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: saveUser, Error: "+ex.message);

      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  login: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spLogin(?,?)';
        var param = [req.body.email, req.body.password];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) { 
              var jsonResponse = {};
              if (rows[0].length > 0) {
                if (rows[0][0].message == 'Success') { 
                  if(rows[0][0].message == 'Success' && rows[0][0].isEmailVerified ==true && rows[0][0].planExpired ==0
                  &&  rows[0][0].isActive == 1  ){
                    jsonResponse = {
                      status: 'Success',
                      data: rows[0][0],
                      invoiceCount:rows[1][0].invoiceCount,
                      accountExist: rows[2][0].accountExist
                    };
                  }
                  else if(rows[0][0].message == 'Success' &&  rows[0][0].isActive == false){ 
                    jsonResponse = {
                      status: 'Error',
                      message: "Your account has been deactivated. Please contact your EZ Cloud administrator.",
                      accountExist: rows[2][0].accountExist
                    };
                  }
                  else if(rows[0][0].message == 'Success' && rows[0][0].isEmailVerified ==false){
                    jsonResponse = {
                      status: 'Error',
                      message: "You must activate your account at the email address provided in order to log in.",
                       accountExist: rows[2][0].accountExist
                    };
                  }
                  else if(rows[0][0].message == 'Success' && rows[0][0].planExpired ==1){
                    jsonResponse = {
                      status: 'Error',
                      message: "Your subscription has expired.Please contact EZ Cloud Team",
                       accountExist: rows[2][0].accountExist
                    };
                  }
                  
                } else {
                  jsonResponse = {
                    status: 'Error',
                    message: 'Incorrect Username or Password',
                    accountExist: rows[2][0].accountExist
                  };
                }
              } else {
                jsonResponse = {
                  status: 'Error',
                  message: 'Incorrect Username or Password',
                  accountExist: rows[2][0].accountExist
                };
              }
              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: login, Error: "+err.message);
    
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: login, Error: "+ex.message);
    
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },
  getUserById: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spGetUserById(?)';
        var param = [req.query.userId];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};

              jsonResponse = {
                status: 'Success',
                data: rows[0],
              };
              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  getUser: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spGetUser(?,?,?,?,?,?,?,?,?)';
        var param = [req.query.teamId,req.query.count,req.query.offset,req.query.email,
          req.query.companyName,req.query.firstName,req.query.lastName,req.query.userRole,req.query.isActive];
        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};

              jsonResponse = {
                status: 'Success',
                data: rows[0],
                count: rows[1][0].totalCount
              };
              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  deleteUser: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spDeleteUser(?,?)';
        var param = [req.query.userId,req.query.isActive];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};
            var action=(req.query.isActive==1) ? 'reactivated ' : 'deactivated';
              jsonResponse = {
                status: 'Success',
                message: 'User '+action+' successfully',
              };  
              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },
  updatePassword: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spUpdatePassword(?,?,?)';
        var param = [
          req.body.email,
          req.body.oldPassword,
          req.body.newPassword,
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                jsonResponse = {
                  status: 'Success',
                  message: 'Password updated successfully',
                };

                req.body.firstName=rows[0][0].firstName;
                req.body.subject='Password Updated – EZ Cloud';
                updatePasswordEmail(req,res);
              //   var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.email,'Update Password',
              //   `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
              // <div></br></br>`+'<p></br> Hi,<br/><br/> Your password has been successfully updated in EZ Cloud application.New password is: '+req.body.newOriginalPassword
              // +`<br><br> Thanks<br> EZ Cloud Team </p></div>`);

              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              }

              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: updatePassword, Error: "+err.message); 
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: updatePassword, Error: "+ex.message); 
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  forGetPassword:  function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) { 
        var query = 'CALL spForGetPassword(?,?)';
        var param = [
          req.body.email,
          req.body.password 
        ]; 
        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) { 
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                req.body.firstName=rows[0][0].firstName;
                req.body.subject='Password Reset – EZ Cloud';
              forgotPasswordEmail(req,res); 
            //    var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.email,'Forgot Password',
            //    `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
            //  <div></br></br>`+'<p><br/> Hi, <br/><br/>Your password has been successfully reset in EZ Cloud application.New password is: '+req.body.newPassword
            //  +`<br><br> Thanks<br> EZ Cloud Team</p> </div>`);

            //   obj.then(
            //     function (objResult) {
            //       if (objResult.status === 'Error') {
            //         return reject(objResult);
            //       }
            //       else { 
            //         return resolve(objResult);
            //       }
            //     },
            //     function (err) {
            //       logger.error("Method Name: forGetPassword, Error: "+err.message); 
            //       var result = { status: 'Error', message: err.message };
            //       return reject(result);
            //     }
            //   );

              var result = { status: 'Success', message: 'Email sent successfully' };
              return resolve(result);
              } else { 
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              } 
              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: forGetPassword, Error: "+err.message); 
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: forGetPassword, Error: "+ex.message); 
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  verifyCustomerEmail: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spverifycustomeremail(?,?)';
        var param = [
          req.body.email,
          req.body.hashKey
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                jsonResponse = {
                  status: 'Success',
                  message: 'Email activated successfully',
                };
              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              }

              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: verifyCustomerEmail, Error: "+err.message); 
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: verifyCustomerEmail, Error: "+ex.message); 
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  verifyOTP: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        logger.info("Method Name: verifyOTP, Input Data: "+JSON.stringify(req.body));
        var query = 'CALL spverifyotp(?,?,?,?)';
        var param = [
          req.body.otpType,
          req.body.otpValue,
          req.body.otpTo,
          req.body.countryCode
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                jsonResponse = {
                  status: 'Success',
                  message: 'OTP verified successfully',
                };
              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              }

              connection.release();
              return resolve(jsonResponse);
            } else {
              logger.error("Method Name: verifyOTP, Error: "+err.message);
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: verifyOTP, Error: "+ex.message);
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },


generateOTP:  function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        logger.info("Method Name: generateOTP, Input Data: "+JSON.stringify(req.body));
        var query = 'CALL spsaveotp(?,?,?,?)';
        var param = [
          req.body.otpType,
          req.body.otpValue,
          req.body.otpTo,
          req.body.countryCode
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              connection.release();

              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                var smsBody=req.body.otpValue+ ` is your one time password for EZ Cloud application.`;
                var obj= objCommon.sendSMS( objConfig.fromMobileNumber,req.body.countryCode+ req.body.otpTo,smsBody);
                 
                obj.then(
                  function (objResult) {
                    if (objResult.status === 'Error') {
                      return reject(objResult);
                    }
                    else { 
                    logger.info("Method Name: generateOTP, Message: OTP sent successfully");
                      return resolve(objResult);
                    }
                  },
                  function (err) {
                    logger.error("Method Name: generateOTP, Error: "+err.message);
                    var result = { status: 'Error', message: err.message };
                    return reject(result);
                  }
                );

              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
                return reject(jsonResponse);
              }

            } else {
              logger.error("Method Name: generateOTP, Error: "+err.message);
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: generateOTP, Error: "+ex.message);
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

forGetPasswordForPhone:  function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) { 
        logger.info("Method Name: forGetPasswordForPhone, Input Data: "+JSON.stringify(req.body));
        var query = 'CALL spforgetpasswordforphone(?,?,?)';
        var param = [
          req.body.phoneNumber,
          req.body.countryCode,
          req.body.password 
        ]; 
        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) { 
              connection.release();
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {

                var smsBody=  'Hi, Your password has been successfully reset in EZ Cloud application.New password is: '+req.body.newPassword;
                var obj = objCommon.sendSMS( objConfig.fromMobileNumber,req.body.countryCode+ req.body.phoneNumber,smsBody);
   
                obj.then(
                  function (objResult) {
                    if (objResult.status === 'Error') {
                      return reject(objResult);
                    }
                    else { 
                      logger.info("Method Name: forGetPasswordForPhone, Message: Password sent successfully");
                      return resolve(objResult);
                    }
                  },
                  function (err) {
                    logger.error("Method Name: forGetPasswordForPhone, Error: "+err.message);

                    var result = { status: 'Error', message: err.message };
                    return reject(result);
                  }
                );

              } else { 
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
                return reject(jsonResponse);
              } 
              
            } else {
              logger.error("Method Name: forGetPasswordForPhone, Error: "+err.message);
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      logger.error("Method Name: forGetPasswordForPhone, Error: "+ex.message);
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  signOut: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spSignOut(?)';
        var param = [
          req.body.userId 
        ];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};
              if (rows[0][0].message == 'Success') {
                jsonResponse = {
                  status: 'Success',
                  message: 'Logout account successfully',
                };
              } else {
                jsonResponse = {
                  status: 'Error',
                  message: rows[0][0].message,
                };
              }

              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },
  
  getEntityUser: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'CALL spGetEntityUser(?,?,?,?,?)';
        var param = [req.query.entityType,req.query.email,req.query.count,req.query.offset,
          req.query.teamId];

        pool.getConnection(function (err, connection) {
          connection.query(query, param, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};

              jsonResponse = {
                status: 'Success',
                data: rows[0],
                count: rows[1][0].totalCount
              };
              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  getUserByEmail: function (req, res, next) {
    try {
      return new Promise(function (resolve, reject) {
        var query = 'SELECT * FROM tbluser WHERE email="'+req.query.email+'"'; 
        pool.getConnection(function (err, connection) {
          connection.query(query, function (err, rows, fields) {
            if (!err) {
              var jsonResponse = {};

              jsonResponse = {
                status: 'Success',
                data: rows[0],
              };
              connection.release();
              return resolve(jsonResponse);
            } else {
              var jsonResponse = {
                message: err.message,
                status: 'Error',
              };

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },

  checkIsNewSupplier: function (req, res, next) {
    try {
      var jsonResponse = {};
      return new Promise(function (resolve, reject) {
        var query = 'SELECT userId,email,firstName,lastName,userRole FROM tbluser WHERE email="'+req.query.email+'" and isDeleted=0 '; 
        pool.getConnection(function (err, connection) {
          connection.query(query, async function (err, rows, fields) {
            if (!err) {
              
               if(rows[0] ==undefined){
                jsonResponse = {
                  status: 'Success',
                  isNewUser: true,
                };
              }
              else{ 
                jsonResponse = {
                  status: 'Success',
                  isNewUser: false,
                  data: rows[0]
                };
              }

             
              connection.release();
              return resolve(jsonResponse);
            } else {
               jsonResponse = {
                message: err.message,
                status: 'Error',
              };jsonResponse

              connection.release();
              return reject(jsonResponse);
            }
          });
        });
      });
    } catch (ex) {
      var result = { status: 'Error', message: ex.message };
      return reject(result);
    }
  },


};

function accountConfirmationEmail(req,res) {
  try {
    var filepath = __dirname + '//views//confirmyouraccountemail.html';
    filepath = filepath.replace('dao', '');
    filepath = path.normalize(filepath);
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        logger.error("Method Name: accountConfirmationEmail, Error: "+err.message); 
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          firstName: req.body.firstName,
          confirmationlink: req.body.url,
          loginURL: objConfig.adminUrl 
        };
      
        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.email, req.body.subject, htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              logger.error("Method Name: accountConfirmationEmail, Error: "+result); 
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message }; 
            logger.error("Method Name: accountConfirmationEmail, Error: "+err.message); 
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    logger.error("Method Name: accountConfirmationEmail, Error: "+ex.message); 
    return (result);
  }


}
 

function forgotPasswordEmail(req,res) {
  try {
    var filepath = __dirname + '//views//forgotpassword.html';
    filepath = filepath.replace('dao', '');
    filepath = path.normalize(filepath);
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        logger.error("Method Name: forgotPasswordEmail, Error: "+err.message); 
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          firstName: req.body.firstName,
          newPassword: req.body.newPassword,
          loginURL: objConfig.adminUrl 
        };
      
        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.email, req.body.subject, htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              logger.error("Method Name: forgotPasswordEmail, Error: "+result); 
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message }; 
            logger.error("Method Name: forgotPasswordEmail, Error: "+err.message); 
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    logger.error("Method Name: forgotPasswordEmail, Error: "+ex.message); 
    return (result);
  }


}

function updatePasswordEmail(req,res) {
  try {
    var filepath = __dirname + '//views//updatedpasswordemailnotification.html';
    filepath = filepath.replace('dao', '');
    filepath = path.normalize(filepath);
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        logger.error("Method Name: updatePasswordEmail, Error: "+err.message); 
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          firstName: req.body.firstName, 
          loginURL: objConfig.adminUrl 
        };
      
        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.email, req.body.subject, htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              logger.error("Method Name: updatePasswordEmail, Error: "+result); 
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message }; 
            logger.error("Method Name: updatePasswordEmail, Error: "+err.message); 
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    logger.error("Method Name: updatePasswordEmail, Error: "+ex.message); 
    return (result);
  }


}

function createTeamMemberEmail(req,res) {
  try {
    var filepath = __dirname + '//views//teammembercreation.html';
    filepath = filepath.replace('dao', '');
    filepath = path.normalize(filepath);
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        logger.error("Method Name: createTeamMemberEmail, Error: "+err.message); 
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          firstName: req.body.firstName,
          createdByName: req.body.createdByName,
          email: req.body.email,
          password: req.body.originalPassword,
          loginURL: objConfig.adminUrl 
        };
      
        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.email, req.body.subject, htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              logger.error("Method Name: createTeamMemberEmail, Error: "+result); 
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message }; 
            logger.error("Method Name: createTeamMemberEmail, Error: "+err.message); 
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    logger.error("Method Name: createTeamMemberEmail, Error: "+ex.message); 
    return (result);
  }


}



module.exports = user;
