const crypto = require('crypto');
const masterKey = 'EZCloud@123!';
const encryptionType = 'aes-256-cbc';
const encodingType = 'utf8';
const objConfig=require('../appconfig/config');
const pool=require('../dao/connectionPool'); 
const logger=require('../dao/logger');
var common={

  encryptString: function(text){ 
    try{
        var cipher = crypto.createCipher(encryptionType, masterKey);
        var crypted = cipher.update(text, encodingType, 'hex');
        crypted += cipher.final('hex');
        return crypted;  
}
    catch(ex){
      var result = { status: 'Error', message: ex.message }; 
    }
},

decryptString: function(text){ 
    try {
        var decipher = crypto.createDecipher(encryptionType, masterKey);
        var dec = decipher.update(text, 'hex', encodingType);
        dec += decipher.final(encodingType);
        return dec;
      } catch (ex) {
        var result = { status: 'Error', message: ex.message }; 
      }
    
    } ,

getMasterKey: function(){ 
      try {
          
          return masterKey;
        } catch (ex) {
          var result = { status: 'Error', message: ex.message }; 
        }
      
      },
generatePassword: function(){
   var generatePassword = require('password-generator');
       
      var passwords = generatePassword(8, false)
      return passwords;
      },
sendEmail: function(from, to, subject, emailContent) {
        try {
       
          return new Promise(function(resolve, reject) {
            logger.info("Method Name: sendEmail, Input Data: "+JSON.stringify({from:from,to:to,subject:subject,emailContent:emailContent}));

            var nodemailer = require('nodemailer'),
              _ = require('lodash');
            var sgTransport = require('nodemailer-sendgrid-transport');
    
            var options = {
              auth: {
                api_key: objConfig.sendGridKey
              }
            };
            var client = nodemailer.createTransport(sgTransport(options));
            var email = {
              from: from,
              to: to,
              subject: subject,
              html: emailContent
            };
    
            client.sendMail(email, function(error, info) {
              if (error) {
                 var result = { status: 'Error', message: error.message }; 
                 logger.error("Method Name: sendEmail, Error: "+error.message);
                return reject(result);
              } else {
                result = { status: 'Success', message: 'Email sent successfully' };
                logger.info("Method Name: sendEmail, Message: Email sent successfully");
                return resolve(result);
              }
            });
          });
    
    
        } 
        catch (ex) {
          var result = { status: 'Error', message: ex.message }; 
          logger.error("Method Name: sendEmail, Error: "+ex.message);
          return reject(result);
        }
      },
generateOTP: function(){
  var otpGenerator = require('otp-generator'); 
  var otp=otpGenerator.generate(6, { upperCase: false, specialChars: false,digits: true,alphabets :false });
           return otp;
    },  
  
sendSMS: function(from, to, body) {
      try { 

        return new Promise(function(resolve, reject) {
          var twilio = require('twilio');
          var client = twilio(objConfig.twilioSID, objConfig.twilioSecret);
          logger.info("Method Name: sendSMS, Input Data: "+JSON.stringify({from:from,to:to,body:body}));

          client.messages.create({
              to:to,
              from:from,
              body: body
          }, function(err, message) {
              if (err) {
                var result = { status: 'Error', message: err.message }; 
                logger.error("Method Name: sendSMS, Error: "+err.message);
                return reject(result);
              } else {
                result = { status: 'Success', message: 'OTP sent successfully',sid: message.sid }; 
                logger.info("Method Name: sendSMS, Message: OTP sent successfully");
                return resolve(result);
              }
          }); 
         
       

//           const accountSid = objConfig.twilioSID;
// const authToken = objConfig.twilioSecret;
// const client = require('twilio')(accountSid, authToken);
// console.log("accountSid: ",accountSid," authToken: ",authToken," to: ",to)

// // client.verify.services.create({friendlyName: 'My Verify Service'})
// // .then(service => console.log(service));

// client.verify.services("VA3df130bb0d3ec2af7c022a1f1a9d71f6")
//       .verificationChecks
//       .create({to: '+918870240610', code: '123456'})
//       .then(verification_check => console.log(verification_check.status)
      
//       ).catch(error => console.log("error: ",error) )
       
       });
  
      }
      
      catch (ex) {
        var result = { status: 'Error', message: ex.message }; 
          return reject(result);
      }
    },

checkDecimal:function ( n){
      n=n || "";
      var temp=n.toString();
      temp=temp.replace(/,/g, '');
      temp = parseFloat(temp.match(/[\d\.]+/));
      if(isNaN(temp))temp=null; else temp=temp;
        return temp;
    },

    checkDate:function(sDate) {  
      try{
          if(sDate.toString() == parseInt(sDate).toString()) return null; 
  
          var tryDate = new Date(sDate);
           if (tryDate && tryDate.toString() != "NaN" && tryDate != "Invalid Date")
           {
               return tryDate;//tryDate.getFullYear() + "/" + (tryDate.getMonth() + 1) + "/" + (tryDate.getDate());
               
           } 
           return null;
      }
      catch(ex){
    return null;
      }
      
    },

saveLog: function(req,res,functionName,functionData){ 
      try{   

return new Promise(function(resolve, reject) {  
     
   var query = "CALL spSaveLog(?,?)";  
   var param = [functionName,functionData];
     
   pool.getConnection(function (err, connection) {
     connection.query(query, param, function (err, rows, fields) {
           if (!err) {
              
              var jsonResponse ={
                   message: 'Success',
                   status: 'Log saved successfully' 
               }; 
               
               connection.release();
               return resolve(jsonResponse);
                    
           }
           else { 
             var jsonResponse ={
                   message: err.message,
                   status: 'Error'
               };
            
               connection.release();
               return reject(jsonResponse);
           }
              
       });
       
   });

          }) ; 
    }
      catch(ex){ 
   
       var result = { status: 'Error', message: ex.message }; 
       return  reject(result);  
      }
    },

getTeamId: function(req,res,next){ 
      try{   
    return new Promise(function(resolve, reject) {   
    
    var query=`SELECT tm.teamId  FROM tblteam tm  WHERE tm.invoiceSenderEmail='`+req.body.receiverEmail+`'` 
    var param = [];
    pool.getConnection(function (err, connection) {
     connection.query(query, param, function (err, rows, fields) { 
           if (!err) {
              var jsonResponse ={
                   message: 'Success',
                   teamId: rows[0].teamId
               };
               connection.release();
               return resolve(jsonResponse);
                    
           }
           else { 
             var jsonResponse ={
                   message: err.message,
                   status: 'Error'
               };
                
               connection.release();
               return reject(jsonResponse);
           }
              
       });
       
    });
    
          }) ; 
    }
      catch(ex){ 
       var result = { status: 'Error', message: ex.message }; 
       return  reject(result);  
      }
    }, 
} 

module.exports=common;
 
