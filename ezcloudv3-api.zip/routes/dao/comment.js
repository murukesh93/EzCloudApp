const pool=require('../dao/connectionPool'); 
const logger=require('../dao/logger');
var comments = {
saveComment: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
    logger.info("Method Name: saveComment, Input Data: "+JSON.stringify(req.body));
     var query = "CALL savecomment(?,?,?,?,?,?)";  

     var param = [req.body.commentId,req.body.comment,req.body.postedBy,
        req.body.tagBy,req.body.invoiceId,req.body.action];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if (rows[0][0].message=="Success" )
                {
                    jsonResponse ={
                        status: 'Success',
                        message: 'Comment details saved successfully'
                    }; 
                    logger.info("Method Name: saveComment, Message: Comment details saved successfully");
                }
                else{
                    jsonResponse ={
                        status: 'Error',
                        message:"Error in save comment details."
                    }; 
                }
               
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
                logger.error("Method Name: saveComment, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
            
      logger.error("Method Name: saveComment, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 
 
deleteComment: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spdeletecomment(?)";  
     var param = [req.query.commentId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                 
                    jsonResponse ={
                        status: 'Success', 
                        data: "Record deleted successfully"
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

getComments: function(req,res,next){ 
    try{   
return new Promise(function(resolve, reject) {   
 var query = "CALL spgetcomment(?,?,?,?,?)";  
 var param = [req.query.count,req.query.offset,req.query.postedBy,req.query.invoiceId,req.query.comment];

 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
            var jsonResponse ={}; 
                jsonResponse ={
                    status: 'Success', 
                    data: rows[0],
                    count: rows[1][0].totalCount
                } 
             connection.release();
             return resolve(jsonResponse); 
         }
         else { 
          logger.error("Method Name: getComments, Error: "+err.message);
           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
      logger.error("Method Name: getComments, Error: "+ex.message);
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  },

  
getCommentById: function(req,res,next){ 
    try{   
return new Promise(function(resolve, reject) {   

 var query = "SELECT * FROM vwgetcomment WHERE commentId="+req.query.commentId;  
 var param = [];
   
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
        var jsonResponse ={}; 
           jsonResponse ={
            status: 'Success', 
            data: rows[0] 
         }   
             connection.release();
             return resolve(jsonResponse); 
         }
         else { 
           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  }, 
 
getChatUser: function(req,res,next){ 
    try{   
return new Promise(function(resolve, reject) {   
 var query = "CALL spgetchatuser(?,?)";  
 var param = [req.query.teamId,req.query.invoiceId];
 
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
            var jsonResponse ={}; 
                jsonResponse ={
                    status: 'Success', 
                    data: rows[0] 
                } 
             connection.release();
             return resolve(jsonResponse); 
         }
         else { 
          logger.error("Method Name: getChatUser, Error: "+err.message);
           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
      logger.error("Method Name: getChatUser, Error: "+ex.message);
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  },

};

module.exports=comments;