const pool=require('../dao/connectionPool'); 
var jsonQuery = require('json-query');
const logger=require('../dao/logger');
var dashboard = {
getDashboard: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spgetdashboard(?,?,?,?)";  
     var param = [req.query.teamId,req.query.senderEmail,req.query.year,req.query.userId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={}; 

                var objMonthvsAmount=[];
                if(rows[3].length >0){
                  var Jan={};
                  var Feb={};
                  var Mar={};
                  var Apr={};
                  var May={};
                  var Jun={};
                  var Jul={};
                  var Aug={};
                  var Sep={};
                  var Oct={};
                  var Nov={};
                  var Dec={};
                var  data=rows[3];
                Jan= {Month:"Jan",Approved: jsonQuery('[mntName=Jan & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=Jan & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=Jan & name=Auto Approved].amount', {data: data}).value}
                  if(Jan.Approved!=null || Jan.Pending!=null || Jan.AutoApproved!=null ){ 
                 objMonthvsAmount.push(Jan);
                  }

                  Feb= {Month:"Feb",Approved: jsonQuery('[mntName=Feb & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=Feb & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=Feb & name=Auto Approved].amount', {data: data}).value}
                  if(Feb.Approved!=null || Feb.Pending!=null || Feb.AutoApproved!=null){ 
                 objMonthvsAmount.push(Feb);
                  }

                  Mar= {Month:"Mar",Approved: jsonQuery('[mntName=Mar & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=Mar & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=Mar & name=Auto Approved].amount', {data: data}).value}
                  if(Mar.Approved!=null || Mar.Pending!=null || Mar.AutoApproved!=null ){ 
                 objMonthvsAmount.push(Mar);
                  } 
                  
                 Apr= {Month:"Apr",Approved: jsonQuery('[mntName=Apr & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=Apr & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=Apr & name=Auto Approved].amount', {data: data}).value}
                  if(Apr.Approved!=null || Apr.Pending!=null || Apr.AutoApproved!=null ){ 
                 objMonthvsAmount.push(Apr);
                  }

                  May= {Month:"May",Approved: jsonQuery('[mntName=May & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=May & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=May & name=Auto Approved].amount', {data: data}).value}
                  if(May.Approved!=null || May.Pending!=null || May.AutoApproved!=null ){ 
                 objMonthvsAmount.push(May);
                  }

                  
                  Jun= {Month:"Jun",Approved: jsonQuery('[mntName=Jun & name=Approved].amount', {data: data}).value,
                 Pending: jsonQuery('[mntName=Jun & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=jun & name=Auto Approved].amount', {data: data}).value}
                  if(Jun.Approved!=null || Jun.Pending!=null || Jun.AutoApproved!=null ){ 
                 objMonthvsAmount.push(Jun);
                  }

                  Jul= {Month:"Jul",Approved: jsonQuery('[mntName=Jul & name=Approved].amount', {data: data}).value,
                  Pending: jsonQuery('[mntName=Jul & name=Pending].amount', {data: data}).value,
                  AutoApproved: jsonQuery('[mntName=jul & name=Auto Approved].amount', {data: data}).value}
                   if(Jul.Approved!=null || Jul.Pending!=null || Jul.AutoApproved !=null ){ 
                  objMonthvsAmount.push(Jul);
                   }
                  
                   Aug= {Month:"Aug",Approved: jsonQuery('[mntName=Aug & name=Approved].amount', {data: data}).value,
                  Pending: jsonQuery('[mntName=Aug & name=Pending].amount', {data: data}).value,
                  AutoApproved: jsonQuery('[mntName=Aug & name=Auto Approved].amount', {data: data}).value}
                   if(Aug.Approved!=null || Aug.Pending!=null || Aug.AutoApproved !=null){ 
                  objMonthvsAmount.push(Aug);
                   }

                  Sep= {Month:"Sep",Approved: jsonQuery('[mntName=Sep & name=Approved].amount', {data: data}).value,
                    Pending: jsonQuery('[mntName=Sep & name=Pending].amount', {data: data}).value,
                    AutoApproved: jsonQuery('[mntName=Sep & name=Auto Approved].amount', {data: data}).value}
                     if(Sep.Approved!=null || Sep.Pending!=null || Sep.AutoApproved!=null ){ 
                    objMonthvsAmount.push(Sep);
                     } 
                  
                 Oct= {Month:"Oct",Approved: jsonQuery('[mntName=Oct & name=Approved].amount', {data: data}).value,
                     Pending: jsonQuery('[mntName=Oct & name=Pending].amount', {data: data}).value,
                     AutoApproved: jsonQuery('[mntName=Oct & name=Auto Approved].amount', {data: data}).value}
                      if(Oct.Approved!=null || Oct.Pending!=null || Oct.AutoApproved!=null ){ 
                     objMonthvsAmount.push(Oct);
                      }  
                  
                 Nov= {Month:"Nov",Approved: jsonQuery('[mntName=Nov & name=Approved].amount', {data: data}).value ,
                 Pending: jsonQuery('[mntName=Nov & name=Pending].amount', {data: data}).value,
                 AutoApproved: jsonQuery('[mntName=Nov & name=Auto Approved].amount', {data: data}).value}
                  if(Nov.Approved!=null || Nov.Pending!=null || Nov.AutoApproved!=null ){ 
                 objMonthvsAmount.push(Nov);
                  }  
                  
                  Dec= {Month:"Dec",Approved: jsonQuery('[mntName=Dec & name=Approved].amount', {data: data}).value,
                  Pending: jsonQuery('[mntName=Dec & name=Pending].amount', {data: data}).value,
                  AutoApproved: jsonQuery('[mntName=Dec & name=Auto Approved].amount', {data: data}).value}
                   if(Dec.Approved!=null || Dec.Pending!=null || Dec.AutoApproved!=null ){ 
                  objMonthvsAmount.push(Dec);
                   }  
 
                  }
                  jsonResponse ={
                        status: 'Success', 
                        approved: rows[0][0].approved,
                        pending: rows[1][0].pending,
                        invoiceStatusCount: rows[2],
                        invoiceMonthVSAmount: rows[5],
                        autoApproved: rows[4][0].autoApproved,
                        MonthvsAmount:objMonthvsAmount
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
              logger.error("Method Name: getDashboard, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: getDashboard, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 
    }

module.exports=dashboard;