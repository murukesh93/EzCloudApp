const objConfig=require('../appconfig/config');
var axios = require('axios');
var username =objConfig.oicUserName ;
var password = objConfig.oicPassword;
var baseURL=objConfig.baseURL;
var objInvoice=require('./invoice');
const pool=require('../dao/connectionPool'); 
const oic = {} 
var objCommon=require('../dao/common')
const logger=require('../dao/logger');

oic.approveInvoice = function (req,res) {
    try{   
        return new Promise(function(resolve, reject) {   
    logger.info("Method Name: approveInvoice, Input Data: "+JSON.stringify(req.body)); 
    var config = {
      method: 'get', 
      auth: {
        username: username,
        password: password
      },  
       url: baseURL+"/ezcloud/erp-controller/approval", 
      headers: { 
        'subscriberId': 'SilverElephant', // req.body.invoice.data[0].teamId
       // 'Authorization': 'Basic RVpDbG91ZDpXZWxjb21lQDEyMw==', 
        'Content-Type': 'application/json'
      },
      data : req.body.invoice
    };
    
    axios(config)
    .then(function (response) {
                  if (response.data.status=="Success"){
                    var jsonResponse ={
                        message: "Valid invoice",
                        status: 'Success'
                    };  

                    logger.info("Method Name: approveInvoice, Message: "+response.data.status);
                    return resolve(jsonResponse);
                   }
                   else{
                    let temp = Object.assign({}, response)
                    delete temp.config
                    delete temp.request 

                    logger.error("Method Name: approveInvoice, Error: "+JSON.stringify( temp));

                    var functionData= JSON.stringify({Error: temp,RequestData: req.body});
                    objCommon.saveLog(req,res,"approveInvoice",functionData);
                    var jsonResponse ={
                        message: "Invalid invoice",
                        status: 'Error'
                    };  
                    return reject(jsonResponse);
                   }
    
    })
    .catch(function (error) {
                var jsonResponse ={
                    message: error.message,
                    status: "Error"
                };  
                logger.error("Method Name: approveInvoice, Error: "+error.message);
                var functionData= JSON.stringify({Error: jsonResponse,RequestData: req.body});
                objCommon.saveLog(req,res,"approveInvoice",functionData);
                return reject(jsonResponse);

    });

    

    
    //  var url = baseURL+"/ic/api/integration/v1/flows/rest/POSTAPPROVEDINVOICE/1.0/ebs/approvedInvoice";
        
    //  axios.post(url, req.body.invoice, {
    //             auth: {
    //               username: username,
    //               password: password
    //             }
    //           }).then(function(response) { 
    //             if (response.data.status=="Success"){
    //                 var jsonResponse ={
    //                     message: "Valid invoice",
    //                     status: 'Success'
    //                 };  

    //                 logger.info("Method Name: approveInvoice, Message: "+response.data.status);
    //                 return resolve(jsonResponse);
    //                }
    //                else{
    //                 let temp = Object.assign({}, response)
    //                 delete temp.config
    //                 delete temp.request 

    //                 logger.error("Method Name: approveInvoice, Error: "+JSON.stringify( temp));

    //                 var functionData= JSON.stringify({Error: temp,RequestData: req.body});
    //                 objCommon.saveLog(req,res,"approveInvoice",functionData);
    //                 var jsonResponse ={
    //                     message: "Invalid invoice",
    //                     status: 'Error'
    //                 };  
    //                 return reject(jsonResponse);
    //                }
                 
    //           }).catch(function(error) {
    //             var jsonResponse ={
    //                 message: error.message,
    //                 status: "Error"
    //             };  
    //             logger.error("Method Name: approveInvoice, Error: "+error.message);
    //             var functionData= JSON.stringify({Error: jsonResponse,RequestData: req.body});
    //             objCommon.saveLog(req,res,"approveInvoice",functionData);
    //             return reject(jsonResponse);
    //           }); 


            }); 


    }
    catch(ex){  
      logger.error("Method Name: approveInvoice, Error: "+ex.message);
     var result = { status: 'Error', message: ex.message }; 
     var functionData= JSON.stringify({Error: result,RequestData: req.body});
     objCommon.saveLog(req,res,"approveInvoice",functionData);
     return reject(result); 
    }
  }

oic.updateInvoiceStatus=async function (req,res){
    try{   
        return new Promise(function(resolve, reject) {    
          logger.info("Method Name: updateInvoiceStatus, Input Data: "+JSON.stringify(req.body));
   
          var query = "CALL spUpdateInvoiceStatus(?,?,?)";  
           var param = [req.body.invoiceId,req.body.userId,req.body.status];
             
           pool.getConnection(function (err, connection) {
             connection.query(query, param, function (err, rows, fields) {
                   if (!err) {
                      var jsonResponse ={};
                      if (rows[0][0].message=="Success" )
                      {
                          jsonResponse ={
                              status: 'Success',
                              message: 'Invoice data successfully submitted to ERP'
                          }; 
                          logger.info("Method Name: updateInvoiceStatus, Message: Status updated successfully");
                      }
                      else{
                          jsonResponse ={
                              status: 'Error',
                              message: rows[0][0].message
                          }; 
                      }
                     
                       connection.release();
                       return resolve(jsonResponse);
                            
                   }
                   else { 
                     var jsonResponse ={
                           message: err.message,
                           status: 'Error'
                       };
                       logger.info("Method Name: updateInvoiceStatus, Error: "+err.message);
                       connection.release();
                       return reject(jsonResponse);
                   }
                      
               });
               
           });
      
                  }) ; 
            }
              catch(ex){ 
                logger.info("Method Name: updateInvoiceStatus, Error: "+ex.message);
               var result = { status: 'Error', message: ex.message }; 
               return reject (result);  
              }
} 

oic.validationsInvoice = async function (req,res) {
  try{    
      return new Promise(function(resolve, reject) {   
        logger.info("Method Name: validationsInvoice, Input Data: "+JSON.stringify(req.body));     
        var config = {
          method: 'get',
          url: baseURL+"/ezcloud/erp-controller/validation",
          // auth: {
          //   username: username,
          //   password: password
          // },
          headers: { 
            'subscriberId': "SilverElephant",//req.body.teamId, 
            'Content-Type': 'application/json'
          },
          data : req.body.invoiceData
        };
        
        axios(config)
        .then(async function (response) {
          if (response.data !==undefined  ){ 
            req.body.invoiceStatus=response.data.data[0].validateInvoiceStatus;
            req.body.invoicePOStatus=response.data.data[0].validateInvoicePOStatus;
            req.body.supplierStatus=response.data.data[0].validateSupplierStatus;

            req.body.validationResponse=JSON.stringify(response.data);
            logger.info("Method Name: validationsInvoice, API Response Data: "+JSON.stringify(req.body.validationResponse)); 

            await oic.updateInvoiceValidationStatus(req,res);

              var jsonResponse ={
                  message: "Valid invoice",
                  status: 'Success'
              };  
              return resolve(jsonResponse);
             }
             else{ 
              req.body.supplierStatus="Fail";
              req.body.invoicePOStatus="Fail";
              req.body.invoiceStatus="Fail";
              req.body.validationResponse=JSON.stringify(response.data)

              var functionData= JSON.stringify({Error: response,RequestData: req.body});
              objCommon.saveLog(req,res,"validationsInvoice",functionData);

              await  oic.updateInvoiceValidationStatus(req,res);

              
              var jsonResponse ={
                  message: "Invalid invoice",
                  status: 'Error'
              };  
              return reject(jsonResponse);
             }
        })
        .catch(async function (error) { 
          logger.error("Method Name: validationsInvoice, Error : "+error.message);  
          req.body.supplierStatus="Fail";
          req.body.invoicePOStatus="Fail";
          req.body.invoiceStatus="Fail";
          req.body.validationResponse=error.message;
          var functionData= JSON.stringify({Error: req.body.validationResponse,RequestData: req.body});
          objCommon.saveLog(req,res,"validationsInvoice",functionData);
          await  oic.updateInvoiceValidationStatus(req,res);
                    var jsonResponse ={
                        message: error.message,
                        status: "Error"
                    };   
          return reject(jsonResponse); 
        }); 
          }); 
  }
  catch(ex){ 
    logger.error("Method Name: validationsInvoice, Error : "+ex.message); 
    req.body.supplierStatus="Fail";
    req.body.invoicePOStatus="Fail";
    req.body.invoiceStatus="Fail";
    req.body.validationResponse=ex.message;
    await  oic.updateInvoiceValidationStatus(req,res);
   
    var result = { status: 'Error', message: ex.message }; 
   var functionData= JSON.stringify({Error: result,RequestData: req.body});
  objCommon.saveLog(req,res,"validationsInvoice",functionData);
   return reject(result); 
  }
}


oic.updateInvoiceValidationStatus=async function (req,res){
  try{   
    
      return new Promise(function(resolve, reject) {   
     logger.info("Method Name: validationsInvoice, Input Data: "+JSON.stringify(req.body)); 
 
        var query = "CALL spUpdateInvoiceValidationStatus(?,?,?,?,?,?)";  
         var param = [req.body.invoiceStatus,req.body.invoicePOStatus,
          req.body.supplierStatus,req.body.validationResponse,req.body.invoiceId, req.body.filepath]; 
           
         pool.getConnection(function (err, connection) {
           connection.query(query, param, function (err, rows, fields) {
                 if (!err) {
                    var jsonResponse ={};
                    if (rows[0][0].message=="Success" )
                    { 
                        jsonResponse ={
                            status: 'Success',
                            message: 'Status updated successfully'
                        }; 
                        logger.info("Method Name: validationsInvoice, Message: Status updated successfully"); 

                    }
                    else{
                        jsonResponse ={
                            status: 'Error',
                            message: rows[0][0].message
                        }; 
                    }
                   
                     connection.release();
                     return resolve(jsonResponse);
                          
                 }
                 else { 
                   var jsonResponse ={
                         message: err.message,
                         status: 'Error'
                     };
              logger.error("Method Name: validationsInvoice, Error: "+err.message); 
            
                     connection.release();
                     return reject(jsonResponse);
                 }
                    
             });
             
         });
    
                }) ; 
          }
            catch(ex){ 
              logger.error("Method Name: validationsInvoice, Error: "+ex.message); 
             var result = { status: 'Error', message: ex.message }; 
             return reject (result);  
            }
}


oic.lookupService = async function (req,res) {
  try{     
      return new Promise(function(resolve, reject) {  
        logger.info("Method Name: lookupService, Input Data: "+JSON.stringify(req.body)); 

        var config = {
          method: 'post',
          url: baseURL+"/ezcloud/erp-controller/lookup",
          auth: {
            username: username,
            password: password
          },
          headers: { 
            'subscriberId': 'SilverElephant',  //req.body.teamId, 
         //   'Authorization': 'Basic RVpDbG91ZDpXZWxjb21lQDEyMw==', 
            'Content-Type': 'application/json'
          },
          data : req.body.lookupData
        }; 
        axios(config)
        .then(async function (response) {  
                if (response.data !==undefined  ){ 
                req.body.supplierId=response.data.data[0]["Vendor ID"];
                req.body.supplierSite=response.data.data[0]["Vendor Site ID"];
                req.body.supplierAddress=response.data.data[0]["Address Line 1"];
                req.body.supplierAddress2=response.data.data[0]["Address Line 2"];
                req.body.city=response.data.data[0].City;
                req.body.state=response.data.data[0].State;
                req.body.postalCode=response.data.data[0]["Post Code "];
                req.body.country=response.data.data[0].Country;
                req.body.taxNumber= response.data.data[0].SupplierTaxNumber;
                req.body.bankAccount=response.data.data[0].SupplierBankAccount;
                req.body.swift=response.data.data[0].SwiftCode;
                req.body.sortCode=response.data.data[0].SortCode;
                req.body.iban=response.data.data[0].IBAN;

                req.body.supplierResponse=JSON.stringify(response.data);
                await oic.updateSupplierDetails(req,res);

                  var jsonResponse ={
                      message: "Supplier details updated successfully",
                      status: 'Success'
                  }; 
                  logger.info("Method Name: lookupService,API Response Date : "+ JSON.stringify(response.data)); 
                  return resolve(jsonResponse);
                 }
                 else{ 
                  var functionData= JSON.stringify({Error: response,RequestData: req.body});
                  objCommon.saveLog(req,res,"lookupService",functionData);
                  var jsonResponse ={
                      message: "Update failed",
                      status: 'Error'
                  };  
                  return reject(jsonResponse);
                 } 
        })
        .catch(function (error) { 
                var jsonResponse ={
                  message: error.message,
                  status: "Error"
              };  
              var functionData= JSON.stringify({Error: jsonResponse,RequestData: req.body});
              objCommon.saveLog(req,res,"lookupService",functionData);
              logger.error("Method Name: lookupService, Error: "+error.message); 
              return reject(jsonResponse); 
        });

        
          }); 
  }
  catch(ex){  
   var result = { status: 'Error', message: ex.message }; 
   var functionData= JSON.stringify({Error: result,RequestData: req.body});
   logger.error("Method Name: lookupService, Error: "+ex.message);
   objCommon.saveLog(req,res,"lookupService",functionData);
   return reject(result); 
  }
}

oic.updateSupplierDetails=async function (req,res){
  try{ 
      return new Promise(function(resolve, reject) {  
        logger.info("Method Name: updateSupplierDetails, Input Data: "+JSON.stringify(req.body));  

        var query = "CALL spUpdateSupplierDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
         var param = [req.body.supplierAddress,req.body.supplierAddress2,
          req.body.city,req.body.state,req.body.postalCode, req.body.country
          ,req.body.supplierId,req.body.supplierSite,req.body.invoiceId,req.body.filepath,
          req.body.taxNumber,req.body.bankAccount,req.body.swift,req.body.sortCode,req.body.iban
        ];  
         pool.getConnection(function (err, connection) {
           connection.query(query, param, function (err, rows, fields) {
                 if (!err) {
                    var jsonResponse ={};
                    if (rows[0][0].message=="Success" )
                    {  
                        jsonResponse ={
                            status: 'Success',
                            message: 'Supplier details updated successfully'
                        }; 
                        logger.info("Method Name: updateSupplierDetails, Message: Supplier details updated successfully");  

                    }
                    else{ 
                        jsonResponse ={
                            status: 'Error',
                            message: rows[0][0].message
                        }; 
                    }
                   
                     connection.release();
                     return resolve(jsonResponse);
                          
                 }
                 else { 
                   var jsonResponse ={
                         message: err.message,
                         status: 'Error'
                     };
                 logger.error("Method Name: updateSupplierDetails, Error: "+err.message);  
             
                     connection.release();
                     return reject(jsonResponse);
                 }
                    
             });
             
         });
    
                }) ; 
          }
            catch(ex){  
            logger.error("Method Name: updateSupplierDetails, Error: "+ex.message);  
             var result = { status: 'Error', message: ex.message }; 
             return reject (result);  
            }
}


module.exports=oic;
