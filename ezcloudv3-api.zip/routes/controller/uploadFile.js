/**
* @swagger 
 
* /uploadFile/uploadFile:
*   post:
*     tags:
*       - uploadFile
*     name: Upload a file
*     summary: Upload a file to s3 bucket
*     security:
*       - bearerAuth: []
*     consumes:
*       -  multipart/form-data
*     produces:
*       - application/json
*     parameters: 
*       - in: formData
*         name: file
*         type: file
*         required: true 
*     responses:
*       200:
*        description:  Return Filepath
*       400:
*        description: Invalid Token key. 
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 



* /uploadFile/accessS3File:
*   post:
*     tags:
*       - uploadFile
*     name: uploadFile
*     summary: To access the s3 file
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             filePath:
*               type: string

*         required:
*           - filePath
*     responses:
*       200:
*        description:  Return Filepath
*       400:
*        description: Invalid Token key. 
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 



* /uploadFile/preSignedS3Url:
*   post:
*     tags:
*       - uploadFile
*     name: uploadFile
*     summary: To create pre-signed S3 Url
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             name:
*               type: string
*             type:
*               type: string

*         required:
*           - filePath
*     responses:
*       200:
*        description:  Return Filepath
*       400:
*        description: Invalid Token key. 
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


*/


var objFileUpload=require('../dao/uploadFile'); 
var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
var objconfig=require('../appconfig/config') 
var multiparty = require ('connect-multiparty')
multipartyMiddleware =  multiparty();
router.use(multipartyMiddleware);
var AWS = require('aws-sdk');
// var s3 = new AWS.S3({
//   signatureVersion: 'v4',
// });

var awsConfig = require('aws-config');
var AWS = require('aws-sdk');

router.post('/uploadFile', function(req, res,next) {
  try {

    var objUser = objFileUpload.uploadFile(req,res,next) ; 
     objUser.then(
      function(result) { 
        if (result.status === 'Error') {
          return res.status(500).json(result);
        } else { 
          return res.status(200).json(result);
        }
      },
      function(err) {
         var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    ); 
  } catch (ex) {
     var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  } 
  }); 
  
router.post('/accessS3File', async function(req, res,next) {
    try { 
 
AWS.config.update({ accessKeyId: objconfig.awsAccessKeyId, secretAccessKey: objconfig.awsSecretKey})

//AWS.config.update({ accessKeyId: objconfig.accessKeyId, secretAccessKey: objconfig.secretAccessKey})
const s3 = new AWS.S3()

filetext = req.body.filePath.split('/');
var text= filetext[2];
var bucketName= text.split('.');
var key= req.body.filePath.replace('https://'+text+'/','')

const myBucket =objconfig.invoiceBucketName; //bucketName[0];
const myKey = key;
const signedUrlExpireSeconds = 60 * 24 * 60 * 7

  const  url = await s3.getSignedUrl('getObject', {
    Bucket: myBucket,
    Key: myKey,
    Expires: signedUrlExpireSeconds
  })
const finalurl= url.replace('.us-west-2','');
var result = { status: 'Success', url: finalurl};
return res.status(200).json(result);
      
    } catch (ex) {
       var result = { status: 'Error', message: ex.message };
      return res.status(500).json(result);
    } 
    });
// https://dev.to/danstanhope/react-file-upload-using-s3-pre-signed-urls-1a6d
const getUploadURL = async (type, name) => {

const aws = require('aws-sdk');
aws.config.update({ region: 'us-east-1' });
console.log(aws.config);
const s3 = new aws.S3();

      const file = parseInt(Math.random() * 10000000);
      const params = {
        Bucket: objconfig.invoiceBucketName,
        Key: name,
        ContentType: type,
      };
      
      let signed = await s3.getSignedUrl('putObject', params);
      console.log('signed ', aws.config);
    
      return { signed, file };
    };
    

router.post('/preSignedS3Url', async function(req, res,next) {
      try { 
        let type = req.body.type;
       // let name = req.body.name; 
        let name = decodeURIComponent(req.body.name); 

        // let fileExtension=req.body.name.split('.');
        // var ext=fileExtension[fileExtension.length-1];
        // const { signed, file } = await getUploadURL(type, name);
        // const response = {
        //   statusCode: 200,
        //   headers: {
        //     'Access-Control-Allow-Origin': '*',
        //     'Access-Control-Allow-Credentials': true,
        //   },
        //   body: {
        //     upload_url: signed,
        //     filename: `${file}`+'.'+ext
        //   },
        // };
       
        AWS.config.update({
          accessKeyId: objconfig.awsAccessKeyId, // Generated on step 1
          secretAccessKey: objconfig.awsSecretKey, // Generated on step 1
          region: 'us-east-1', // Must be the same as your bucket
          signatureVersion: 'v4',
        });
        const params = {
          Bucket: objconfig.invoiceBucketName,
          Key: name,
          Expires: 30 * 60, // 30 minutes
          ContentType: type
        };
        const options = {
          signatureVersion: 'v4',
          region: 'us-east-1', // same as your bucket
          endpoint: new AWS.Endpoint(objconfig.accelerateURL),    useAccelerateEndpoint: true,  }
        const client = new AWS.S3(options);
        const signedURL = await (new Promise((resolve, reject) => {
          client.getSignedUrl('putObject', params, (err, data) => {      if (err) {
              reject(err)
            } else {
              resolve(data)
            }
            });
        })); 


    var result = { status: 'Success', url: signedURL};
    return res.status(200).json(result);
        
      } catch (ex) {
         var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
      } 
      });

  module.exports = router;