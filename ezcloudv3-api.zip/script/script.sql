-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for ezcloud
CREATE DATABASE IF NOT EXISTS `ezcloud` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ezcloud`;

-- Dumping structure for procedure ezcloud.spcreateinvoicedetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spcreateinvoicedetails`(
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(30),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed Boolean,
pStatus VARCHAR(25),
pinvoiceType VARCHAR(20),
pName VARCHAR(30),
pPhoneNumber VARCHAR(30),
pCreatedBy int

)
BEGIN

INSERT INTO tblinvoicedetails(invoiceNumber,senderEmail,dueDate,dueAmount,textractJson,textTractStatus,
filepath,createdDate,isDeleted,orderNumber,success,textractFailed,manualExtractFailed,status,invoiceType,name,phoneNumber,
createdBy)
VALUES(pInvoiceNumber,pSenderEmail,pDueDate,pDueAmount,pTextractJson,pTextTractStatus,
pFilepath,NOW(),0,pOrderNumber,pSuccess,pTextractFailed,pManualExtractFailed,pStatus,pinvoiceType,pName,pPhoneNumber,pCreatedBy); 

SELECT LAST_INSERT_ID()invoiceId; 

UPDATE tblinvoicedetails SET status="Auto Approved" WHERE invoiceId=LAST_INSERT_ID() AND  status="Pending" AND 
dueAmount <= (SELECT autoApproval FROM tblteam WHERE invoiceSenderEmail=pSenderEmail);
 
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spDeleteInvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spDeleteInvoice`(pinvoiceId INT)
BEGIN
 UPDATE  tblinvoicedetails set isDeleted=1 WHERE isDeleted=0 AND invoiceId=pinvoiceId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spDeleteUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spDeleteUser`(puserId INT)
BEGIN
UPDATE tbluser SET isDeleted=1 WHERE userId=puserId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spForGetPassword
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spForGetPassword`(pemail VARCHAR(50),pnewPassword VARCHAR(500))
BEGIN
if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0) =0 then
SELECT "Invalid User" message; 
ELSE 
UPDATE tbluser SET password=pnewPassword,isDefaultPassword=1 WHERE email=pemail AND isDeleted=0;
SELECT "Success" message;
END if;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spgetinvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spgetinvoice`(psearch VARCHAR(200),pteamId INT,papprovalAmountFrom DECIMAL(10,2),
papprovalAmountTo DECIMAL(10,2))
BEGIN

SET @SQL = "SELECT * FROM vwgetinvoicedetails where 0=0 "; 
SET @filter="";
 
 if pteamId > 0 then
 SET @filter= CONCAT (" and teamId= " , pteamId);
 END if ;
 
 if papprovalAmountFrom > 0 then
 SET @filter= CONCAT (" and dueAmount>= " , papprovalAmountFrom );
 END if ;
 
 if papprovalAmountTo > 0 then
 SET @filter= CONCAT ( " AND dueAmount<=", papprovalAmountTo );
 END if ;
 
 if psearch <> "" then
 SET @filter= CONCAT(@filter," and search  like '%",psearch,"%'");
 END if ;
 
 SET @filter= CONCAT(@filter," order by invoiceId desc");

SET @SQL=CONCAT(@SQL,@filter);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetInvoiceDetailById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetInvoiceDetailById`(pinvoiceId INT)
BEGIN
 SELECT * FROM tblinvoicedetails WHERE isDeleted=0 AND invoiceId=pinvoiceId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetInvoiceDetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetInvoiceDetails`()
begin
SELECT * FROM tblinvoicedetails WHERE isDeleted=0 ORDER BY invoiceId DESC LIMIT  1000;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetTeamDetailsById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetTeamDetailsById`(pteamId INT)
BEGIN
SELECT * FROM tblteam WHERE teamId=pteamId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetUser`(psearch VARCHAR(200),pteamId INT)
BEGIN

SET @SQL = "SELECT * FROM vwGetUser where 0=0 "; 
SET @filter="";
 
 if pteamId > 0 then
 SET @filter= CONCAT (" and teamId= " , pteamId);
 END if ;
 
 if psearch <> "" then
 SET @filter= CONCAT(@filter," and search  like '%",psearch,"%'");
 END if ;
 
 SET @filter= CONCAT(@filter," order by userId desc");

SET @SQL=CONCAT(@SQL,@filter);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetUserById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetUserById`(puserId INT)
BEGIN
SELECT * FROM vwGetUser  WHERE userId=puserId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spLogin
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spLogin`(
pemail VARCHAR(50),
ppassword VARCHAR(500)
)
BEGIN
SELECT us.userId,firstName,lastName,email,phoneNumber,approvalAmountFrom,approvalAmountTo,
profileLogo,userRole,"Success"message,isDefaultPassword,tm.teamId FROM tbluser us LEFT JOIN tblteammembers tm on
tm.userId=us.userId
 WHERE email=pemail AND password=ppassword AND isDeleted=0;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveInvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveInvoice`( invoiceDetails LONGTEXT )
BEGIN


    DECLARE i INT UNSIGNED DEFAULT 0;
    DECLARE v_count INT UNSIGNED DEFAULT 0 ;
    DECLARE v_current_item LONGTEXT DEFAULT NULL;
    DECLARE att_current_item LONGTEXT DEFAULT NULL;
    DECLARE  attachment LONGTEXT DEFAULT NULL;
 
    
/* DECLARE pInvoiceId INT;
DECLARE pInvoiceNumber varchar(25);
DECLARE pInvoiceDate date;
DECLARE pMessageBody varchar(100); 
DECLARE pAttachment LONGTEXT;
*/

DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;

END;
DECLARE exit handler for sqlwarning
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;
END;

START TRANSACTION;
  SET v_count=IFNULL(JSON_LENGTH(invoiceDetails), 0);
   
    WHILE i < v_count DO
     
	      SET v_current_item :=
            JSON_EXTRACT(invoiceDetails, CONCAT('$[', i, ']'));
        
        -- SET @temporal = JSON_EXTRACT(in_array, CONCAT('$[', i, ']'));
        -- SELECT REPLACE(v_current_item,'\\','') into v_current_item;
        -- SELECT REPLACE(v_current_item,'"{','{') into v_current_item;
        -- SELECT REPLACE(v_current_item,'}"','}') into v_current_item;

        SET @invNumber =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.invNumber'));
        SET @attachment =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.attachment'));
        SET @body =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.body'));
        SET @invDate =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.invDate'));
        
        
        INSERT INTO tblInvoice(invoiceNumber,messageBody,invoiceDate,createdDate,isDeleted)
        VALUES(@invNumber,@body,@invDate,NOW(),0); 
        SET @invId=LAST_INSERT_ID(); 
        
        
         SET @att_count=IFNULL(JSON_LENGTH(@attachment), 0); 
         SET @j  = 0; 
		   SET @att_current_item= NULL;
		   
       
         
           WHILE @j < @att_count DO
     
	         SET @att_current_item :=
            JSON_EXTRACT(@attachment, CONCAT('$[', @j, ']'));
            
            SET @filepath = JSON_UNQUOTE(JSON_EXTRACT(@att_current_item, '$.fpath'));
            

            INSERT INTO tblAttachment (invoiceId,filepath,isDeleted)VALUES(@invId,@filepath,0);
            
             SET @j = @j + 1; 
             END WHILE;  
             

        SET i := i + 1;
    END WHILE;
 

   SELECT v_count v_count;
COMMIT;

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveInvoiceDetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveInvoiceDetails`(
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(25),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed BOOLEAN

)
BEGIN

INSERT INTO tblinvoicedetails(invoiceNumber,senderEmail,dueDate,dueAmount,textractJson,textTractStatus,
filepath,createdDate,isDeleted,orderNumber,success,textractFailed,manualExtractFailed)
VALUES(pInvoiceNumber,pSenderEmail,pDueDate,pDueAmount,pTextractJson,pTextTractStatus,
pFilepath,NOW(),0,pOrderNumber,pSuccess,pTextractFailed,pManualExtractFailed); 

SELECT LAST_INSERT_ID()invoiceId; 

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveUser`(
puserId	INT,
pfirstName	varchar(50),
plastName	varchar(50),
pemail	varchar(50),
ppassword	varchar(500),
pphoneNumber	varchar(50),
papprovalAmountFrom	decimal(10,2),
papprovalAmountTo	decimal(10,2),
pprofileLogo	varchar(1000),
pcreatedBy	INT,
puserRole	varchar(25),
pAction VARCHAR(25),
pinvoiceSenderEmail VARCHAR(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @TEXT);
SELECT @full_error;
RESIGNAL;
END;
DECLARE exit handler for sqlwarning
 BEGIN
 ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;
END;

START TRANSACTION;

if pAction= "Add" then

if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isdeleted=0)=0 then
INSERT INTO tbluser(firstName,lastName,email,password,phoneNumber,approvalAmountFrom,approvalAmountTo,profileLogo,createdBy,userRole,
createdDate,isDeleted,isDefaultPassword)
VALUES(pfirstName,plastName,pemail,ppassword,pphoneNumber,papprovalAmountFrom,papprovalAmountTo,pprofileLogo,pcreatedBy,puserRole,
NOW(),0,1); 

SET puserId= (select LAST_INSERT_ID());
SET @teamId= (SELECT  tm.teamId FROM tblteam tb INNER JOIN tblteammembers tm ON tm.userId= pcreatedBy  LIMIT 1 );

-- create team
if puserRole="Admin" then
INSERT INTO tblteam (invoiceSenderEmail,autoApproval,createdDate)VALUES(pinvoiceSenderEmail,20,NOW());
SET @teamId= (select LAST_INSERT_ID());
END if;

-- create team member
if puserRole="Admin" OR puserRole="Team Member"  then
INSERT INTO tblteammembers (teamId,userId)VALUES(@teamId,puserId);
END if;


SELECT puserId userId, "Success" message; 

ELSE
SELECT 0 userId,"Email already exist" message;
END if;

ELSE
UPDATE tbluser SET firstName= (case when pfirstName="" OR pfirstName=NULL then firstName ELSE pfirstName END),
lastName= (case when plastName="" OR plastName=NULL then lastName ELSE plastName END),
phoneNumber=(case when pphoneNumber="" OR pphoneNumber=NULL then phoneNumber ELSE pphoneNumber END),
approvalAmountFrom=(case when papprovalAmountFrom<= 0 OR papprovalAmountFrom=NULL then approvalAmountFrom ELSE papprovalAmountFrom END),
approvalAmountTo=(case when papprovalAmountTo<=0 OR papprovalAmountTo=NULL then approvalAmountTo ELSE papprovalAmountTo END),
profileLogo=(case when pphoneNumber="" OR pprofileLogo=NULL then profileLogo ELSE pprofileLogo END)
WHERE userId=puserId;

SELECT puserId userId,"Success" message; 
END if;
 
COMMIT;   
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spupdateinvoicedetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spupdateinvoicedetails`(
pInvoiceId INT,
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(30),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed Boolean,
pStatus VARCHAR(25),
pinvoiceType VARCHAR(20),
pName VARCHAR(30),
pPhoneNumber VARCHAR(30)

)
BEGIN

update tblinvoicedetails SET 
invoiceNumber= (case when pinvoiceNumber="" OR pinvoiceNumber=NULL then invoiceNumber ELSE pinvoiceNumber END),
senderEmail=(case when pSenderEmail="" OR pSenderEmail=NULL then senderEmail ELSE pSenderEmail END),
dueDate=(case when pDueDate="" OR pDueDate=NULL then dueDate ELSE pDueDate END),
dueAmount=(case when pdueAmount<=0 OR pdueAmount=NULL then dueAmount ELSE pdueAmount END),
textractJson=(case when pTextractJson="" OR pTextractJson=NULL then textractJson ELSE pTextractJson END),
textTractStatus=(case when pTextTractStatus="" OR pTextTractStatus=NULL then textTractStatus ELSE pTextTractStatus END),
filepath=(case when pFilepath="" OR pFilepath=NULL then filepath ELSE pFilepath END),
orderNumber=(case when pOrderNumber="" OR pOrderNumber=NULL then orderNumber ELSE pOrderNumber END),
success=(case when pSuccess="" OR pSuccess=NULL then success ELSE pSuccess END),
textractFailed=(case when pTextractFailed="" OR pTextractFailed=NULL then textractFailed ELSE pTextractFailed END),
manualExtractFailed=(case when pManualExtractFailed="" OR pManualExtractFailed=NULL then manualExtractFailed ELSE pManualExtractFailed END),
status=(case when PStatus="" OR PStatus=NULL then status ELSE PStatus END),
invoiceType=(case when pInvoiceType="" OR pInvoiceType=NULL then invoiceType ELSE pInvoiceType END),
name=(case when pName="" OR pName=NULL then name ELSE pName END),
phoneNumber=(case when pPhoneNumber="" OR pPhoneNumber=NULL then phoneNumber ELSE pPhoneNumber END)
WHERE invoiceId=pInvoiceId; 

SELECT pInvoiceId invoiceId; 

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdateInvoiceStatus
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdateInvoiceStatus`(pinvoiceId INT,pactionBy INT,pstatus	varchar(25))
BEGIN
UPDATE tblinvoicedetails SET STATUS=pstatus,actionBy=pactionBy,actionDate=NOW() WHERE invoiceId=pinvoiceId;
SELECT "Success" message;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdatePassword
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdatePassword`(pemail VARCHAR(50),poldpassword VARCHAR(500),pnewPassword VARCHAR(500))
BEGIN
if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0) =0 then
SELECT "Invalid User" message;

ELSEIF (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0 AND PASSWORD=poldpassword) =0 then
SELECT "Invalid Credential" message;

ELSE 
UPDATE tbluser SET password=pnewPassword,isDefaultPassword=0 WHERE email=pemail AND isDeleted=0 AND password=poldpassword;
SELECT "Success" message;
END if;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdateTeam
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdateTeam`(pteamId INT,pautoApproval DECIMAL (10,2),pinvoiceSenderEmail VARCHAR(50))
BEGIN
UPDATE tblteam SET invoiceSenderEmail= (case when pinvoiceSenderEmail="" OR pinvoiceSenderEmail=NULL then invoiceSenderEmail ELSE pinvoiceSenderEmail END),
autoApproval=(case when pautoApproval<=0 OR pautoApproval=NULL then autoApproval ELSE pautoApproval END)
WHERE teamId=pteamId;
SELECT "Success" message;
END//
DELIMITER ;

-- Dumping structure for table ezcloud.tblattachment
CREATE TABLE IF NOT EXISTS `tblattachment` (
  `attachmentId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceId` int(11) DEFAULT NULL,
  `filepath` varchar(1000) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`attachmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblattachment: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblattachment` DISABLE KEYS */;
INSERT IGNORE INTO `tblattachment` (`attachmentId`, `invoiceId`, `filepath`, `isDeleted`) VALUES
	(19, 13, 'inv#123.pdf', 0),
	(20, 13, 'inv#123_1.pdf', 0);
/*!40000 ALTER TABLE `tblattachment` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblinvoice
CREATE TABLE IF NOT EXISTS `tblinvoice` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(25) DEFAULT NULL,
  `invoiceDate` date DEFAULT NULL,
  `messageBody` text DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblinvoice: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblinvoice` DISABLE KEYS */;
INSERT IGNORE INTO `tblinvoice` (`invoiceId`, `invoiceNumber`, `invoiceDate`, `messageBody`, `createdDate`, `isDeleted`) VALUES
	(13, '#123', '2020-08-11', 'data', '2020-08-19 16:15:34', 0),
	(14, '#124', '2020-08-11', 'data', '2020-08-19 16:15:34', 0);
/*!40000 ALTER TABLE `tblinvoice` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblinvoicedetails
CREATE TABLE IF NOT EXISTS `tblinvoicedetails` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(25) DEFAULT NULL,
  `senderEmail` varchar(30) DEFAULT NULL,
  `dueDate` varchar(20) DEFAULT NULL,
  `dueAmount` varchar(20) DEFAULT NULL,
  `textractJson` text DEFAULT NULL,
  `textTractStatus` tinyint(1) DEFAULT NULL,
  `filePath` varchar(1000) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  `orderNumber` varchar(25) DEFAULT NULL,
  `success` tinyint(4) DEFAULT NULL,
  `textractFailed` tinyint(4) DEFAULT NULL,
  `manualExtractFailed` tinyint(4) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `invoiceType` varchar(25) DEFAULT NULL,
  `actionBy` int(11) DEFAULT NULL,
  `actionDate` datetime DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblinvoicedetails: ~12 rows (approximately)
/*!40000 ALTER TABLE `tblinvoicedetails` DISABLE KEYS */;
INSERT IGNORE INTO `tblinvoicedetails` (`invoiceId`, `invoiceNumber`, `senderEmail`, `dueDate`, `dueAmount`, `textractJson`, `textTractStatus`, `filePath`, `createdDate`, `isDeleted`, `orderNumber`, `success`, `textractFailed`, `manualExtractFailed`, `status`, `invoiceType`, `actionBy`, `actionDate`, `name`, `phoneNumber`, `createdBy`) VALUES
	(10, '123', 'murukeshs@apptomate.co', '2020-09-09', '33', '', 1, '', '2020-09-11 15:40:47', 1, '333', 1, 1, 1, 'Pending', NULL, 1, '2020-10-06 13:05:23', NULL, NULL, NULL),
	(11, '123', 'murukeshs@apptomate.co', '2020-09-09', '33', '', 1, '', '2020-09-11 15:41:23', 0, '333', 1, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(12, 'inv777', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:56:23', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(13, 'inv777', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:57:20', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(14, 'inv779', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:57:42', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(15, 'inv780', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 13:05:14', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(16, 'S123', 'murukeshs@apptomate.co', '2020-11-10', '50', '{}', 1, 'testpath1.pdf', '2020-10-16 15:13:09', 0, 'O123', 1, 1, 1, '0', 'PO', NULL, NULL, 'Apptomate', '8870240610', 5),
	(17, 'Inv17', 'murukeshs@apptomate.co', '2020-11-11', '20', '{}', 1, '17.pdf', '2020-10-16 15:19:47', 0, 'O17', 1, 1, 1, 'Pending', 'PO', NULL, NULL, 'Apptomate Digital', '8667749365', 5),
	(18, 'S123', 'murukeshs@apptomate.co', '2020-11-10', '50', '{}', 1, 'testpath1.pdf', '2020-10-16 15:26:31', 0, 'O123', 0, 0, 1, 'Pending', 'PO', NULL, NULL, 'Apptomate', '8870240610', 5),
	(19, 'inv45', 'murukeshs@apptomate.co', '2020/11/11', '45', '', 1, '', '2020-11-03 15:21:16', 0, 'ord1', 1, 0, 0, 'Pending', 'Non-PO', NULL, NULL, '', '', 5),
	(20, 'inv45', 'murukeshs@apptomate.co', '2020/11/11', '4', '', 1, '', '2020-11-03 15:21:57', 0, 'ord1', 1, 0, 0, 'Auto Approved', 'Non-PO', NULL, NULL, '', '', 5),
	(21, 'inv45', 'murukeshs@apptomate.co1', '2020/11/11', '4', '', 1, '', '2020-11-03 15:35:18', 0, 'ord1', 1, 0, 0, 'Pending', 'Non-PO', NULL, NULL, '', '', 5);
/*!40000 ALTER TABLE `tblinvoicedetails` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblteam
CREATE TABLE IF NOT EXISTS `tblteam` (
  `teamId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceSenderEmail` varchar(50) DEFAULT NULL,
  `autoApproval` decimal(10,2) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  PRIMARY KEY (`teamId`),
  UNIQUE KEY `invoiceSenderEmail` (`invoiceSenderEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblteam: ~1 rows (approximately)
/*!40000 ALTER TABLE `tblteam` DISABLE KEYS */;
INSERT IGNORE INTO `tblteam` (`teamId`, `invoiceSenderEmail`, `autoApproval`, `createdDate`) VALUES
	(1, 'murukeshs@apptomate.co', 25.55, '2020-10-01 14:53:09');
/*!40000 ALTER TABLE `tblteam` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblteammembers
CREATE TABLE IF NOT EXISTS `tblteammembers` (
  `memberId` int(11) NOT NULL AUTO_INCREMENT,
  `teamId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblteammembers: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblteammembers` DISABLE KEYS */;
INSERT IGNORE INTO `tblteammembers` (`memberId`, `teamId`, `userId`) VALUES
	(1, 1, 4),
	(2, 1, 5);
/*!40000 ALTER TABLE `tblteammembers` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tbluser
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `phoneNumber` varchar(50) DEFAULT NULL,
  `approvalAmountFrom` decimal(10,2) DEFAULT NULL,
  `approvalAmountTo` decimal(10,2) DEFAULT NULL,
  `profileLogo` varchar(1000) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `userRole` varchar(25) DEFAULT NULL,
  `isDefaultPassword` tinyint(1) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `createdBy` (`createdBy`),
  CONSTRAINT `tbluser_ibfk_1` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`),
  CONSTRAINT `tbluser_ibfk_2` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`),
  CONSTRAINT `tbluser_ibfk_3` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tbluser: ~4 rows (approximately)
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT IGNORE INTO `tbluser` (`userId`, `firstName`, `lastName`, `email`, `password`, `phoneNumber`, `approvalAmountFrom`, `approvalAmountTo`, `profileLogo`, `createdBy`, `createdDate`, `userRole`, `isDefaultPassword`, `isDeleted`) VALUES
	(1, 'murukesh', 'kumar', 'murukeshs@apptomate.co', 'e99545001372179a734b38d383d3ccdf', '8870240610', 1.00, 1000000.00, '', NULL, '2020-09-28 13:27:40', 'Super Admin', 1, 0),
	(4, 'test', 'user 1', 'testuser1@gmail.com', 'e99545001372179a734b38d383d3ccdf', '8870240611', 1.00, 2000.00, '', 1, '2020-10-01 14:53:09', 'Admin', 1, 0),
	(5, 'team', 'user 1', 'teamuser1@gmail.com', 'f6e8d3d4bfa4e0b504a52b7da554b764d1dd38cdb0df608f23c4d6fa0f55b359', '48849933', 1.00, 50.00, '', 4, '2020-10-01 14:56:47', 'Team Member', 1, 0);
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;

-- Dumping structure for view ezcloud.vwgetinvoicedetails
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vwgetinvoicedetails` (
	`invoiceId` INT(11) NOT NULL,
	`invoiceNumber` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`senderEmail` VARCHAR(30) NULL COLLATE 'utf8mb4_general_ci',
	`dueDate` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`dueAmount` DECIMAL(10,2) NULL,
	`textractJson` TEXT NULL COLLATE 'utf8mb4_general_ci',
	`textTractStatus` TINYINT(1) NULL,
	`filePath` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`invCreatedDate` DATETIME NULL,
	`orderNumber` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`success` TINYINT(4) NULL,
	`textractFailed` TINYINT(4) NULL,
	`manualExtractFailed` TINYINT(4) NULL,
	`status` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceType` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`actionBy` INT(11) NULL,
	`actionDate` DATETIME NULL,
	`name` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`phoneNumber` VARCHAR(30) NULL COLLATE 'utf8mb4_general_ci',
	`teamId` INT(11) NULL,
	`invoiceSenderEmail` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`autoApproval` DECIMAL(10,2) NULL,
	`teamCreatedDate` DATETIME NULL,
	`search` VARCHAR(56) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view ezcloud.vwgetuser
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vwgetuser` (
	`userId` INT(11) NOT NULL,
	`firstName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`lastName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`email` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`phoneNumber` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`approvalAmountFrom` DECIMAL(10,2) NULL,
	`approvalAmountTo` DECIMAL(10,2) NULL,
	`profileLogo` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`userRole` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`createdBy` INT(11) NULL,
	`createdDate` DATETIME NULL,
	`cfirstName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`clastName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`cemail` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`teamId` INT(11) NULL,
	`search` VARCHAR(178) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view ezcloud.vwgetinvoicedetails
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vwgetinvoicedetails`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwgetinvoicedetails` AS SELECT invoiceId,invoiceNumber,senderEmail,dueDate,
CAST((case when dueAmount="" OR dueAmount=NULL then 0 ELSE  dueAmount END)as DECIMAL (10,2))dueAmount,
textractJson,textTractStatus,filePath,inv.createdDate invCreatedDate
,orderNumber,success,textractFailed,manualExtractFailed,status,invoiceType,actionBy,actionDate,name,phoneNumber,
tm.teamId,tm.invoiceSenderEmail,tm.autoApproval,tm.createdDate teamCreatedDate,
concat(inv.invoiceNumber,"_",inv.senderEmail) search
FROM tblinvoicedetails inv left join tblteam tm ON tm.invoiceSenderEmail=inv.senderEmail 
WHERE isDeleted=0 ;

-- Dumping structure for view ezcloud.vwgetuser
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vwgetuser`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwgetuser` AS SELECT us.userId,us.firstName,us.lastName,us.email,us.phoneNumber,us.approvalAmountFrom,us.approvalAmountTo,
us.profileLogo,us.userRole,us.createdBy,us.createdDate, cr.firstName cfirstName,cr.lastName clastName,
cr.email cemail,mem.teamId, CONCAT(us.firstName,"_",us.lastName,"_",us.email,"_",us.userRole)search FROM tbluser us 
LEFT JOIN tbluser cr ON cr.userId=us.createdBy
LEFT JOIN tblteammembers mem ON mem.userId=us.userId 
 WHERE us.isDeleted=0 ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
