/**
* @swagger 

* /comment/createComment:
*   post:
*     tags:
*       - comment
*     name: comment
*     summary: create a new comment
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             postedBy:
*               type: integer
*             comment:
*               type: string
*             tagBy:
*               type: string
*             invoiceId:
*               type: integer

*         required:
*           - invoiceId
*           - comment
*           - postedBy

*     responses:
*       200:
*         description: comment details saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /comment/updateComment:
*   put:
*     tags:
*       - comment
*     name: comment
*     summary: To update a existing comment
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             commentId:
*               type: integer
*             postedBy:
*               type: integer
*             comment:
*               type: string
*             tagBy:
*               type: string
*             invoiceId:
*               type: integer

*         required:
*           - commentId
*           - comment

*     responses:
*       200:
*         description: comment details saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 



* /comment/getCommentById:
 *   get:
 *     tags:
 *       - comment
 *     name: comment
 *     summary: To get comment details object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: commentId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return comment object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 
* /comment/deleteComment:
 *   delete:
 *     tags:
 *       - comment
 *     name: comment
 *     summary: To delete a particulat comment detail object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: commentId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 

* /comment/getComments:
 *   get:
 *     tags:
 *       - comment
 *     name: comment
 *     summary: To get list of comments object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: comment
 *         type: string
 *       - in: query
 *         name: invoiceId
 *         type: integer
 *       - in: query
 *         name: postedBy
 *         type: integer
 *  
 *     responses:
 *       200:
 *        description: Return comment object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

 
* /comment/getChatUser:
 *   get:
 *     tags:
 *       - comment
 *     name: comment
 *     summary: To get list of user object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceId
 *         type: integer
 *       - in: query
 *         name: teamId
 *         type: integer
 *  
 *     responses:
 *       200:
 *        description: Return user object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 * 
 */

 var express = require('express');
 const router = express.Router();
 var jwtAuth=require('../dao/jwt');
 const objComment=require('../dao/comment');
 

 router.post('/createComment',jwtAuth.VerifyToken, function(req, res,next) {
     try {  
       if(req.body.comment=='' ||req.body.comment==undefined  ){
         return res.status(403).json({status:'Error',message:'comment is required!'});
       }
       if(req.body.postedBy=='' ||req.body.postedBy==undefined || req.body.postedBy<=0 ){
        return res.status(403).json({status:'Error',message:'postedBy is required!'});
      }
      if(req.body.invoiceId=='' ||req.body.invoiceId==undefined || req.body.invoiceId<=0 ){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'});
      }
      req.body.commentId=0;
      req.body.action='Add';
       var obj = objComment.saveComment(req, res, next);
       obj.then(
         function (result) {
           if (result.status === 'Error') { 
             return res.status(403).json(result);
           }
           else {
             return res.status(200).json(result);  
           }
         },
         function (err) {  
           var result = { status: 'Error', message: err.message };
           return res.status(500).json(result);
         }
       );
   
     } catch (ex) {
        var jsonResponse = { status: 'Error', message: ex.message };
       return res.status(500).json(jsonResponse);  
     } 
   }); 
   
router.put('/updateComment',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.body.comment=='' || req.body.comment==undefined  ){
        return res.status(403).json({status:'Error',message:'comment is required!'});
      } 
     if(req.body.invoiceId=='' || req.body.invoiceId==undefined || req.body.invoiceId<=0 ){
       return res.status(403).json({status:'Error',message:'invoiceId is required!'});
     }
     if(req.body.commentId=='' || req.body.commentId==undefined || req.body.commentId<=0 ){
      return res.status(403).json({status:'Error',message:'commentId is required!'});
    }
    req.body.action='Edit';
      var obj = objComment.saveComment(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') { 
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);  
          }
        },
        function (err) {  
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);  
    } 
  }); 
  
router.delete('/deleteComment',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.query.commentId=='' || req.query.commentId==undefined || req.query.commentId<= 0 ){
            return res.status(403).json({status:'Error',message:'commentId is required!'}); 
        } 
       
      var obj = objComment.deleteComment(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 

router.get('/getComments',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
        req.query.count=10;
      } 
      if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
        req.query.offset=0;
      }  
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
        req.query.teamId=0;
      }  
      if(req.query.postedBy=='' || req.query.postedBy==undefined || req.query.postedBy<=0 ){
        req.query.postedBy=0;
      }  
      if(req.query.tagBy=='' || req.query.tagBy==undefined || req.query.tagBy<=0 ){
        req.query.tagBy=0;
      }   
      if(req.query.senderEmail=='' || req.query.senderEmail==undefined  ){
        req.query.senderEmail="";
      }
      if(req.query.receiverEmail=='' || req.query.receiverEmail==undefined  ){
        req.query.receiverEmail="";
      }  
      
      var obj = objComment.getComments(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  
router.get('/getCommentById',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      
    if(req.query.commentId=='' || req.query.commentId==undefined || req.query.commentId<= 0 ){
      return res.status(403).json({status:'Error',message:'commentId is required!'}); 
  }  
      var obj = objComment.getCommentById(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });

router.get('/getChatUser',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<= 0 ){
        return res.status(403).json({status:'Error',message:'teamId is required!'}); 
    }  
    if(req.query.invoiceId=='' || req.query.invoiceId==undefined || req.query.invoiceId<= 0 ){
      return res.status(403).json({status:'Error',message:'invoiceId is required!'}); 
  }  
      var obj = objComment.getChatUser(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
 
module.exports = router;