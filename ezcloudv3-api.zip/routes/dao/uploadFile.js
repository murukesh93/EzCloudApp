var objconfig=require('../appconfig/config') 
var datetime = require('node-datetime');
var fs = require('fs');
var aws = require('aws-sdk');
const logger=require('../dao/logger');

var uploadFile={
 
    uploadFile: function(req,res,next){ 
        return new Promise(function(resolve, reject) {
          try {

            aws.config.setPromisesDependency();
            aws.config.update({
              accessKeyId: objconfig.awsAccessKeyId,
              secretAccessKey: objconfig.awsSecretKey,
              region: 'us-west-2'
            });
            const s3 = new aws.S3();
            var dt = datetime.create();
                  var formatteddatetime = dt.format('Y-m-d-H-M-S');
                  var fileext = [];
                  fileext = req.files.file.originalFilename.split('.');
                  var fileName = fileext[0].replace(/[^A-Z0-9-_]/gi, '');
                  newfilename = fileName +  '_' + formatteddatetime + '.' +fileext[fileext.length - 1];

            var params = {
              ACL: 'public-read',
              Bucket: objconfig.bucketName,
              Body: fs.createReadStream(req.files.file.path),
              Key: newfilename
            };
        
            s3.upload(params, (err, data) => {
              if (err) {
                fs.unlinkSync(req.files.file.path); // Empty temp folder

                var result = { status: 'Error', message: err};  
                return resolve(err);
              }
        
              if (data) {
                fs.unlinkSync(req.files.file.path); // Empty temp folder
                const locationUrl = data.Location;
                result = {
                          status: 'Success',
                          filePath:  locationUrl,
                           message: 'File uploaded successfully' 
                              };
              return resolve(result);
              }
            });

          } catch (excb1) {                        
          var result = { status: 'Error', message: excb1.message };  
          return  reject(result);          }


});
}

} 
module.exports=uploadFile;