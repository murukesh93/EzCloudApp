const pool=require('../dao/connectionPool'); 
const logger=require('../dao/logger');
var objCommon=require('../dao/common');
const objConfig=require('../appconfig/config');
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');

var supplier = {

    
sendSupplierRequest: function(req,res,next){ 
    try{   

return new Promise(function(resolve, reject) {   
logger.info("Method Name: sendSupplierRequest, Input Data: "+JSON.stringify(req.body));

 var query = "CALL spSendSupplierRequest(?,?,?)";  
 var param = [req.body.teamId,req.body.supplierEmail,req.body.requestedBy];
   
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
    if (!err) {
        var jsonResponse ={};
        if (rows[0][0].message=="Success" )
        {
            jsonResponse ={
                status: 'Success',
                message: 'Request sent successfully'
            }; 
          
            logger.info("Method Name: sendSupplierRequest, Message: Request sent successfully");
            req.body.supplierCompanyName=rows[0][0].companyName;
            req.body.requestBy=rows[0][0].userName;
            req.body.email=req.body.supplierEmail;
            req.body.subject='Invitation to Collaborate with '+req.body.supplierCompanyName+'’s Invoice Processing – EZ Cloud';
            sendSupplierRequestEmail(req,res);
            // var obj =objCommon.sendEmail(objConfig.fromEmail,req.body.supplierEmail,'EZ Cloud–Invite Request',
            // `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
            // <div></br></br>`+ `<p></br></br>Hello <br><br> You have been invited to EZ Cloud application by `+userName+` from `+companyName+` to begin the collaboration.</p>
            // <br> Thanks <br> EZ Cloud Team </div>`);
 
        }
        else{
            jsonResponse ={
                status: 'Error',
                message: rows[0][0].message
            }; 
        }
       
         connection.release();
         return resolve(jsonResponse);
              
     }
     else { 
       var jsonResponse ={
             message: err.message,
             status: 'Error'
         };
         logger.error("Method Name: sendSupplierRequest, Error: "+err.message);
 
         connection.release();
         return reject(jsonResponse);
     }
     });
     
 });

        }) ; 
  }
    catch(ex){ 
        logger.error("Method Name: sendSupplierRequest, Error: "+ex.message);
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  },

updateSupplierStatus: async function(req,res,next){ 
    try{   
 
return new Promise(function(resolve, reject) {    
logger.info("Method Name: updateSupplierStatus, Input Data: "+JSON.stringify(req.body));

var query = "CALL spUpdateSupplierStatus(?,?)";  
 var param = [req.body.requestId,req.body.status];
   var message="Status updated successfully";
   if(req.body.status=="Accepted"){
    message="Supplier reactivated successfully";
   }
   else if(req.body.status=="Deactivated"){
    message="Supplier deactivated successfully";
   }
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
            var jsonResponse ={};
            if (rows[0][0].message=="Success" )
            {
                jsonResponse ={
                    status: 'Success',
                    message: message
                }; 
                logger.info("Method Name: updateSupplierStatus, Message: Status updated successfully");

            }
            else{
                jsonResponse ={
                    status: 'Error',
                    message: rows[0][0].message
                }; 
            }
           
             connection.release();
             return resolve(jsonResponse);
                  
         }
         else { 
            logger.error("Method Name: updateSupplierStatus, Error: "+err.message);

           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
        logger.error("Method Name: updateSupplierStatus, Error: "+ex.message);

     var result = { status: 'Error', message: ex.message }; 
     return  (result);  
    }
  }, 
 
getSupplierRequest: function(req,res,next){ 
    try{   
return new Promise(function(resolve, reject) {   
 var query = "CALL spGetSupplierRequest(?,?,?,?,?,?,?,?,?)";  
 var param = [req.query.teamId,req.query.requestStatus,req.query.companyName,
  req.query.requestedName,req.query.requestId,req.query.count,req.query.offset,req.query.supplierEmail,
req.query.supplierCompanyName];
 
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
            var jsonResponse ={};
             
                jsonResponse ={
                    status: 'Success', 
                    data: rows[0],
                    count: rows[1][0].totalCount
                } 
             connection.release();
             return resolve(jsonResponse); 
         }
         else { 
            logger.error("Method Name: getSupplierRequest, Error: "+err.message);
           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
        logger.error("Method Name: getSupplierRequest, Error: "+ex.message);
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  },

  deleteSupplierRequest: function(req,res,next){ 
    try{   
return new Promise(function(resolve, reject) {   

 var query = "CALL spDeleteSupplierRequest(?)";  
 var param = [req.query.requestId];
   
 pool.getConnection(function (err, connection) {
   connection.query(query, param, function (err, rows, fields) {
         if (!err) {
            var jsonResponse ={};
             
                jsonResponse ={
                    status: 'Success', 
                    data: "Record deleted successfully"
                } 
             connection.release();
             return resolve(jsonResponse); 
         }
         else { 
           var jsonResponse ={
                 message: err.message,
                 status: 'Error'
             };
              
             connection.release();
             return reject(jsonResponse);
         }
            
     });
     
 });

        }) ; 
  }
    catch(ex){ 
     var result = { status: 'Error', message: ex.message }; 
     return  reject(result);  
    }
  }, 

};


function sendSupplierRequestEmail(req,res) {
    try {
      var filepath = __dirname + '//views//supplierinvite.html';
      filepath = filepath.replace('dao', '');
      filepath = path.normalize(filepath);
      fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
        if (err) {
          var result = { status: 'Error', message: err.message };
          logger.error("Method Name: sendSupplierRequestEmail, Error: "+err.message); 
          return (result);
        } else {
          var template = handlebars.compile(html);
          var replacements = {
            requestBy: req.body.requestBy,
            supplierCompanyName: req.body.supplierCompanyName,
            loginURL: objConfig.adminUrl ,
            signUpUrl: objConfig.adminUrl+"/signup?email="+req.body.email

          };
        
          var htmlToSend = template(replacements);
          var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.email, req.body.subject, htmlToSend);
          objSendEmail.then(
            function (result) {
              if (result.status === 'Error') {
                logger.error("Method Name: sendSupplierRequestEmail, Error: "+result); 
                return (result);
              } else {
                return (result);
              }
            },
            function (err) {
              var result = { status: 'Error', message: err.message }; 
              logger.error("Method Name: sendSupplierRequestEmail, Error: "+err.message); 
              return (result);
            }
          );
  
  
        }
      });
  
    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message };
      logger.error("Method Name: sendSupplierRequestEmail, Error: "+ex.message); 
      return (result);
    }
  
  
  }


module.exports=supplier;