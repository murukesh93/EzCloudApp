var mysql = require('mysql');
//local 
var pool = mysql.createPool
({
    connectionlimit: 100,
    host: '127.0.0.1',
    user: 'root',
    password: '',
    port: '3306',
    database: 'ezcloud',
    multiplestatements : true
    });
 

            
    module.exports = pool;
