const pool=require('../dao/connectionPool'); 
objCommon=require('../dao/common');
const logger=require('../dao/logger');

var report = {

getInvoiceReport: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   
     var query = "CALL spGetInvoiceReport(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
     var param = [req.query.teamId,req.query.approvalAmountTo,
      req.query.count,req.query.offset,req.query.status,req.query.invoiceNumber,
     req.query.receiverEmail,req.query.senderEmail,req.query.dueAmount,req.query.supplierCompanyName,
     req.query.invoiceAmount, req.query.createdFromDate, req.query.createdToDate,
     req.query.dueFromDate, req.query.dueToDate,req.query.invoiceFromDate, req.query.invoiceToDate,
     req.query.approvedBy,req.query.isDuplicate,req.query.is3PercentageRange,req.query.approvedByRole
    ];
    
  pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                for(i=0; i<rows[0].length;i++){
                  rows[0][i].invoiceLine=JSON.parse(rows[0][i].invoiceLine);
                 }
                    jsonResponse ={
                        status: 'Success', 
                        data: rows[0],
                        count: rows[1][0].totalCount,
                        invoiceAmount: rows[2][0].invoiceAmount,
                        dueAmount: rows[3][0].dueAmount
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
              logger.error("Method Name: getInvoiceReport, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
          logger.error("Method Name: getInvoiceReport, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      },
}


module.exports=report;