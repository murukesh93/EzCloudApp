/**
* @swagger 
 
 * /report/getInvoiceReport:
 *   get:
 *     tags:
 *       - report
 *     name: report
 *     summary: To get a invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: approvalAmountTo
 *         type: number
 *         format: float
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: status
 *         type: string
 *       - in: query
 *         name: invoiceNumber
 *         type: string  
 *       - in: query
 *         name: senderEmail
 *         type: string
 *       - in: query
 *         name: receiverEmail
 *         type: string 
 *       - in: query
 *         name: dueAmount
 *         type: number
 *         format: float
 *       - in: query
 *         name: supplierCompanyName
 *         type: string
 *       - in: query
 *         name: name
 *         type: string
 *       - in: query
 *         name: invoiceAmount
 *         type: number
 *         format: float
 *       - in: query
 *         name: createdFromDate
 *         type: string
 *       - in: query
 *         name: createdToDate
 *         type: string
 *       - in: query
 *         name: dueFromDate
 *         type: string
 *       - in: query
 *         name: dueToDate
 *         type: string
 *       - in: query
 *         name: invoiceFromDate
 *         type: string
 *       - in: query
 *         name: invoiceToDate
 *         type: string
 *       - in: query
 *         name: approvedBy
 *         type: integer
 *       - in: query
 *         name: is3PercentageRange
 *         type: string
 *       - in: query
 *         name: isDuplicate
 *         type: string
 *       - in: query
 *         name: approvedByRole
 *         type: string
 * 
 * 
 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 


*/


var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
const objReport=require('../dao/report');



router.get('/getInvoiceReport',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
    //     req.query.teamId,req.query.approvalAmountTo,
    //   req.query.count,req.query.offset,req.query.status,req.query.invoiceNumber, 
    //   req.query.receiverEmail,req.query.senderEmail, 
    //   req.query.dueAmount,req.query.supplierCompanyName,
    //  req.query.invoiceAmount,
     
    //  req.query.createdFromDate, req.query.createdToDate,
    //  req.query.dueFromDate, req.query.dueToDate,req.query.invoiceFromDate, req.query.invoiceToDate,
    //  req.query.approvedBy

     if(req.query.createdFromDate=='' || req.query.createdFromDate==undefined  ){
        req.query.createdFromDate="";
      }
      if(req.query.createdToDate=='' || req.query.createdToDate==undefined  ){
        req.query.createdToDate="";
      }
      if(req.query.dueFromDate=='' || req.query.dueFromDate==undefined  ){
        req.query.dueFromDate="";
      }
      if(req.query.dueToDate=='' || req.query.dueToDate==undefined  ){
        req.query.dueToDate="";
      }
      if(req.query.invoiceFromDate=='' || req.query.invoiceFromDate==undefined  ){
        req.query.invoiceFromDate="";
      }
      if(req.query.invoiceToDate=='' || req.query.invoiceToDate==undefined  ){
        req.query.invoiceToDate="";
      }

      if(req.query.approvedBy=='' || req.query.approvedBy==undefined || req.query.approvedBy<=0 ){
        req.query.approvedBy=0;
      }   
     if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
        req.query.teamId=0;
      }   
      if(req.query.approvalAmountTo=='' || req.query.approvalAmountTo==undefined || req.query.approvalAmountTo<=0 ){
        req.query.approvalAmountTo=0;
      } 
      if(req.query.status=='' || req.query.status==undefined  ){
        req.query.status="";
      } 
      if(req.query.invoiceNumber=='' || req.query.invoiceNumber==undefined  ){
        req.query.invoiceNumber="";
      }
      if(req.query.senderEmail=='' || req.query.senderEmail==undefined  ){
        req.query.senderEmail="";
      }
      if(req.query.receiverEmail=='' || req.query.receiverEmail==undefined  ){
        req.query.receiverEmail="";
      } 

      if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
        req.query.count=10;
      } 
      if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
        req.query.offset=0;
      }  
      if(req.query.supplierCompanyName=='' || req.query.supplierCompanyName==undefined  ){
        req.query.supplierCompanyName="";
      }
      if(req.query.dueAmount=='' || req.query.dueAmount==undefined){
        req.query.dueAmount=0;
      }
      if(req.query.invoiceAmount=='' || req.query.invoiceAmount==undefined){
        req.query.invoiceAmount=0;
      }
 
      
      var obj = objReport.getInvoiceReport(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 



  module.exports = router;