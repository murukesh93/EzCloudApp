const pool=require('../dao/connectionPool'); 
const logger=require('../dao/logger');
var team = {
updateTeam: function(req,res,next){ 
        try{   

 return new Promise(function(resolve, reject) {   
    logger.info("Method Name: updateTeam, Input Data: "+JSON.stringify(req.body));
     var query = "CALL spUpdateTeam(?,?,?,?,?)";  
     var param = [req.body.teamId,req.body.autoApproval,req.body.invoiceSenderEmail,
        req.body.companyLogo,req.body.companyName];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                if (rows[0][0].message=="Success" )
                {
                    jsonResponse ={
                        status: 'Success',
                        message: 'Team details saved successfully'
                    }; 
                    logger.info("Method Name: updateTeam, Message: Team details saved successfully");
                }
                else{
                    jsonResponse ={
                        status: 'Error',
                        message:"Error in update team details."
                    }; 
                }
               
                 connection.release();
                 return resolve(jsonResponse);
                      
             }
             else { 
                logger.error("Method Name: updateTeam, Error: "+err.message);
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                  
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
            
      logger.error("Method Name: updateTeam, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 
      
getTeamDetailsById: function(req,res,next){ 
        try{   
 return new Promise(function(resolve, reject) {   

     var query = "CALL spGetTeamDetailsById(?)";  
     var param = [req.query.teamId];
       
     pool.getConnection(function (err, connection) {
       connection.query(query, param, function (err, rows, fields) {
             if (!err) {
                var jsonResponse ={};
                 
                    jsonResponse ={
                        status: 'Success', 
                        data: rows[0]
                    } 
                 connection.release();
                 return resolve(jsonResponse); 
             }
             else { 
               var jsonResponse ={
                     message: err.message,
                     status: 'Error'
                 };
                 logger.error("Method Name: getTeamDetailsById, Error: "+err.message);
                 connection.release();
                 return reject(jsonResponse);
             }
                
         });
         
     });

            }) ; 
      }
        catch(ex){ 
            logger.error("Method Name: getTeamDetailsById, Error: "+ex.message);
         var result = { status: 'Error', message: ex.message }; 
         return  reject(result);  
        }
      }, 

   
};

module.exports=team;