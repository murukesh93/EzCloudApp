/**
* @swagger 

* /team/updateTeam:
*   put:
*     tags:
*       - team
*     name: team
*     summary: update a team details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             teamId:
*               type: integer
*             invoiceSenderEmail:
*               type: string
*             autoApproval:
*               type: number
*               format: float
*             companyName:
*               type: string
*             companyLogo:
*               type: string

*         required:
*           - teamId
*           - autoApproval
*           - invoiceSenderEmail

*     responses:
*       200:
*         description: Team details saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /team/getTeamDetailsById:
 *   get:
 *     tags:
 *       - team
 *     name: team
 *     summary: Get team details object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return team object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 
 */

 // Import Node modules
var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
const objTeam=require('../dao/team');

// Update the already existing team details
router.put('/updateTeam',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      // validate input fields data
      if(req.body.teamId=='' ||req.body.teamId==undefined || req.body.teamId<=0 ){
        return res.status(403).json({status:'Error',message:'teamId is required!'});
      }
      // if(req.body.autoApproval=='' ||req.body.autoApproval==undefined || req.body.autoApproval< 0 ){
      //   return res.status(403).json({status:'Error',message:'autoApproval amount is required!'});
      // }
      // Call update team method
      var obj = objTeam.updateTeam(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') { 
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result); //Method call Success 
          }
        },
        function (err) { //promise  call error 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse); //Exception error 
    } 
  }); 
  
  // Get team details using teamId
router.get('/getTeamDetailsById',jwtAuth.VerifyToken, function(req, res,next) {
    try {    // validate input fields data
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId <= 0   ){
        return res.status(403).json({status:'Error',message:'teamId is required!'});
      }
       // Call getTeamDetailsById method
      var obj = objTeam.getTeamDetailsById(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result); //Method call Success
          }
        },
        function (err) { //promise  call error 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse); //Exception error
    } 
  }); 

  module.exports = router;