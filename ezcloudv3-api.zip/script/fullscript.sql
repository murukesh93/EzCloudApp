-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for ezcloud
CREATE DATABASE IF NOT EXISTS `ezcloud` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ezcloud`;

-- Dumping structure for procedure ezcloud.saveinvoiceline
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `saveinvoiceline`(
pinvoiceLineId	int,
pinvoiceId	INT,
poperatingUnit	varchar(30),
pinvoiceNumber	varchar(30),
pinvoiceLineNumber	varchar(30),
pinvoiceLineType	varchar(30),
pinvoiceLineAmount	decimal(10,2),
paction VARCHAR(30)
)
BEGIN

IF paction="Add" THEN
   INSERT INTO tblinvoiceline(invoiceId,operatingUnit,invoiceNumber,invoiceLineNumber,invoiceLineType,invoiceLineAmount)
   VALUE(pinvoiceId,poperatingUnit,pinvoiceNumber,pinvoiceLineNumber,pinvoiceLineType,pinvoiceLineAmount);
   SELECT LAST_INSERT_ID() invoiceLineId; 
ELSE
    UPDATE tblinvoiceline SET invoiceId=pinvoiceId,operatingUnit=poperatingUnit,invoiceNumber=pinvoiceNumber,
	 invoiceLineNumber=pinvoiceLineNumber,invoiceLineType=pinvoiceLineType,invoiceLineAmount=pinvoiceLineAmount
	 WHERE invoiceLineId=pinvoiceLineId;
	 SELECT pinvoiceLineId invoiceLineId; 
END IF;

end//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spcreateinvoicedetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spcreateinvoicedetails`(
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(30),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed Boolean,
pStatus VARCHAR(25),
pinvoiceType VARCHAR(20),
pName VARCHAR(30),
pPhoneNumber VARCHAR(30),
pCreatedBy INT,
pinvoiceDate DATETIME,
psupplierSite VARCHAR(250),
ptaxNumber VARCHAR(50),
pbankAccount VARCHAR(50),
psortCode VARCHAR(50),
pswift VARCHAR(50),
piban VARCHAR(50),
psupplierAddress VARCHAR(50),
pinvoiceCurrency VARCHAR(30),
pinvoiceAmount DECIMAL(10,2),
ppaidAmount DECIMAL(10,2),
ptaxTotal DECIMAL(10,2),
pinvoiceDescription VARCHAR(500)

)
BEGIN

INSERT INTO tblinvoicedetails(invoiceNumber,senderEmail,dueDate,dueAmount,textractJson,textTractStatus,
filepath,createdDate,isDeleted,orderNumber,success,textractFailed,manualExtractFailed,status,invoiceType,name,phoneNumber,
createdBy,invoiceDate,supplierSite,taxNumber,bankAccount,sortCode,swift,iban,supplierAddress,invoiceCurrency,invoiceAmount,paidAmount,
taxTotal,invoiceDescription)
VALUES(pInvoiceNumber,pSenderEmail,pDueDate,pDueAmount,pTextractJson,pTextTractStatus,
pFilepath,NOW(),0,pOrderNumber,pSuccess,pTextractFailed,pManualExtractFailed,pStatus,pinvoiceType,pName,pPhoneNumber,pCreatedBy,
pinvoiceDate,psupplierSite,ptaxNumber,pbankAccount,psortCode,pswift,piban,psupplierAddress,pinvoiceCurrency,pinvoiceAmount,ppaidAmount,
ptaxTotal,pinvoiceDescription); 

SELECT LAST_INSERT_ID()invoiceId; 

UPDATE tblinvoicedetails SET status="Auto Approved" WHERE invoiceId=LAST_INSERT_ID() AND  status="Pending" AND 
dueAmount <= (SELECT autoApproval FROM tblteam WHERE invoiceSenderEmail=pSenderEmail);
 
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spDeleteInvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spDeleteInvoice`(pinvoiceId INT)
BEGIN
 UPDATE  tblinvoicedetails set isDeleted=1 WHERE isDeleted=0 AND invoiceId=pinvoiceId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spDeleteUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spDeleteUser`(puserId INT)
BEGIN
UPDATE tbluser SET isDeleted=1 WHERE userId=puserId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spForGetPassword
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spForGetPassword`(pemail VARCHAR(50),pnewPassword VARCHAR(500))
BEGIN
if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0) =0 then
SELECT "Invalid User" message; 
ELSE 
UPDATE tbluser SET password=pnewPassword,isDefaultPassword=1 WHERE email=pemail AND isDeleted=0;
SELECT "Success" message;
END if;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spgetdashboard
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spgetdashboard`(
 pteamId int
)
BEGIN

 
IF pteamId > 0 THEN
  
  SELECT count(invoiceId)approved FROM vwgetinvoicedetails where status="Approved" AND teamId=pteamId; 
  SELECT count(invoiceId)pending FROM vwgetinvoicedetails where status="Pending" AND teamId=pteamId; 
  SELECT count(status)totalCount,status statusName FROM vwgetinvoicedetails  where teamId=pteamId and status IS NOT null  GROUP BY status; 
 SELECT sum(totalAmount)amount,mntName  FROM vwgetinvoicedetails 
 where invCreatedDate >= DATE_SUB(NOW(),INTERVAL 1 YEAR) and totalAmount is not NULL AND  status="Approved" AND teamId=pteamId GROUP BY mntName;
ELSE
   
  SELECT count(invoiceId)approved FROM vwgetinvoicedetails where status="Approved" ; 
  SELECT count(invoiceId)pending FROM vwgetinvoicedetails where status="Pending" ; 
  SELECT count(status)totalCount,status statusName FROM vwgetinvoicedetails where status IS NOT null  GROUP BY status; 
 SELECT sum(totalAmount)amount,mntName  FROM vwgetinvoicedetails 
 where invCreatedDate >= DATE_SUB(NOW(),INTERVAL 1 YEAR) and totalAmount is not NULL AND  status="Approved"  GROUP BY mntName;
  
END IF;

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetInvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetInvoice`(pteamId INT,papprovalAmountFrom DECIMAL(10,2),
papprovalAmountTo DECIMAL(10,2),pcount int,poffset INT,pstatus VARCHAR(50),pcompanyName VARCHAR(50),pinvoiceNumber VARCHAR(30),
ptotalAmount DECIMAL(10,2),pemail  VARCHAR(30))
BEGIN

SET @SQL = "SELECT * FROM vwgetinvoicedetails where 0=0 "; 
SET @sqlCount=" SELECT count(invoiceId)totalCount FROM vwgetinvoicedetails where 0=0 ";
SET @filter="";
 
 if pteamId > 0 then
 SET @filter= CONCAT (" and teamId= " , pteamId);
 END if ;
 
 if papprovalAmountFrom > 0 then
 SET @filter= CONCAT (" and totalAmount>= " , papprovalAmountFrom );
 END if ;
 
 if papprovalAmountTo > 0 then
 SET @filter= CONCAT ( " AND totalAmount<=", papprovalAmountTo );
 END if ;
 
 
  if pinvoiceNumber <> "" then
 SET @filter= CONCAT(@filter," and invoiceNumber  like '%",pinvoiceNumber,"%'");
 END if ;
 
  if pcompanyName <> "" then
 SET @filter= CONCAT(@filter," and companyName  like '%",pcompanyName,"%'");
 END if ;
 
 if pstatus <> "" then
 SET @filter= CONCAT(@filter," and status  like '%",pstatus,"%'");
 END if ;
 
 if ptotalAmount > 0 then
 SET @filter= CONCAT ( " AND totalAmount =", ptotalAmount );
 END if ;
 
if pemail <> "" then
 SET @filter= CONCAT(@filter," and senderEmail  like '%",pemail,"%'");
 END if ;
 
SET @sqlCount=CONCAT(@sqlCount,@filter);
 
 SET @filter= CONCAT(@filter," order by invoiceId desc  LIMIT  ",pcount * poffset,",",pcount );

SET @SQL=CONCAT(@SQL,@filter);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

PREPARE stmt FROM @sqlCount;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetInvoiceDetailById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetInvoiceDetailById`(pinvoiceId INT)
BEGIN
 SELECT * FROM vwgetinvoicedetails WHERE  invoiceId=pinvoiceId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetInvoiceDetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetInvoiceDetails`()
begin
SELECT * FROM tblinvoicedetails WHERE isDeleted=0 ORDER BY invoiceId DESC LIMIT  1000;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetTeamDetailsById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetTeamDetailsById`(pteamId INT)
BEGIN
SELECT tm.teamId,tm.invoiceSenderEmail,tm.autoApproval,tm.createdDate,tm.teamType,tm.companyLogo,tm.companyName,
tm.planId,tm.createdBy,pl.planName, us.firstName,us.lastName FROM tblteam tm left JOIN tblplan pl on pl.planId=tm.planId
LEFT JOIN tbluser us ON us.userId=tm.createdBy
WHERE teamId=pteamId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetUser`(pteamId INT,pcount int,poffset INT,pemail VARCHAR(50),pcompanyName VARCHAR(50),
pfirstName VARCHAR(50),plastName VARCHAR(50))
BEGIN

SET @SQL = "SELECT * FROM vwgetuser where 0=0 "; 
SET @sqlCount=" SELECT count(userId)totalCount FROM vwgetuser where 0=0 ";
SET @filter="";
 
 if pteamId > 0 then
 SET @filter= CONCAT (" and teamId= " , pteamId);
 END if ;

if pemail <> "" then
 SET @filter= CONCAT(@filter," and email  like '%",pemail,"%'");
 END if ;

if pcompanyName <> "" then
 SET @filter= CONCAT(@filter," and companyName  like '%",pcompanyName,"%'");
 END if ;
 
if pfirstName <> "" then
 SET @filter= CONCAT(@filter," and firstName  like '%",pfirstName,"%'");
 END if ;
 
 if plastName <> "" then
 SET @filter= CONCAT(@filter," and lastName  like '%",plastName,"%'");
 END if ;
 
 
 
SET @sqlCount=CONCAT(@sqlCount,@filter);
 
 SET @filter= CONCAT(@filter," order by userId desc  LIMIT  ",pcount * poffset,",",pcount);

SET @SQL=CONCAT(@SQL,@filter);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

PREPARE stmt FROM @sqlCount;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spGetUserById
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spGetUserById`(puserId INT)
BEGIN
SELECT * FROM vwGetUser  WHERE userId=puserId;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spLogin
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spLogin`(
pemail VARCHAR(50),
ppassword VARCHAR(500)
)
BEGIN
    DECLARE puserId INT DEFAULT 0; 
    DECLARE puserRole  VARCHAR(50); 
    DECLARE papprovalAmountFrom DECIMAL(10,2); 
    DECLARE papprovalAmountTo DECIMAL(10,2); 
    DECLARE pteamId INT DEFAULT 0; 
    
SELECT us.userId,firstName,lastName,email,phoneNumber,approvalAmountFrom,approvalAmountTo,
profileLogo,userRole,"Success"message,isDefaultPassword,tm.teamId, t.companyLogo FROM tbluser us LEFT JOIN tblteammembers tm on
tm.userId=us.userId
LEFT JOIN tblteam t ON t.teamId=tm.teamId
WHERE email=pemail AND password=ppassword AND isDeleted=0;

SELECT us.userId,approvalAmountFrom,approvalAmountTo,userRole,tm.teamId INTO 
puserId,papprovalAmountFrom,papprovalAmountTo,puserRole,pteamId FROM tbluser us LEFT JOIN tblteammembers tm on
tm.userId=us.userId WHERE email=pemail AND password=ppassword AND isDeleted=0; 

if puserId > 0 AND puserRole="Team Member" then 
SELECT COUNT(invoiceId)invoiceCount FROM vwgetinvoicedetails WHERE teamId=pteamId AND totalAmount>= papprovalAmountFrom AND totalAmount <= papprovalAmountFrom;

ELSEIF puserId > 0 AND puserRole="Admin" then
SELECT COUNT(invoiceId)invoiceCount FROM vwgetinvoicedetails WHERE teamId=pteamId ;

ELSEIf  puserRole="Super Admin" then
SELECT COUNT(invoiceId)invoiceCount FROM vwgetinvoicedetails ;

ELSE 
SELECT 0 invoiceCount ;
END if;

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveInvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveInvoice`( invoiceDetails LONGTEXT )
BEGIN


    DECLARE i INT UNSIGNED DEFAULT 0;
    DECLARE v_count INT UNSIGNED DEFAULT 0 ;
    DECLARE v_current_item LONGTEXT DEFAULT NULL;
    DECLARE att_current_item LONGTEXT DEFAULT NULL;
    DECLARE  attachment LONGTEXT DEFAULT NULL;
 
    
/* DECLARE pInvoiceId INT;
DECLARE pInvoiceNumber varchar(25);
DECLARE pInvoiceDate date;
DECLARE pMessageBody varchar(100); 
DECLARE pAttachment LONGTEXT;
*/

DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;

END;
DECLARE exit handler for sqlwarning
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;
END;

START TRANSACTION;
  SET v_count=IFNULL(JSON_LENGTH(invoiceDetails), 0);
   
    WHILE i < v_count DO
     
	      SET v_current_item :=
            JSON_EXTRACT(invoiceDetails, CONCAT('$[', i, ']'));
        
        -- SET @temporal = JSON_EXTRACT(in_array, CONCAT('$[', i, ']'));
        -- SELECT REPLACE(v_current_item,'\\','') into v_current_item;
        -- SELECT REPLACE(v_current_item,'"{','{') into v_current_item;
        -- SELECT REPLACE(v_current_item,'}"','}') into v_current_item;

        SET @invNumber =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.invNumber'));
        SET @attachment =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.attachment'));
        SET @body =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.body'));
        SET @invDate =  JSON_UNQUOTE(JSON_EXTRACT(v_current_item, '$.invDate'));
        
        
        INSERT INTO tblInvoice(invoiceNumber,messageBody,invoiceDate,createdDate,isDeleted)
        VALUES(@invNumber,@body,@invDate,NOW(),0); 
        SET @invId=LAST_INSERT_ID(); 
        
        
         SET @att_count=IFNULL(JSON_LENGTH(@attachment), 0); 
         SET @j  = 0; 
		   SET @att_current_item= NULL;
		   
       
         
           WHILE @j < @att_count DO
     
	         SET @att_current_item :=
            JSON_EXTRACT(@attachment, CONCAT('$[', @j, ']'));
            
            SET @filepath = JSON_UNQUOTE(JSON_EXTRACT(@att_current_item, '$.fpath'));
            

            INSERT INTO tblAttachment (invoiceId,filepath,isDeleted)VALUES(@invId,@filepath,0);
            
             SET @j = @j + 1; 
             END WHILE;  
             

        SET i := i + 1;
    END WHILE;
 

   SELECT v_count v_count;
COMMIT;

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveInvoiceDetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveInvoiceDetails`(
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(25),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed BOOLEAN

)
BEGIN

INSERT INTO tblinvoicedetails(invoiceNumber,senderEmail,dueDate,dueAmount,textractJson,textTractStatus,
filepath,createdDate,isDeleted,orderNumber,success,textractFailed,manualExtractFailed,STATUS)
VALUES(pInvoiceNumber,pSenderEmail,pDueDate,pDueAmount,pTextractJson,pTextTractStatus,
pFilepath,NOW(),0,pOrderNumber,pSuccess,pTextractFailed,pManualExtractFailed,"Progressing"); 

SELECT LAST_INSERT_ID()invoiceId; 

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spSaveUser
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSaveUser`(
puserId	INT,
pfirstName	varchar(50),
plastName	varchar(50),
pemail	varchar(50),
ppassword	varchar(500),
pphoneNumber	varchar(50),
papprovalAmountFrom	decimal(10,2),
papprovalAmountTo	decimal(10,2),
pprofileLogo	varchar(1000),
pcreatedBy	INT,
puserRole	varchar(25),
pAction VARCHAR(25),
pinvoiceSenderEmail VARCHAR(50),
pteamType VARCHAR(50),
pcompanyLogo VARCHAR(1000),
pcompanyName VARCHAR(100),
pplanId INT,
pisDefaultPassword bool

)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @TEXT);
SELECT @full_error;
RESIGNAL;
END;
DECLARE exit handler for sqlwarning
 BEGIN
 ROLLBACK;
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, 
@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
SELECT @full_error;
RESIGNAL;
END;

START TRANSACTION;

if pAction= "Add" then

if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isdeleted=0)=0 then
INSERT INTO tbluser(firstName,lastName,email,password,phoneNumber,approvalAmountFrom,approvalAmountTo,profileLogo,createdBy,userRole,
createdDate,isDeleted,isDefaultPassword)
VALUES(pfirstName,plastName,pemail,ppassword,pphoneNumber,papprovalAmountFrom,papprovalAmountTo,pprofileLogo,pcreatedBy,puserRole,
NOW(),0,pisDefaultPassword); 

SET puserId= (select LAST_INSERT_ID());
SET @teamId= (SELECT  tm.teamId FROM tblteam tb INNER JOIN tblteammembers tm ON tm.userId= pcreatedBy  LIMIT 1 );

-- create team
if puserRole="Admin" then
INSERT INTO tblteam (invoiceSenderEmail,autoApproval,createdDate,teamType,companyLogo,companyName,planId,createdBy)
VALUES(pinvoiceSenderEmail,20,NOW(),pteamType,pcompanyLogo,pcompanyName,pplanId,pcreatedBy);
SET @teamId= (select LAST_INSERT_ID());
END if;

-- create team member
if puserRole="Admin" OR puserRole="Team Member"  then
INSERT INTO tblteammembers (teamId,userId)VALUES(@teamId,puserId);
END if;


SELECT puserId userId, "Success" message; 

ELSE
SELECT 0 userId,"Email already exist" message;
END if;

ELSE
UPDATE tbluser SET firstName= (case when pfirstName="" OR pfirstName=NULL then firstName ELSE pfirstName END),
lastName= (case when plastName="" OR plastName=NULL then lastName ELSE plastName END),
phoneNumber=(case when pphoneNumber="" OR pphoneNumber=NULL then phoneNumber ELSE pphoneNumber END),
approvalAmountFrom=(case when papprovalAmountFrom<= 0 OR papprovalAmountFrom=NULL then approvalAmountFrom ELSE papprovalAmountFrom END),
approvalAmountTo=(case when papprovalAmountTo<=0 OR papprovalAmountTo=NULL then approvalAmountTo ELSE papprovalAmountTo END),
profileLogo=(case when pphoneNumber="" OR pprofileLogo=NULL then profileLogo ELSE pprofileLogo END)
WHERE userId=puserId;

SELECT puserId userId,"Success" message; 
END if;
 
COMMIT;   
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spupdateinvoice
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spupdateinvoice`(
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(25),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed BOOLEAN,
pStatus VARCHAR(30),
pinvoiceId int
)
BEGIN
If  pinvoiceId >0 then

 update tblinvoicedetails set 
 invoiceNumber= (case when pInvoiceNumber="" OR pInvoiceNumber=NULL then invoiceNumber ELSE pInvoiceNumber END),
 senderEmail= (case when pSenderEmail="" OR pSenderEmail=NULL then senderEmail ELSE pSenderEmail END),
 dueDate= (case when pDueDate="" OR pDueDate=NULL then dueDate ELSE pDueDate END),
 dueAmount= (case when pDueAmount="" OR pDueAmount=NULL then dueAmount ELSE pDueAmount END),
 textractJson= (case when pTextractJson="" OR pTextractJson=NULL then textractJson ELSE pTextractJson END),
 textTractStatus= (case when pTextTractStatus="" OR pTextTractStatus=NULL then textTractStatus ELSE pTextTractStatus END),
 orderNumber= (case when pOrderNumber="" OR pOrderNumber=NULL then orderNumber ELSE pOrderNumber END),
 success= (case when pSuccess="" OR pSuccess=NULL then success ELSE pSuccess END),
 textractFailed= (case when pTextractFailed="" OR pTextractFailed=NULL then textractFailed ELSE pTextractFailed END),
 manualExtractFailed= (case when pManualExtractFailed="" OR pManualExtractFailed=NULL then manualExtractFailed ELSE pManualExtractFailed END),
 STATUS= (case when pStatus="" OR pStatus=NULL then STATUS ELSE pStatus END),
 filePath= (case when pFilePath="" OR pFilePath=NULL then filePath ELSE pFilePath END)
 WHERE invoiceId=pinvoiceId;
 
 else
 
 update tblinvoicedetails set 
 invoiceNumber= (case when pInvoiceNumber="" OR pInvoiceNumber=NULL then invoiceNumber ELSE pInvoiceNumber END),
 senderEmail= (case when pSenderEmail="" OR pSenderEmail=NULL then senderEmail ELSE pSenderEmail END),
 dueDate= (case when pDueDate="" OR pDueDate=NULL then dueDate ELSE pDueDate END),
 dueAmount= (case when pDueAmount="" OR pDueAmount=NULL then dueAmount ELSE pDueAmount END),
 textractJson= (case when pTextractJson="" OR pTextractJson=NULL then textractJson ELSE pTextractJson END),
 textTractStatus= (case when pTextTractStatus="" OR pTextTractStatus=NULL then textTractStatus ELSE pTextTractStatus END),
 orderNumber= (case when pOrderNumber="" OR pOrderNumber=NULL then orderNumber ELSE pOrderNumber END),
 success= (case when pSuccess="" OR pSuccess=NULL then success ELSE pSuccess END),
 textractFailed= (case when pTextractFailed="" OR pTextractFailed=NULL then textractFailed ELSE pTextractFailed END),
 manualExtractFailed= (case when pManualExtractFailed="" OR pManualExtractFailed=NULL then manualExtractFailed ELSE pManualExtractFailed END),
 STATUS= (case when pStatus="" OR pStatus=NULL then STATUS ELSE pStatus END)
  WHERE filePath=pFilePath;
 
 END if;

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spupdateinvoicedetails
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spupdateinvoicedetails`(
pInvoiceId INT,
pInvoiceNumber	varchar(25),
pSenderEmail	varchar(30),
pDueDate	VARCHAR(20),
pDueAmount	VARCHAR(20),
pTextractJson	TEXT,
pTextTractStatus	BOOLEAN,
pFilePath	VARCHAR(1000),
pOrderNumber VARCHAR(30),
pSuccess BOOLEAN,
pTextractFailed BOOLEAN,
pManualExtractFailed Boolean,
pStatus VARCHAR(25),
pinvoiceType VARCHAR(20),
pName VARCHAR(30),
pPhoneNumber VARCHAR(30),
pinvoiceDate DATETIME,
psupplierSite VARCHAR(250),
ptaxNumber VARCHAR(50),
pbankAccount VARCHAR(50),
psortCode VARCHAR(50),
pswift VARCHAR(50),
piban VARCHAR(50),
psupplierAddress VARCHAR(50),
pinvoiceCurrency VARCHAR(30),
pinvoiceAmount DECIMAL(10,2),
ppaidAmount DECIMAL(10,2),
ptaxTotal DECIMAL(10,2),
pinvoiceDescription VARCHAR(500)
)
BEGIN

update tblinvoicedetails SET 
invoiceNumber= (case when pinvoiceNumber="" OR pinvoiceNumber=NULL then invoiceNumber ELSE pinvoiceNumber END),
senderEmail=(case when pSenderEmail="" OR pSenderEmail=NULL then senderEmail ELSE pSenderEmail END),
dueDate=(case when pDueDate="" OR pDueDate=NULL then dueDate ELSE pDueDate END),
dueAmount=(case when pdueAmount<=0 OR pdueAmount=NULL then dueAmount ELSE pdueAmount END),
textractJson=(case when pTextractJson="" OR pTextractJson=NULL then textractJson ELSE pTextractJson END),
textTractStatus=(case when pTextTractStatus="" OR pTextTractStatus=NULL then textTractStatus ELSE pTextTractStatus END),
filepath=(case when pFilepath="" OR pFilepath=NULL then filepath ELSE pFilepath END),
orderNumber=(case when pOrderNumber="" OR pOrderNumber=NULL then orderNumber ELSE pOrderNumber END),
success=(case when pSuccess="" OR pSuccess=NULL then success ELSE pSuccess END),
textractFailed=(case when pTextractFailed="" OR pTextractFailed=NULL then textractFailed ELSE pTextractFailed END),
manualExtractFailed=(case when pManualExtractFailed="" OR pManualExtractFailed=NULL then manualExtractFailed ELSE pManualExtractFailed END),
status=(case when PStatus="" OR PStatus=NULL then status ELSE PStatus END),
invoiceType=(case when pInvoiceType="" OR pInvoiceType=NULL then invoiceType ELSE pInvoiceType END),
name=(case when pName="" OR pName=NULL then name ELSE pName END),
phoneNumber=(case when pPhoneNumber="" OR pPhoneNumber=NULL then phoneNumber ELSE pPhoneNumber END),
invoiceDate=(case when pinvoiceDate="" OR pinvoiceDate=NULL then invoiceDate ELSE pinvoiceDate END),
supplierSite=(case when psupplierSite="" OR psupplierSite=NULL then supplierSite ELSE psupplierSite END),
taxNumber=(case when ptaxNumber="" OR ptaxNumber=NULL then taxNumber ELSE ptaxNumber END),
bankAccount=(case when pbankAccount="" OR pbankAccount=NULL then bankAccount ELSE pbankAccount END),
sortCode=(case when psortCode="" OR psortCode=NULL then sortCode ELSE psortCode END),
swift=(case when pswift="" OR pswift=NULL then swift ELSE pswift END),
iban=(case when piban="" OR piban=NULL then iban ELSE piban END),
supplierAddress=(case when psupplierAddress="" OR psupplierAddress=NULL then supplierAddress ELSE psupplierAddress END),
invoiceCurrency=(case when pinvoiceCurrency="" OR pinvoiceCurrency=NULL then invoiceCurrency ELSE pinvoiceCurrency END),
invoiceAmount=(case when pinvoiceAmount <=0 OR pinvoiceAmount=NULL then invoiceAmount ELSE pinvoiceAmount END),
paidAmount=(case when ppaidAmount <=0 OR ppaidAmount=NULL then paidAmount ELSE ppaidAmount END),
taxTotal=(case when ptaxTotal <=0 OR ptaxTotal=NULL then taxTotal ELSE ptaxTotal END),
invoiceDescription=(case when pinvoiceDescription ="" OR pinvoiceDescription=NULL then invoiceDescription ELSE pinvoiceDescription END)
WHERE invoiceId=pInvoiceId; 

SELECT pInvoiceId invoiceId; 

END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdateInvoiceStatus
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdateInvoiceStatus`(pinvoiceId INT,pactionBy INT,pstatus	varchar(25))
BEGIN
UPDATE tblinvoicedetails SET STATUS=pstatus,actionBy=pactionBy,actionDate=NOW() WHERE invoiceId=pinvoiceId;
SELECT "Success" message;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdatePassword
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdatePassword`(pemail VARCHAR(50),poldpassword VARCHAR(500),pnewPassword VARCHAR(500))
BEGIN
if (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0) =0 then
SELECT "Invalid User" message;

ELSEIF (SELECT COUNT(userId) FROM tbluser WHERE email=pemail AND isDeleted=0 AND PASSWORD=poldpassword) =0 then
SELECT "Invalid Credential" message;

ELSE 
UPDATE tbluser SET password=pnewPassword,isDefaultPassword=0 WHERE email=pemail AND isDeleted=0 AND password=poldpassword;
SELECT "Success" message;
END if;
END//
DELIMITER ;

-- Dumping structure for procedure ezcloud.spUpdateTeam
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `spUpdateTeam`(pteamId INT,pautoApproval DECIMAL (10,2),pinvoiceSenderEmail VARCHAR(50),
pcompanyLogo VARCHAR(1000),pcompanyName VARCHAR(100))
BEGIN
UPDATE tblteam SET
invoiceSenderEmail= (case when pinvoiceSenderEmail="" OR pinvoiceSenderEmail=NULL then invoiceSenderEmail ELSE pinvoiceSenderEmail END),
autoApproval=(case when pautoApproval<=0 OR pautoApproval=NULL then autoApproval ELSE pautoApproval END),
companyLogo= (case when pcompanyLogo="" OR pcompanyLogo=NULL then companyLogo ELSE pcompanyLogo END),
companyName= (case when pcompanyName="" OR pcompanyName=NULL then companyName ELSE pcompanyName END)

WHERE teamId=pteamId;
SELECT "Success" message;
END//
DELIMITER ;

-- Dumping structure for table ezcloud.tblattachment
CREATE TABLE IF NOT EXISTS `tblattachment` (
  `attachmentId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceId` int(11) DEFAULT NULL,
  `filepath` varchar(1000) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`attachmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblattachment: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblattachment` DISABLE KEYS */;
INSERT IGNORE INTO `tblattachment` (`attachmentId`, `invoiceId`, `filepath`, `isDeleted`) VALUES
	(19, 13, 'inv#123.pdf', 0),
	(20, 13, 'inv#123_1.pdf', 0);
/*!40000 ALTER TABLE `tblattachment` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblinvoice
CREATE TABLE IF NOT EXISTS `tblinvoice` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(25) DEFAULT NULL,
  `invoiceDate` date DEFAULT NULL,
  `messageBody` text DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblinvoice: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblinvoice` DISABLE KEYS */;
INSERT IGNORE INTO `tblinvoice` (`invoiceId`, `invoiceNumber`, `invoiceDate`, `messageBody`, `createdDate`, `isDeleted`) VALUES
	(13, '#123', '2020-08-11', 'data', '2020-08-19 16:15:34', 0),
	(14, '#124', '2020-08-11', 'data', '2020-08-19 16:15:34', 0);
/*!40000 ALTER TABLE `tblinvoice` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblinvoicedetails
CREATE TABLE IF NOT EXISTS `tblinvoicedetails` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(25) DEFAULT NULL,
  `senderEmail` varchar(30) DEFAULT NULL,
  `dueDate` varchar(20) DEFAULT NULL,
  `dueAmount` varchar(20) DEFAULT NULL,
  `textractJson` text DEFAULT NULL,
  `textTractStatus` tinyint(1) DEFAULT NULL,
  `filePath` varchar(1000) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  `orderNumber` varchar(25) DEFAULT NULL,
  `success` tinyint(4) DEFAULT NULL,
  `textractFailed` tinyint(4) DEFAULT NULL,
  `manualExtractFailed` tinyint(4) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `invoiceType` varchar(25) DEFAULT NULL,
  `actionBy` int(11) DEFAULT NULL,
  `actionDate` datetime DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `invoiceDate` datetime DEFAULT NULL,
  `supplierSite` varchar(250) DEFAULT NULL,
  `taxNumber` varchar(50) DEFAULT NULL,
  `bankAccount` varchar(50) DEFAULT NULL,
  `sortCode` varchar(50) DEFAULT NULL,
  `swift` varchar(50) DEFAULT NULL,
  `iban` varchar(50) DEFAULT NULL,
  `supplierAddress` varchar(500) DEFAULT NULL,
  `invoiceCurrency` varchar(10) DEFAULT NULL,
  `invoiceAmount` decimal(10,2) DEFAULT NULL,
  `paidAmount` decimal(10,2) DEFAULT NULL,
  `taxTotal` decimal(10,2) DEFAULT NULL,
  `invoiceDescription` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblinvoicedetails: ~14 rows (approximately)
/*!40000 ALTER TABLE `tblinvoicedetails` DISABLE KEYS */;
INSERT IGNORE INTO `tblinvoicedetails` (`invoiceId`, `invoiceNumber`, `senderEmail`, `dueDate`, `dueAmount`, `textractJson`, `textTractStatus`, `filePath`, `createdDate`, `isDeleted`, `orderNumber`, `success`, `textractFailed`, `manualExtractFailed`, `status`, `invoiceType`, `actionBy`, `actionDate`, `name`, `phoneNumber`, `createdBy`, `invoiceDate`, `supplierSite`, `taxNumber`, `bankAccount`, `sortCode`, `swift`, `iban`, `supplierAddress`, `invoiceCurrency`, `invoiceAmount`, `paidAmount`, `taxTotal`, `invoiceDescription`) VALUES
	(10, '57755', 'murukeshs@apptomate.co', '2020-12-17', '28', 'ddd', 1, 'wwwww', '2020-09-11 15:40:47', 1, '44444ord', 1, 1, 1, 'Approved', 'Manual', 1, '2020-10-06 13:05:23', 'murukesh', '4445444', NULL, '2020-10-20 00:00:00', 'apptomate.co', '23747464444', '2364664647', '4647', 'GGG222GGT', NULL, 'Chennai', '$', 20.00, 10.00, 5.00, 'Test invoice'),
	(11, '123', 'murukeshs@apptomate.co', '2020-09-09', '33', '', 1, '', '2020-09-11 15:41:23', 0, '333', 1, 0, 1, 'Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 100.00, 10.00, 0.00, NULL),
	(12, 'inv777', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:56:23', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 200.00, 10.00, 0.00, NULL),
	(13, 'inv777', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:57:20', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 300.00, 20.00, 0.00, NULL),
	(14, 'inv779', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 12:57:42', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 400.00, 30.00, 0.00, NULL),
	(15, 'inv780', 'murukeshs@apptomate.co', '2020-09-10', '10', '', 1, 'test.pdf', '2020-09-16 13:05:14', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 200.00, 50.00, 0.00, NULL),
	(16, 'S123', 'murukeshs@apptomate.co', '2020-11-10', '50', '{}', 1, 'testpath1.pdf', '2020-10-16 15:13:09', 0, 'O123', 1, 1, 1, 'Approved', 'PO', NULL, NULL, 'Apptomate', '8870240610', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 500.00, 60.00, 0.00, NULL),
	(17, 'Inv17', 'murukeshs@apptomate.co', '2020-11-11', '20', '{}', 1, '17.pdf', '2020-10-16 15:19:47', 0, 'O17', 1, 1, 1, 'Pending', 'PO', NULL, NULL, 'Apptomate Digital', '8667749365', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL),
	(18, 'S123', 'murukeshs@apptomate.co', '2020-11-10', '50', '{}', 1, 'testpath1.pdf', '2020-10-16 15:26:31', 0, 'O123', 0, 0, 1, 'Pending', 'PO', NULL, NULL, 'Apptomate', '8870240610', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 800.00, 70.00, 0.00, NULL),
	(19, 'inv45', 'murukeshs@apptomate.co', '2020/11/11', '45', '', 1, '', '2020-11-03 15:21:16', 0, 'ord1', 1, 0, 0, 'Pending', 'Non-PO', NULL, NULL, '', '', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL),
	(20, 'inv45', 'murukeshs@apptomate.co', '2020/11/11', '4', '', 1, '', '2020-11-03 15:21:57', 0, 'ord1', 1, 0, 0, 'Auto Approved', 'Non-PO', NULL, NULL, '', '', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 100.00, NULL, 0.00, NULL),
	(21, 'inv45', 'murukeshs@apptomate.co1', '2020/11/11', '4', '', 1, '', '2020-11-03 15:35:18', 0, 'ord1', 1, 0, 0, 'Pending', 'Non-PO', NULL, NULL, '', '', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL),
	(22, 'inv456', 'apptomate.co', '2020-12-25', '200', '', 1, 'path.pdf', '2020-12-16 13:16:17', 0, 'ord123', 1, 1, 1, 'Auto Approved', 'Manual', NULL, NULL, 'murukesh kumar', '8870240610', 5, '2020-12-21 00:00:00', 'apptomate.com', 'tax1233', 'b1234', 'srt45', 'swft1233', 'iba123', 'Dindigul', '$', 30.00, 10.00, 10.50, 'Descri'),
	(23, 'inv4545', 'string', 'string', 'string', 'string', 1, 'inv4544.pdf', '2020-12-23 15:45:28', 0, '1234', 1, 1, 1, 'Pending', 'string', NULL, NULL, 'string', 'string', 0, '0000-00-00 00:00:00', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 0.00, 0.00, 0.00, 'string');
/*!40000 ALTER TABLE `tblinvoicedetails` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblinvoiceline
CREATE TABLE IF NOT EXISTS `tblinvoiceline` (
  `invoiceLineId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceId` int(11) DEFAULT NULL,
  `operatingUnit` varchar(30) DEFAULT NULL,
  `invoiceNumber` varchar(30) DEFAULT NULL,
  `invoiceLineNumber` varchar(30) DEFAULT NULL,
  `invoiceLineType` varchar(30) DEFAULT NULL,
  `invoiceLineAmount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`invoiceLineId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblinvoiceline: ~4 rows (approximately)
/*!40000 ALTER TABLE `tblinvoiceline` DISABLE KEYS */;
INSERT IGNORE INTO `tblinvoiceline` (`invoiceLineId`, `invoiceId`, `operatingUnit`, `invoiceNumber`, `invoiceLineNumber`, `invoiceLineType`, `invoiceLineAmount`) VALUES
	(1, 23, NULL, 'string', 'string', NULL, 0.00),
	(2, 23, NULL, 'string', 'string', NULL, 0.00),
	(3, 23, 'string', 'string', 'string', 'string', 0.00),
	(4, 22, 'Unit 1', 'www', '3344', 'Type1', 10.00);
/*!40000 ALTER TABLE `tblinvoiceline` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblplan
CREATE TABLE IF NOT EXISTS `tblplan` (
  `planId` int(11) NOT NULL AUTO_INCREMENT,
  `planName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`planId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblplan: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblplan` DISABLE KEYS */;
INSERT IGNORE INTO `tblplan` (`planId`, `planName`) VALUES
	(1, 'Free'),
	(2, 'Premium');
/*!40000 ALTER TABLE `tblplan` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblteam
CREATE TABLE IF NOT EXISTS `tblteam` (
  `teamId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceSenderEmail` varchar(50) DEFAULT NULL,
  `autoApproval` decimal(10,2) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `teamType` varchar(25) DEFAULT NULL,
  `companyLogo` varchar(1000) DEFAULT NULL,
  `companyName` varchar(100) DEFAULT NULL,
  `planId` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`teamId`),
  UNIQUE KEY `invoiceSenderEmail` (`invoiceSenderEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblteam: ~4 rows (approximately)
/*!40000 ALTER TABLE `tblteam` DISABLE KEYS */;
INSERT IGNORE INTO `tblteam` (`teamId`, `invoiceSenderEmail`, `autoApproval`, `createdDate`, `teamType`, `companyLogo`, `companyName`, `planId`, `createdBy`) VALUES
	(1, 'murukeshs@apptomate.co', 10.00, '2020-10-01 14:53:09', NULL, 'apptomate.png', 'Apptomate', NULL, NULL),
	(3, 'smith@apptomate.co', 20.00, '2020-12-16 15:42:08', 'Created By Admin', 'logo1.png', 'Digi', 2, 1),
	(4, 'paul@gmail.com', 20.00, '2020-12-16 15:51:52', 'Open Registration', 'logo.png', 'paul pvt', 1, NULL),
	(5, 'string', 20.00, '2021-01-21 18:02:11', 'Open Registration', 'string', 'string', 0, NULL),
	(6, 'murukeshhh@gmail.com', 20.00, '2021-01-23 15:34:31', 'Created By Admin', '', 'Apptomate@123', 1, 1),
	(8, 'murukeshhh@gmail.com1', 20.00, '2021-01-23 15:38:14', 'Created By Admin', '', 'Apptomate@123', 1, 1);
/*!40000 ALTER TABLE `tblteam` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tblteammembers
CREATE TABLE IF NOT EXISTS `tblteammembers` (
  `memberId` int(11) NOT NULL AUTO_INCREMENT,
  `teamId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tblteammembers: ~6 rows (approximately)
/*!40000 ALTER TABLE `tblteammembers` DISABLE KEYS */;
INSERT IGNORE INTO `tblteammembers` (`memberId`, `teamId`, `userId`) VALUES
	(1, 1, 4),
	(2, 1, 5),
	(3, 3, 7),
	(4, 4, 8),
	(5, NULL, 10),
	(6, 5, 11),
	(7, 6, 12),
	(8, 8, 14),
	(9, 4, 15);
/*!40000 ALTER TABLE `tblteammembers` ENABLE KEYS */;

-- Dumping structure for table ezcloud.tbluser
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `phoneNumber` varchar(50) DEFAULT NULL,
  `approvalAmountFrom` decimal(10,2) DEFAULT NULL,
  `approvalAmountTo` decimal(10,2) DEFAULT NULL,
  `profileLogo` varchar(1000) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `userRole` varchar(25) DEFAULT NULL,
  `isDefaultPassword` tinyint(1) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `createdBy` (`createdBy`),
  CONSTRAINT `tbluser_ibfk_1` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`),
  CONSTRAINT `tbluser_ibfk_2` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`),
  CONSTRAINT `tbluser_ibfk_3` FOREIGN KEY (`createdBy`) REFERENCES `tbluser` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ezcloud.tbluser: ~8 rows (approximately)
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT IGNORE INTO `tbluser` (`userId`, `firstName`, `lastName`, `email`, `password`, `phoneNumber`, `approvalAmountFrom`, `approvalAmountTo`, `profileLogo`, `createdBy`, `createdDate`, `userRole`, `isDefaultPassword`, `isDeleted`) VALUES
	(1, 'murukesh', 'kumar', 'murukeshs@apptomate.co', 'e99545001372179a734b38d383d3ccdf', '8870240610', 1.00, 1000000.00, '', NULL, '2020-09-28 13:27:40', 'Super Admin', 1, 0),
	(4, 'test', 'user 1', 'testuser1@gmail.com', 'e99545001372179a734b38d383d3ccdf', '8870240611', 1.00, 2000.00, '', 1, '2020-10-01 14:53:09', 'Admin', 1, 0),
	(5, 'team', 'user 1', 'teamuser1@gmail.com', 'f6e8d3d4bfa4e0b504a52b7da554b764d1dd38cdb0df608f23c4d6fa0f55b359', '48849933', 1.00, 50.00, '', 4, '2020-10-01 14:56:47', 'Team Member', 1, 0),
	(7, 'paul', 'smith', 'smith@apptomate.co', 'e99545001372179a734b38d383d3ccdf', '980877666', 1.00, 100.00, 'logo1.png', 1, '2020-12-16 15:42:08', 'Admin', 1, 0),
	(8, 'smith', 'paul', 'paul@gmail.com', 'e99545001372179a734b38d383d3ccdf', '9843383', 1.00, 200.00, 'logo.png', NULL, '2020-12-16 15:51:52', 'Admin', 1, 0),
	(9, 'super', 'admin 1', 'superadmin@gmail.com', 'c5b07183baa2863f49fc1c9372773199', '887887767', NULL, NULL, 'logo1.png', 1, '2020-12-16 16:03:02', 'Super Admin', 1, 0),
	(10, 'murukesh', 'kumar', 'murukeshhh@gmail.com', 'e99545001372179a734b38d383d3ccdf', '8879240610', 10.00, 1000.00, '', 1, '2021-01-07 20:36:26', 'Team Member', 1, 1),
	(11, 'string', 'string', 'string', '1c23179e8ec79f848b5f9b604bfbd789', 'string', 0.00, 0.00, 'string', NULL, '2021-01-21 18:02:11', 'Admin', 0, 0),
	(12, 'string', 'string', 'murukeshhh@gmail.com', 'e99545001372179a734b38d383d3ccdf', 'string', 10.00, 10000.00, 'string', 1, '2021-01-23 15:34:31', 'Admin', 1, 1),
	(14, 'string', 'string', 'murukeshhh@gmail.com', 'e99545001372179a734b38d383d3ccdf', 'string', 10.00, 10000.00, 'string', 1, '2021-01-23 15:38:14', 'Admin', 1, 1),
	(15, 'string', 'string', 'murukeshhh@gmail.com', 'e99545001372179a734b38d383d3ccdf', 'string', 10.00, 11110.00, '', 8, '2021-01-23 15:40:56', 'Team Member', 1, 0);
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;

-- Dumping structure for view ezcloud.vwgetinvoicedetails
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vwgetinvoicedetails` (
	`invoiceId` INT(11) NOT NULL,
	`invoiceNumber` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`senderEmail` VARCHAR(30) NULL COLLATE 'utf8mb4_general_ci',
	`dueDate` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`dueAmount` DECIMAL(10,2) NULL,
	`textractJson` TEXT NULL COLLATE 'utf8mb4_general_ci',
	`textTractStatus` TINYINT(1) NULL,
	`filePath` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`invCreatedDate` DATETIME NULL,
	`orderNumber` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`success` TINYINT(4) NULL,
	`textractFailed` TINYINT(4) NULL,
	`manualExtractFailed` TINYINT(4) NULL,
	`status` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceType` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`actionBy` INT(11) NULL,
	`actionDate` DATETIME NULL,
	`name` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceDate` DATETIME NULL,
	`supplierSite` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`taxNumber` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`bankAccount` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`sortCode` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`swift` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`iban` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`supplierAddress` VARCHAR(500) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceCurrency` VARCHAR(10) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceAmount` DECIMAL(10,2) NULL,
	`paidAmount` DECIMAL(10,2) NULL,
	`taxTotal` DECIMAL(10,2) NULL,
	`totalAmount` DECIMAL(11,2) NULL,
	`invoiceDescription` VARCHAR(500) NULL COLLATE 'utf8mb4_general_ci',
	`phoneNumber` VARCHAR(30) NULL COLLATE 'utf8mb4_general_ci',
	`mntName` VARCHAR(32) NULL COLLATE 'utf8mb4_general_ci',
	`invoiceYear` INT(4) NULL,
	`invoiceLine` MEDIUMTEXT NULL COLLATE 'utf8mb4_general_ci',
	`invoiceSenderEmail` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`teamId` INT(11) NULL,
	`autoApproval` DECIMAL(10,2) NULL,
	`teamCreatedDate` DATETIME NULL,
	`teamType` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`companyLogo` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`companyName` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci',
	`teamCreatedBy` INT(11) NULL
) ENGINE=MyISAM;

-- Dumping structure for view ezcloud.vwgetuser
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vwgetuser` (
	`userId` INT(11) NOT NULL,
	`firstName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`lastName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`email` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`phoneNumber` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`approvalAmountFrom` DECIMAL(10,2) NULL,
	`approvalAmountTo` DECIMAL(10,2) NULL,
	`profileLogo` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`userRole` VARCHAR(25) NULL COLLATE 'utf8mb4_general_ci',
	`createdBy` INT(11) NULL,
	`createdDate` DATETIME NULL,
	`cfirstName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`clastName` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`cemail` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`teamId` INT(11) NULL,
	`companyLogo` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`companyName` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci',
	`search` VARCHAR(178) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view ezcloud.vwgetinvoicedetails
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vwgetinvoicedetails`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwgetinvoicedetails` AS select `inv`.`invoiceId` AS `invoiceId`,`inv`.`invoiceNumber` AS `invoiceNumber`,
 `inv`.`senderEmail` AS `senderEmail`,`inv`.`dueDate` AS `dueDate`,cast(case when (`inv`.`dueAmount` = '' or `inv`.`dueAmount` = NULL)
  then 0 else `inv`.`dueAmount` end as decimal(10,2)) AS `dueAmount`,`inv`.`textractJson` AS `textractJson`,`inv`.`textTractStatus` AS
   `textTractStatus`,`inv`.`filePath` AS `filePath`,`inv`.`createdDate` AS `invCreatedDate`,`inv`.`orderNumber` AS `orderNumber`,
	`inv`.`success` AS `success`,`inv`.`textractFailed` AS `textractFailed`,`inv`.`manualExtractFailed` AS `manualExtractFailed`,
	`inv`.`status` AS `status`,`inv`.`invoiceType` AS `invoiceType`,`inv`.`actionBy` AS `actionBy`,`inv`.`actionDate` AS `actionDate`,
	`inv`.`name` AS `name`,`inv`.`invoiceDate` AS `invoiceDate`,`inv`.`supplierSite` AS `supplierSite`,`inv`.`taxNumber` AS `taxNumber`,
	`inv`.`bankAccount` AS `bankAccount`,`inv`.`sortCode` AS `sortCode`,`inv`.`swift` AS `swift`,`inv`.`iban` AS `iban`,
	`inv`.`supplierAddress` AS `supplierAddress`,`inv`.`invoiceCurrency` AS `invoiceCurrency`,`inv`.`invoiceAmount` AS `invoiceAmount`,
	`inv`.`paidAmount` AS `paidAmount`,`inv`.`taxTotal` AS `taxTotal`,`inv`.`taxTotal` + `inv`.`invoiceAmount` AS `totalAmount`,
	`inv`.`invoiceDescription` AS `invoiceDescription`,`inv`.`phoneNumber` AS `phoneNumber`,DATE_FORMAT(inv.createdDate,'%b')mntName,
	(select concat('[',group_concat(json_object('invoiceLineId',`tblinvoiceline`.`invoiceLineId`,'operatingUnit',`tblinvoiceline`.`operatingUnit`,'invoiceNumber',`tblinvoiceline`.`invoiceNumber`,'invoiceId',`tblinvoiceline`.`invoiceId`,'invoiceLineNumber',`tblinvoiceline`.`invoiceLineNumber`,'invoiceLineType',`tblinvoiceline`.`invoiceLineType`,'invoiceLineAmount',`tblinvoiceline`.`invoiceLineAmount`) separator ','),']') from `tblinvoiceline` where `tblinvoiceline`.`invoiceId` = `inv`.`invoiceId`) AS `invoiceLine`,`tm`.`invoiceSenderEmail` AS `invoiceSenderEmail`,`tm`.`teamId` AS `teamId`,`tm`.`autoApproval` AS `autoApproval`,`tm`.`createdDate` AS `teamCreatedDate`,`tm`.`teamType` AS `teamType`,`tm`.`companyLogo` AS `companyLogo`,`tm`.`companyName` AS `companyName`,`tm`.`createdBy` AS `teamCreatedBy` from (`tblinvoicedetails` `inv` left join `tblteam` `tm` on(`tm`.`invoiceSenderEmail` = `inv`.`senderEmail`)) where `inv`.`isDeleted` = 0 ;

-- Dumping structure for view ezcloud.vwgetuser
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vwgetuser`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwgetuser` AS SELECT us.userId,us.firstName,us.lastName,us.email,us.phoneNumber,us.approvalAmountFrom,us.approvalAmountTo,
us.profileLogo,us.userRole,us.createdBy,us.createdDate, cr.firstName cfirstName,cr.lastName clastName,
cr.email cemail,mem.teamId, tm.companyLogo,tm.companyName, CONCAT(us.firstName,"_",us.lastName,"_",us.email,"_",us.userRole)search FROM tbluser us 
LEFT JOIN tbluser cr ON cr.userId=us.createdBy
LEFT JOIN tblteammembers mem ON mem.userId=us.userId 
LEFT JOIN tblteam tm ON tm.teamId=mem.teamId
 WHERE us.isDeleted=0 ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
