/**
* @swagger 
* /supplier/sendSupplierRequest:
*   post:
*     tags:
*       - supplier
*     name: supplier
*     summary: To send a supplier request
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             teamId:
*               type: integer
*             supplierEmail:
*               type: string   
*             requestedBy:
*               type: integer 

*         required:
*           - teamId
*           - supplierEmail 
*           - requestedBy
 
*     responses:
*       200:
*         description: Request sent successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /supplier/updateSupplierStatus:
*   put:
*     tags:
*       - supplier
*     name: supplier
*     summary: Status updated successfully
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             requestId:
*               type: integer
*             status:
*               type: string   

*         required:
*           - requestId
*           - status 
 
*     responses:
*       200:
*         description: Request sent successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /supplier/getSupplierRequest:
 *   get:
 *     tags:
 *       - supplier
 *     name: supplier
 *     summary: To get a supplier request object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: requestStatus
 *         type: string
 *       - in: query
 *         name: companyName
 *         type: string
 *       - in: query
 *         name: requestedName
 *         type: string
 *       - in: query
 *         name: requestId
 *         type: integer
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: supplierEmail
 *         type: string
 *       - in: query
 *         name: supplierCompanyName
 *         type: string
 * 
 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

* /supplier/sendPixelatedEmail:
*   post:
*     tags:
*       - supplier
*     name: supplier
*     summary: To send a email notification to supplier
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             teamId:
*               type: integer
*             supplierEmail:
*               type: string   
*             requesterEmail:
*               type: string  
*             invoiceNumber:
*               type: string  
*         required:
*           - teamId
*           - supplierEmail 
 
*     responses:
*       200:
*         description: Request sent successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


 * /supplier/deleteSupplierRequest:
 *   delete:
 *     tags:
 *       - supplier
 *     name: supplier
 *     summary: Delete a supplier request
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: requestId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 


*/


var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
const objSupplier=require('../dao/supplier');
var objTeam=require('../dao/team');
var objUser=require('../dao/user');
var objConfig=require('../appconfig/config');
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');

  router.post('/sendSupplierRequest',jwtAuth.VerifyToken, function(req, res,next) {
    try {  

        if(req.body.teamId=='' ||req.body.teamId==undefined || req.body.teamId <=0 ){
            return res.status(403).json({status:'Error',message:'teamId is required!'});
          }
          if(req.body.supplierEmail=='' ||req.body.supplierEmail==undefined ){
            return res.status(403).json({status:'Error',message:'supplierEmail is required!'});
          }

          if(req.body.requestedBy=='' ||req.body.requestedBy==undefined || req.body.requestedBy <=0 ){
            return res.status(403).json({status:'Error',message:'requestedBy is required!'});
          }

      var obj = objSupplier.sendSupplierRequest(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 


router.get('/getSupplierRequest',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
        req.query.teamId=0;
      }  
      if(req.query.requestId=='' || req.query.requestId==undefined || req.query.requestId<=0 ){
        req.query.requestId=0;
      }    
      if(req.query.requestStatus=='' || req.query.requestStatus==undefined  ){
        req.query.requestStatus="";
      }
      if(req.query.companyName=='' || req.query.companyName==undefined  ){
        req.query.companyName="";
      }
      if(req.query.requestedName=='' || req.query.requestedName==undefined  ){
        req.query.requestedName="";
      }
      if(req.query.supplierEmail=='' || req.query.supplierEmail==undefined  ){
        req.query.supplierEmail="";
      }
      if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
        req.query.count=10;
      } 
      if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
        req.query.offset=0;
      }  

        var obj = objSupplier.getSupplierRequest(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });

  
router.put('/updateSupplierStatus',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.body.requestId=='' ||req.body.requestId==undefined || req.body.requestId <=0 ){
            return res.status(403).json({status:'Error',message:'requestId is required!'});
          }
          if(req.body.status=='' ||req.body.status==undefined ){
            return res.status(403).json({status:'Error',message:'status is required!'});
          }
      var obj = objSupplier.updateSupplierStatus(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });
  
  
  router.post('/sendPixelatedEmail',jwtAuth.VerifyToken,async function(req, res,next) {
    try {  

        if(req.body.teamId=='' ||req.body.teamId==undefined || req.body.teamId <=0 ){
            return res.status(403).json({status:'Error',message:'teamId is required!'});
          }
          if(req.body.supplierEmail=='' ||req.body.supplierEmail==undefined ){
            return res.status(403).json({status:'Error',message:'supplierEmail is required!'});
          }

          if(req.body.invoiceNumber=='' || req.body.invoiceNumber==undefined || req.body.invoiceNumber=='N/A' ){
           // return res.status(403).json({status:'Error',message:'invoiceNumber is required!'});
           req.body.invoiceNumber='';
          }

          if(req.body.requesterEmail=='' || req.body.requesterEmail==undefined  ){
            return res.status(403).json({status:'Error',message:'requesterEmail is required!'});
          }
          req.query.email=req.body.supplierEmail;
          req.query.teamId=req.body.teamId;
          var companyData=await objTeam.getTeamDetailsById(req,res,next);
          var companyName= companyData.data[0].companyName;
          var companyLogo=companyData.data[0].companyLogo;
          var invoiceSenderEmail=companyData.data[0].invoiceSenderEmail;
          var objUserDetails=await objUser.getUserByEmail(req,res); 
          console.log(objUserDetails)
          req.body.companyName=companyName;  
          req.body.firstName='';
          if(objUserDetails.data !=undefined){
            req.body.firstName=objUserDetails.data.firstName;
          } 
          req.body.subject='Issue with Invoice Submission – Resubmission Request';

          invoiceResubmissionRequestEmail(req,res);

          // var obj = await objCommon.sendEmail(objConfig.fromEmail,req.body.supplierEmail,'EZ Cloud Invoice Issue',
          // `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
          // <div></br></br>`+ `<p></br></br>Hi <br><br> Please be informed that one of your invoices provided by you to `+invoiceSenderEmail+` seems to be pixelated, corrupted or poor in terms of quality.</p>
          // <br> Thanks <br> EZ Cloud Team </div>`);

          var result = { status: 'Success', message:"Email sent successfully" };
          return res.status(200).json(result);
      
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 


router.delete('/deleteSupplierRequest',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.query.requestId=='' || req.query.requestId==undefined || req.query.requestId<=0 ){
            return res.status(403).json({status:'Error',message:'requestId is required!'}); 
        } 
       
      var obj = objSupplier.deleteSupplierRequest(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 


function invoiceResubmissionRequestEmail(req,res) {
    try {
      var filepath = __dirname + '//views//invoiceresubmissionrequest.html';
      filepath = filepath.replace('controller', '');
      filepath = path.normalize(filepath);
      fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
        if (err) {
          var result = { status: 'Error', message: err.message };
          logger.error("Method Name: invoiceResubmissionRequestEmail, Error: "+err.message); 
          return (result);
        } else {
          var template = handlebars.compile(html);
          var replacements = {
            invoiceNumber: req.body.invoiceNumber,
            companyName: req.body.companyName,
            loginURL: objConfig.adminUrl ,
            requesterEmail:req.body.requesterEmail,
            firstName: req.body.firstName
          };
        
          var htmlToSend = template(replacements);
          var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.supplierEmail, req.body.subject, htmlToSend);
          objSendEmail.then(
            function (result) {
              if (result.status === 'Error') {
                logger.error("Method Name: invoiceResubmissionRequestEmail, Error: "+result); 
                return (result);
              } else {
                return (result);
              }
            },
            function (err) {
              var result = { status: 'Error', message: err.message }; 
              logger.error("Method Name: invoiceResubmissionRequestEmail, Error: "+err.message); 
              return (result);
            }
          );
  
  
        }
      });
  
    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message };
      logger.error("Method Name: invoiceResubmissionRequestEmail, Error: "+ex.message); 
      return (result);
    }
  
  
  }


  module.exports = router;