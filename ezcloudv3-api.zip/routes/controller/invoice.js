/**
* @swagger 
* /invoice/createInvoice:
*   post:
*     tags:
*       - invoice
*     name: invoice
*     summary: To save invoice details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             invoiceNumber:
*               type: string
*             senderEmail:
*               type: string   
*             dueDate:
*               type: string 
*             dueAmount:
*               type: string   
*             textractJson:
*               type: string   
*             filePath:
*               type: string  
*             textTractStatus:
*               type: boolean   
*             orderNumber:
*               type: string  
*             success:
*               type: boolean  
*             textractFailed:
*               type: boolean  
*             manualExtractFaile:
*               type: boolean  
*             status:
*               type: string
*             invoiceType:
*               type: string
*             name:
*               type: string
*             phoneNumber:
*               type: string
*             createdBy:
*               type: integer 
*             invoiceDate:
*               type: datetime 
*             supplierSite:
*               type: string
*             taxNumber:
*               type: string
*             bankAccount:
*               type: string
*             sortCode:
*               type: string
*             swift:
*               type: string
*             iban:
*               type: string
*             supplierAddress:
*               type: string
*             invoiceCurrency:
*               type: string
*             invoiceAmount:
*               type: number
*               format: float
*             paidAmount:
*               type: number
*               format: float
*             taxTotal:
*               type: number
*               format: float
*             invoiceDescription:
*               type: string
*             receiverEmail:
*               type: string


*         required:
*           - invoiceNumber
*           - filepath 
 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /invoice/updateInvoice:
*   put:
*     tags:
*       - invoice
*     name: invoice
*     summary: To update invoice details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             invoiceId:
*               type: integer
*             invoiceNumber:
*               type: string
*             senderEmail:
*               type: string   
*             dueDate:
*               type: string 
*             dueAmount:
*               type: string   
*             textractJson:
*               type: string   
*             filePath:
*               type: string  
*             textTractStatus:
*               type: boolean   
*             orderNumber:
*               type: string  
*             success:
*               type: boolean  
*             textractFailed:
*               type: boolean  
*             manualExtractFaile:
*               type: boolean  
*             status:
*               type: string
*             invoiceType:
*               type: string
*             name:
*               type: string
*             phoneNumber:
*               type: string
*             invoiceDate:
*               type: datetime 
*             supplierSite:
*               type: string
*             taxNumber:
*               type: string
*             bankAccount:
*               type: string
*             sortCode:
*               type: string
*             swift:
*               type: string
*             iban:
*               type: string
*             supplierAddress:
*               type: string
*             invoiceCurrency:
*               type: string
*             invoiceAmount:
*               type: number
*               format: float
*             paidAmount:
*               type: number
*               format: float
*             taxTotal:
*               type: number
*               format: float
*             invoiceDescription:
*               type: string
*             receiverEmail:
*               type: string
*             totalAmount:
*               type: number
*               format: float
*             documentType:
*               type: string
*             updateBy:
*               type: integer
*         required:
*           - invoiceId
*           - invoiceNumber
*           - filepath 
 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


 * /invoice/getInvoiceById:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To get a invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 


* /invoice/deleteInvoice:
 *   delete:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: Delete a invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

 * /invoice/updateInvoiceStatus:
*   put:
*     tags:
*       - invoice
*     name: invoice
*     summary: update a existing invoice object status
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             invoiceId:
*               type: integer
*             status:
*               type: string

*         required:
*           - userId
*           - invoiceId
*           - status

*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /invoice/getInvoice:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To get a invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: approvalAmountFrom
 *         type: number
 *         format: float
 *       - in: query
 *         name: approvalAmountTo
 *         type: number
 *         format: float
 *       - in: query
 *         name: status
 *         type: string
 *       - in: query
 *         name: companyName
 *         type: string
 *       - in: query
 *         name: invoiceNumber
 *         type: string
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: totalAmount
 *         type: number
 *         format: float
 *       - in: query
 *         name: senderEmail
 *         type: string
 *       - in: query
 *         name: receiverEmail
 *         type: string
 *       - in: query
 *         name: approvalAmountFrom
 *         type: number
 *         format: float
 *       - in: query
 *         name: dueAmount
 *         type: number
 *         format: float
 *       - in: query
 *         name: supplierCompanyName
 *         type: string
 *       - in: query
 *         name: name
 *         type: string
 *       - in: query
 *         name: invoiceAmount
 *         type: number
 *         format: float
 *       - in: query
 *         name: supplierEmail
 *         type: string
 * 
 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 


 * /invoice/getNextInvoice:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To get a invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: approvalAmountFrom
 *         type: number
 *         format: float
 *       - in: query
 *         name: approvalAmountTo
 *         type: number
 *         format: float
 *       - in: query
 *         name: currentInvoiceId
 *         type: integer
 *       - in: query
 *         name: senderEmail
 *         type: string
 
 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 


 * /invoice/getInvoiceList:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To get a invoice list object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json

 *     responses:
 *       200:
 *        description: Return invoice object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 
* /invoice/createInvoiceLine:
*   post:
*     tags:
*       - invoice
*     name: invoice
*     summary: To create a new invoiceLine
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             invoiceId:
*               type: integer
*             operatingUnit:
*               type: string
*             invoiceLineAmount:
*               type: number
*               format: float
*             invoiceLineNumber:
*               type: string
*             invoiceLineType:
*               type: string 


*         required:
*           - invoiceId
*           - invoiceLineAmount

*     responses:
*       200:
*         description: Invoice line details saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

 

* /invoice/updateInvoiceLine:
*   put:
*     tags:
*       - invoice
*     name: invoice
*     summary: To update a invoiceLine object
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             invoiceLineId:
*               type: integer
*             invoiceId:
*               type: integer
*             operatingUnit:
*               type: string
*             invoiceLineAmount:
*               type: number
*               format: float
*             invoiceLineNumber:
*               type: string
*             invoiceLineType:
*               type: string 


*         required:
*           - invoiceId
*           - invoiceLineAmount

*     responses:
*       200:
*         description: Invoice line details saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /invoice/deleteInvoiceLine:
 *   delete:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: Delete a invoice line object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceLineId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 * 

 * /invoice/getInvoiceLine:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: select a invoice line object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceLineId
 *         type: integer
 *       - in: query
 *         name: invoiceId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 * 


* /invoice/lockInvoice:
*   post:
*     tags:
*       - invoice
*     name: invoice
*     summary: To lock a invoice object
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             invoiceId:
*               type: integer
*             lockedBy:
*               type: integer
*         required:
*           - invoiceId
*           - lockedBy

*     responses:
*       200:
*         description: Record locked successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /invoice/unLockInvoice:
 *   delete:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To release a locked invoice object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceId
 *         type: integer
 *       - in: query
 *         name: lockedBy
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Invoice unlocked successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

 * /invoice/getInvoiceFieldList:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: To get a invoice field list object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return invoice field list object.
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *

 * /invoice/saveInvoiceFieldList:
*   post:
*     tags:
*       - invoice
*     name: invoice
*     summary: To save the invoice mandatory field list
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             teamId:
*               type: integer
*             fieldList:
*               type: array
*               items:
*                   type: object
*                   properties:
*                      fieldListId:
*                       type: integer
*                      customerInvoiceFieldId:
*                       type: integer
*                      isRequired:
*                       type: integer
*                      isVisible:
*                       type: integer
*                      fieldOrder:
*                       type: integer
*                      dataFormat:
*                       type: string 

*         required:
*           - teamId
*           - fieldList

*     responses:
*       200:
*         description: Record locked successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


  * /invoice/getAudits:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: Get invoice log object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: invoiceId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Invoice log record list
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 * /invoice/saveSettings:
*   post:
*     tags:
*       - invoice
*     name: invoice
*     summary: To save a team setting details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             teamId:
*               type: integer
*             dateFormat:
*               type: string

*         required:
*           - teamId
*           - dateFormat

*     responses:
*       200:
*         description: Record saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /invoice/getSettings:
 *   get:
 *     tags:
 *       - invoice
 *     name: invoice
 *     summary: Get setting detail object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return setting object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

 * 

 */


var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
const objeInvoice=require('../dao/invoice');
const objOIC=require('../dao/oic');
const objCommon=require('../dao/common');
const objConfig=require('../appconfig/config');
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');


router.get('/getInvoiceById',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.invoiceId=='' || req.query.invoiceId==undefined || req.query.invoiceId<=0 ){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'});
      } 
     var data= jwtAuth.GetTokenData(req, res,next);
     req.query.userId=data.userId;
      var obj = objeInvoice.getInvoiceById(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  
  router.delete('/deleteInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.query.invoiceId=='' || req.query.invoiceId==undefined || req.query.invoiceId<=0 ){
            return res.status(403).json({status:'Error',message:'invoiceId is required!'}); 
        } 
       
      var obj = objeInvoice.deleteInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  
  router.put('/updateInvoiceStatus',jwtAuth.VerifyToken,async function(req, res,next) {
    try { 
   
      if(req.body.status=='' ||req.body.status==undefined ){
        return res.status(403).json({status:'Error',message:'status is required!'});
      }
      if(req.body.invoiceId=='' ||req.body.invoiceId==undefined || req.body.invoiceId <=0){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'});
      } 
     
      if(req.body.userId=='' ||req.body.userId==undefined || req.body.userId <=0){
        return res.status(403).json({status:'Error',message:'userId is required!'});
      } 
 
     var objApprove ={};
     var objUpdateStatus={};

    
     if (req.body.status=="Approved"){
  req.query.invoiceId=req.body.invoiceId;
  var objInv = await objeInvoice.getInvoiceByIdApproval(req,res);    

  req.body.invoice=objInv;
   objApprove=await objOIC.approveInvoice(req,res); 
   if(objApprove.status=="Success"){ // OIC service success
   
    objUpdateStatus = await objOIC.updateInvoiceStatus(req,res); 

    if(objUpdateStatus.status=="Success"){

     // send email notifcation to supplier 
     // if dummy supplier we did't send email notification for supplier
     if(objInv.data[0].senderEmail!=objConfig.dummySupplierEmail){
     var Logo="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png"
    if(objInv.data[0].companyLogo !="" && objInv.data[0].companyLogo !=null) {
    Logo=objInv.data[0].companyLogo;
   }
   req.body.invoiceNumber=objInv.data[0].invoiceNumber;
   req.body.subject="Your Invoice has Successfully Been Approved! - EZ Cloud";
   req.body.customerCompanyName=objInv.data[0].companyName;
   req.body.sendEmail=objInv.data[0].senderEmail;

   approvedInvoiceEmail(req,res)
//    var obj =objCommon.sendEmail(objConfig.fromEmail,objInv.data[0].senderEmail,'Acknowledgement for approved invoice',
//    `<img src="https://logoez.s3.amazonaws.com/logo_2021-03-23-07-34-19.png" alt="logo" width="200" height="50">
// <div></br></br> <p><br><br>Hi, <br> <br>  This is an acknowledged email for approved your invoice successfully to the EZ Cloud application.Your <br>
//    Invoice Id:`+objInv.data[0].invoiceId+` <br> Invoice Number:`+objInv.data[0].invoiceNumber+` <br> Customer Name:`+objInv.data[0].companyName+``
//    +`<br><br> Thanks<br>EZ Cloud Team</p></div>` );

   }
      return res.status(200).json(objUpdateStatus);
    }else{
      return res.status(403).json(objUpdateStatus);
    }
  
  }else{// OIC service failure
    return res.status(403).json(objApprove);
  } 

} 
else{ // update invoice status
  objUpdateStatus = await objOIC.updateInvoiceStatus(req,res); 
  if(objUpdateStatus.status=="Success"){
    return res.status(200).json(objUpdateStatus);
  }else{
    return res.status(403).json(objUpdateStatus);
  }

}
 
  
    } catch (ex) { 
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });  
  
router.get('/getInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
        req.query.teamId=0;
      }   
      if(req.query.approvalAmountFrom=='' || req.query.approvalAmountFrom==undefined || req.query.approvalAmountFrom<=0 ){
        req.query.approvalAmountFrom=0;
      }
      if(req.query.approvalAmountTo=='' || req.query.approvalAmountTo==undefined || req.query.approvalAmountTo<=0 ){
        req.query.approvalAmountTo=0;
      } 
      if(req.query.status=='' || req.query.status==undefined  ){
        req.query.status="";
      }
      if(req.query.companyName=='' || req.query.companyName==undefined  ){
        req.query.companyName="";
      }
      if(req.query.invoiceNumber=='' || req.query.invoiceNumber==undefined  ){
        req.query.invoiceNumber="";
      }
      if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
        req.query.count=10;
      } 
      if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
        req.query.offset=0;
      }  
      if(req.query.email=='' || req.query.email==undefined  ){
        req.query.email="";
      }
      if(req.query.supplierCompanyName=='' || req.query.supplierCompanyName==undefined  ){
        req.query.supplierCompanyName="";
      }
      
      if(req.query.totalAmount=='' || req.query.totalAmount==undefined){
        req.query.totalAmount=0;
      } 
      if(req.query.senderEmail=='' || req.query.senderEmail==undefined  ){
        req.query.senderEmail="";
      }
      if(req.query.receiverEmail=='' || req.query.receiverEmail==undefined  ){
        req.query.receiverEmail="";
      }  
      if(req.query.dueAmount=='' || req.query.dueAmount==undefined){
        req.query.dueAmount=0;
      }
      if(req.query.invoiceAmount=='' || req.query.invoiceAmount==undefined){
        req.query.invoiceAmount=0;
      }
      if(req.query.supplierEmail=='' || req.query.supplierEmail==undefined){
        req.query.supplierEmail="";
      }

      
      
      var obj = objeInvoice.getInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  
router.get('/getNextInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      // if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
      //   return res.status(403).json({status:'Error',message:'teamId is required!'}); 
      // }   
      if(req.query.approvalAmountFrom=='' || req.query.approvalAmountFrom==undefined || req.query.approvalAmountFrom<=0 ){
        req.query.approvalAmountFrom=0;
      }
      if(req.query.approvalAmountTo=='' || req.query.approvalAmountTo==undefined || req.query.approvalAmountTo<=0 ){
        req.query.approvalAmountTo=0;
      } 
      if(req.query.currentInvoiceId=='' || req.query.currentInvoiceId==undefined || req.query.currentInvoiceId<=0 ){
        return res.status(403).json({status:'Error',message:'currentInvoiceId is required!'}); 
      } 
      if(req.query.senderEmail=='' || req.query.senderEmail==undefined  ){
        req.query.senderEmail="";
      }
      var obj = objeInvoice.getNextInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  

 router.put('/updateInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try { 
    
      if(req.body.invoiceId=='' ||req.body.invoiceId==undefined || req.body.invoiceId <=0){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'});
      } 

      if(req.body.dueAmount==0){
        req.body.dueAmount="";
      } 
      
      req.body.dueDate=objCommon.checkDate(req.body.dueDate || "" );
      req.body.dueAmount=objCommon.checkDecimal(req.body.dueAmount || "");
      req.body.invoiceDate=objCommon.checkDate(req.body.invoiceDate || "");
      req.body.invoiceAmount=objCommon.checkDecimal(req.body.invoiceAmount || "");
      req.body.taxTotal=objCommon.checkDecimal(req.body.taxTotal || "" );
  
      var obj = objeInvoice.updateInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });  
  

router.post('/createInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  

      var obj = objeInvoice.createInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });  
  
  router.get('/getInvoiceList',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        
      var obj = objeInvoice.getInvoiceList(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 

  router.post('/createInvoiceLine',jwtAuth.VerifyToken, function(req, res,next) {
    try {  

      req.body.action="Add";
      var obj = objeInvoice.saveInvoiceLine(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });  
  
  router.put('/updateInvoiceLine',jwtAuth.VerifyToken, function(req, res,next) {
    try {  

      req.body.action="Edit";
      var obj = objeInvoice.saveInvoiceLine(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  });  

  
router.delete('/deleteInvoiceLine',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.query.invoiceLineId=='' || req.query.invoiceLineId==undefined || req.query.invoicinvoiceLineIdeId<=0 ){
            return res.status(403).json({status:'Error',message:'invoiceLineId is required!'}); 
        } 
       
      var obj = objeInvoice.deleteInvoiceLine(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 

  
router.get('/getInvoiceLine',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
    if( req.query.invoiceId<=0 ){
      req.query.invoiceId=0;
    }
    if( req.query.invoiceLineId<=0 ){
      req.query.invoiceLineId=0;
    } 
    var obj = objeInvoice.getInvoiceLine(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 


router.post('/lockInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
       
      if(req.body.invoiceId=='' ||req.body.invoiceId==undefined || req.body.invoiceId<=0 ){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'});
      }

      if(req.body.lockedBy=='' ||req.body.lockedBy==undefined || req.body.lockedBy<=0 ){
        return res.status(403).json({status:'Error',message:'lockedBy is required!'});
      }
      
      var obj = objeInvoice.lockInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') { 
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result); 
          }
        },
        function (err) { 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
router.delete('/unLockInvoice',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
        if(req.query.invoiceId=='' || req.query.invoiceId==undefined || req.query.invoiceId<=0 ){
            return res.status(403).json({status:'Error',message:'invoiceId is required!'}); 
        } 
        if(req.query.lockedBy=='' || req.query.lockedBy==undefined || req.query.lockedBy<=0 ){
          return res.status(403).json({status:'Error',message:'lockedBy is required!'}); 
      } 
       
      var obj = objeInvoice.unLockInvoice(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
  
router.get('/getInvoiceFieldList',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId<=0 ){
        req.query.teamId=0;
      } 
      var obj = objeInvoice.getInvoiceFieldList(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 

  router.post('/saveInvoiceFieldList',jwtAuth.VerifyToken, function(req, res,next) {
    try {  

      if(req.body.teamId=='' ||req.body.teamId==undefined || req.body.teamId<=0 ){
        return res.status(403).json({status:'Error',message:'teamId is required!'});
      }
      if(req.body.fieldList=='' || req.body.fieldList==undefined ){
        return res.status(403).json({status:'Error',message:'fieldList is required!'});
      }
      var obj = objeInvoice.saveInvoiceFieldList(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 


  router.get('/getAudits',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
      if(req.query.invoiceId=='' || req.query.invoiceId==undefined || req.query.invoiceId<= 0 ){
        return res.status(403).json({status:'Error',message:'invoiceId is required!'}); 
    }  
      var obj = objeInvoice.getAudits(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 


  router.post('/saveSettings',jwtAuth.VerifyToken, function(req, res,next) {
    try {  
     
      if(req.body.teamId=='' ||req.body.teamId==undefined || req.body.teamId<=0 ){
        return res.status(403).json({status:'Error',message:'teamId is required!'});
      } 
      var obj = objeInvoice.saveSettings(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') { 
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);  
          }
        },
        function (err) { 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse); 
    } 
  }); 
  

router.get('/getSettings',jwtAuth.VerifyToken, function(req, res,next) {
    try {    
      if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId <= 0   ){
        return res.status(403).json({status:'Error',message:'teamId is required!'});
      }
       
      var obj = objeInvoice.getSettings(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            return res.status(200).json(result);
          }
        },
        function (err) { 
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
  
    } catch (ex) {
       var jsonResponse = { status: 'Error', message: ex.message };
      return res.status(500).json(jsonResponse);
    } 
  }); 
 
function approvedInvoiceEmail(req,res) {
    try {
      var filepath = __dirname + '//views//invoiceapproved.html';
      filepath = filepath.replace('controller', '');
      filepath = path.normalize(filepath);
      fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
        if (err) {
          var result = { status: 'Error', message: err.message };
          logger.error("Method Name: approvedInvoiceEmail, Error: "+err.message); 
          return (result);
        } else {
          var template = handlebars.compile(html);
          var replacements = {
            invoiceNumber: req.body.invoiceNumber,
            customerCompanyName: req.body.customerCompanyName,
            loginURL: objConfig.adminUrl 
          };
        
          var htmlToSend = template(replacements);
          var objSendEmail = objCommon.sendEmail(objConfig.fromEmail, req.body.sendEmail, req.body.subject, htmlToSend);
          objSendEmail.then(
            function (result) {
              if (result.status === 'Error') {
                logger.error("Method Name: approvedInvoiceEmail, Error: "+result); 
                return (result);
              } else {
                return (result);
              }
            },
            function (err) {
              var result = { status: 'Error', message: err.message }; 
              logger.error("Method Name: approvedInvoiceEmail, Error: "+err.message); 
              return (result);
            }
          );
  
  
        }
      });
  
    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message };
      logger.error("Method Name: approvedInvoiceEmail, Error: "+ex.message); 
      return (result);
    }
  
    
  
  }
  

module.exports = router;