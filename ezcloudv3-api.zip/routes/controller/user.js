
/**
* @swagger 

* /user/login:
*   post:
*     tags:
*       - user
*     name: user
*     summary: login user
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             password:
*               type: string
 
*         required:
*           - email
*           - password

*     responses:
*       200:
*         description: Login successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
 
* /user/createSuperAdmin:
*   post:
*     tags:
*       - user
*     name: user
*     summary: create a new super admin
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             lastName:
*               type: string
*             email:
*               type: string
*             password:
*               type: string
*             phoneNumber:
*               type: string
*             countryCode:
*               type: string
*             profileLogo:
*               type: string 
*             createdBy:
*               type: integer 

*         required:
*           - email
*           - password

*     responses:
*       200:
*         description: User saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/customerRegistration:
*   post:
*     tags:
*       - user
*     name: user
*     summary: create a new free customer
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             lastName:
*               type: string
*             email:
*               type: string
*             password:
*               type: string
*             phoneNumber:
*               type: string
*             countryCode:
*               type: string
*             profileLogo:
*               type: string 
*             approvalAmountFrom:
*               type: number
*               format: float
*             approvalAmountTo:
*               type: number
*               format: float
*             invoiceSenderEmail:
*               type: string
*             companyLogo:
*               type: string
*             companyName:
*               type: string
*             planId:
*               type: integer
*             userType:
*               type: string


*         required:
*           - email
*           - password
*           - approvalAmountFrom
*           - approvalAmountTo
*           - invoiceSenderEmail

*     responses:
*       200:
*         description: User saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /user/createCustomer:
*   post:
*     tags:
*       - user
*     name: user
*     summary: create a new premium customer 
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             email:
*               type: string
*             invoiceSenderEmail:
*               type: string
*             expiryDate:
*               type: string
*             createdBy:
*               type: integer

*         required:
*           - email
*           - invoiceSenderEmail
*           - expiryDate
*     responses:
*       200:
*         description: User saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /user/createTeamUser:
*   post:
*     tags:
*       - user
*     name: user
*     summary: create a new team member
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             lastName:
*               type: string
*             email:
*               type: string
*             password:
*               type: string
*             phoneNumber:
*               type: string
*             countryCode:
*               type: string
*             createdBy:
*               type: integer
*             profileLogo:
*               type: string 
*             approvalAmountFrom:
*               type: number
*               format: float
*             approvalAmountTo:
*               type: number
*               format: float

*         required:
*           - email
*           - password
*           - approvalAmountFrom
*           - approvalAmountTo

*     responses:
*       200:
*         description: User saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/updateUser:
*   put:
*     tags:
*       - user
*     name: user
*     summary: update a existing user
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             firstName:
*               type: string
*             lastName:
*               type: string
*             phoneNumber:
*               type: string
*             countryCode:
*               type: string
*             profileLogo:
*               type: string 
*             approvalAmountFrom:
*               type: number
*               format: float
*             approvalAmountTo:
*               type: number
*               format: float

*         required:
*           - approvalAmountFrom
*           - approvalAmountTo
*           - userId

*     responses:
*       200:
*         description: User saved successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

 * /user/getUsers:
 *   get:
 *     tags:
 *       - user
 *     name: user
 *     summary: Get list of all users
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: teamId
 *         type: integer
 *       - in: query
 *         name: email
 *         type: string 
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: companyName
 *         type: string 
 *       - in: query
 *         name: firstName
 *         type: string 
 *       - in: query
 *         name: lastName
 *         type: string 
 *       - in: query
 *         name: userRole
 *         type: string 
 *       - in: query
 *         name: isActive
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.

 * /user/getUserById:
 *   get:
 *     tags:
 *       - user
 *     name: user
 *     summary: Get single user object
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: integer
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 * 
 * /user/deleteUser:
 *   delete:
 *     tags:
 *       - user
 *     name: user
 *     summary: delete a user
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: integer
 *         required: true
 *       - in: query
 *         name: isActive
 *         type: integer
 *         required: true
 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 
 
* /user/updatePassword:
*   put:
*     tags:
*       - user
*     name: user
*     summary: update a existing user password
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             oldPassword:
*               type: string
*             newPassword:
*               type: string

*         required:
*           - email
*           - oldPassword
*           - newPassword

*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/forGetPassword:
*   put:
*     tags:
*       - user
*     name: user
*     summary: Send password to registered email.
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
 

*         required:
*           - email 

*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/verifyCustomerEmail:
*   put:
*     tags:
*       - user
*     name: user
*     summary: To activate a open registered customer.
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             hashKey:
*               type: string

*         required:
*           - email
*           - hashKey
*           - newPassword

*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/verifyOTP:
*   put:
*     tags:
*       - user
*     name: user
*     summary: To verify the otp.
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             otpType:
*               type: string
*             otpValue:
*               type: string
*             otpTo:
*               type: string
*             countryCode:
*               type: string

*         required:
*           - otpType
*           - otpValue
*           - otpTo
*           - countryCode

*     responses:
*       200:
*         description: OTP verified successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/generateOTP:
*   post:
*     tags:
*       - user
*     name: user
*     summary: To generate the otp.
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             otpType:
*               type: string
*             otpTo:
*               type: string
*             countryCode:
*               type: string

*         required:
*           - otpType
*           - otpTo
*           - countryCode
*     responses:
*       200:
*         description: OTP generated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/forGetPasswordForPhone:
*   put:
*     tags:
*       - user
*     name: user
*     summary: Send password to registered phone.
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             phoneNumber:
*               type: string
*             countryCode:
*               type: string
 

*         required:
*           - phoneNumber 
*           - countryCode

*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/signOut:
*   put:
*     tags:
*       - user
*     name: user
*     summary: To signout the current login account
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer

 

*         required:
*           - userId 

*     responses:
*       200:
*         description: Logout account successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

* /user/getEntityUser:
 *   get:
 *     tags:
 *       - user
 *     name: user
 *     summary: Get list of all users based on entity type
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: email
 *         type: string 
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: entityType
 *         type: string 
 *       - in: query
 *         name: teamId
 *         type: integer 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.

* /user/checkIsNewSupplier:
 *   get:
 *     tags:
 *       - user
 *     name: user
 *     summary: Get user status
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: email
 *         type: string 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
*/

var express = require('express');
const router = express.Router();
var jwt = require('jsonwebtoken');
var jwtAuth=require('../dao/jwt');
const config = require('../appconfig/config');
const objCommon=require('../dao/common');
const objUser=require('../dao/user');

router.post('/login', function(req, res,next) {
    try {
        
      if(req.body.email=='' ||req.body.email==undefined ){
        return res.status(403).json({status:'Error',message:'Email is required!'});
      }
      if(req.body.password=='' ||req.body.password==undefined ){
        return res.status(403).json({status:'Error',message:'Password is required!'});
      }  
      req.body.password=objCommon.encryptString(req.body.password);
 
      var obj = objUser.login(req, res, next);
      obj.then(
        function (result) {
          if (result.status === 'Error') {
            return res.status(403).json(result);
          }
          else {
            var token = jwt.sign(
              { 
                role: result.data.userRole,
                userId: result.data.userId,
                iat: Math.floor(Date.now() / 1000)
              },
              config.JWTSecretKey,
              { expiresIn: '24h' }
            );
          
            return res
              .set({ accesstoken: objCommon.encryptString(token) })
              .header('Access-Control-Expose-Headers', 'accesstoken')
              .status(200)
              .json(result);
            
          }
        },
        function (err) {
          var result = { status: 'Error', message: err.message };
          return res.status(500).json(result);
        }
      );
    } catch (ex) {
       var result = { status: 'Error', message: ex.message };
      return res.status(500).json(result);
    } 
    }); 

 router.post('/createSuperAdmin',jwtAuth.VerifyToken, function(req, res,next) {
      try { 
     
        if(req.body.email=='' ||req.body.email==undefined ){
          return res.status(403).json({status:'Error',message:'Email is required!'});
        }
        if(req.body.password=='' ||req.body.password==undefined ){
          return res.status(403).json({status:'Error',message:'Password is required!'});
        } 
        if(req.body.createdBy=='' ||req.body.createdBy==undefined || req.body.createdBy<=0 ){
          return res.status(403).json({status:'Error',message:'CreatedBy is required!'});
        } 
         if(req.body.firstName=='' ||req.body.firstName==undefined ){
          return res.status(403).json({status:'Error',message:'FirstName is required!'});
        } 
      
        req.body.originalPassword=req.body.password;
        req.body.action="Add";
        req.body.userId=0;
        req.body.userRole="Super Admin"
        req.body.password=objCommon.encryptString(req.body.password);
        req.body.isDefaultPassword=true;
        req.body.isEmailVerified=true;
        req.body.hashKey=null;
        var obj = objUser.saveUser(req, res, next);
        obj.then(
          function (result) {
            if (result.status === 'Error') {
              return res.status(403).json(result);
            }
            else {
              return res.status(200).json(result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message };
            return res.status(500).json(result);
          }
        );
    
      } catch (ex) {
         var jsonResponse = { status: 'Error', message: ex.message };
        return res.status(500).json(jsonResponse);
      } 
    });  

router.post('/customerRegistration', function(req, res,next) {
      try { 
     
        if(req.body.email=='' || req.body.email==undefined ){
          return res.status(403).json({status:'Error',message:'Email is required!'});
        }
        if(req.body.password=='' || req.body.password==undefined ){
          return res.status(403).json({status:'Error',message:'Password is required!'});
        }  
         
        if(req.body.firstName=='' || req.body.firstName==undefined ){
          return res.status(403).json({status:'Error',message:'FirstName is required!'});
        }  
        if(req.body.invoiceSenderEmail=='' || req.body.invoiceSenderEmail==undefined ){
          return res.status(403).json({status:'Error',message:'invoiceSenderEmail is required!'});
        } 
        if(req.body.userType=='' || req.body.userType==undefined ){
          return res.status(403).json({status:'Error',message:'userType is required!'});
        }  
        if (req.body.userType=="Supplier"){
          req.body.userRole="Supplier";
          req.body.entityType="Supplier"; 
          req.body.isEmailVerified=false;
          req.body.hashKey=objCommon.encryptString(objCommon.generatePassword());;
        
        }
        else{
          req.body.userRole="Admin";
          req.body.entityType="Customer";
          req.body.isEmailVerified=false;
          req.body.hashKey=objCommon.encryptString(objCommon.generatePassword());
        }
        req.body.originalPassword=req.body.password;
        req.body.action="Add";
        req.body.userId=0; 
        req.body.teamType="Open Registration";
        req.body.createdBy=null;
        req.body.isDefaultPassword=false;
        req.body.password=objCommon.encryptString(req.body.password);
        req.body.expiryDate=null;

        var obj = objUser.saveUser(req, res, next);
        obj.then(
          function (result) {
            if (result.status === 'Error') {
              return res.status(403).json(result);
            }
            else {
              return res.status(200).json(result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message };
            return res.status(500).json(result);
          }
        );
    
      } catch (ex) {
         var jsonResponse = { status: 'Error', message: ex.message };
        return res.status(500).json(jsonResponse);
      } 
    });  
 
    
router.post('/createCustomer' ,jwtAuth.VerifyToken, function(req, res,next) {
  try { 
    
    const userAccessToken = req.headers.authorization;
    var decoded = jwt.verify(
      objCommon.decryptString(userAccessToken),
      config.JWTSecretKey
    );

    if(decoded.role !="Super Admin"){
      var result = { status: 'Error', message: 'Invalid request' };
      return res.status(401).json(result);
    }

    if(req.body.email=='' ||req.body.email==undefined ){
      return res.status(403).json({status:'Error',message:'Email is required!'});
    } 
    if(req.body.firstName=='' ||req.body.firstName==undefined ){
      return res.status(403).json({status:'Error',message:'FirstName is required!'});
    } 

    if(req.body.invoiceSenderEmail=='' ||req.body.invoiceSenderEmail==undefined ){
      return res.status(403).json({status:'Error',message:'invoiceSenderEmail is required!'});
    } 
    if(req.body.createdBy=='' || req.body.createdBy==undefined || req.body.createdBy<=0  ){
      return res.status(403).json({status:'Error',message:'createdBy is required!'});
    }
    req.body.originalPassword=objCommon.generatePassword();
    req.body.action="Add";
    req.body.userId=0;
    req.body.userRole="Admin"
    req.body.teamType="Created By Admin";
    req.body.isDefaultPassword=true;
    req.body.password=objCommon.encryptString(req.body.originalPassword);
    req.body.isEmailVerified=true;
    req.body.hashKey=null;
    req.body.entityType="Customer";
    req.body.planId=2; 
    var obj = objUser.saveUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  
 
router.post('/createTeamUser',jwtAuth.VerifyToken, function(req, res,next) {
  try { 
 
    if(req.body.email=='' ||req.body.email==undefined ){
      return res.status(403).json({status:'Error',message:'Email is required!'});
    }
    if(req.body.password=='' ||req.body.password==undefined ){
      return res.status(403).json({status:'Error',message:'Password is required!'});
    } 
    if(req.body.createdBy=='' ||req.body.createdBy==undefined || req.body.createdBy<=0 ){
      return res.status(403).json({status:'Error',message:'CreatedBy is required!'});
    } 
    // if(req.body.approvalAmountFrom=='' ||req.body.approvalAmountFrom==undefined ){
    //   return res.status(403).json({status:'Error',message:'ApprovalAmountFrom is required!'});
    // } 
     req.body.approvalAmountFrom=0;
    // if(req.body.approvalAmountTo=='' ||req.body.approvalAmountTo==undefined  ){
    //   return res.status(403).json({status:'Error',message:'ApprovalAmountTo is required!'});
    // }
    if(req.body.firstName=='' ||req.body.firstName==undefined ){
      return res.status(403).json({status:'Error',message:'FirstName is required!'});
    } 
    req.body.originalPassword=req.body.password;
    req.body.action="Add";
    req.body.userId=0;
    req.body.userRole="Team Member"
    req.body.invoiceSenderEmail="";
    req.body.isDefaultPassword=true;
    req.body.isEmailVerified=true;
    req.body.password=objCommon.encryptString(req.body.password);
    req.body.hashKey=null;
    var obj = objUser.saveUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  
 

router.put('/updateUser',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
    if(req.body.userId=='' ||req.body.userId==undefined || req.body.userId<=0 ){
      return res.status(403).json({status:'Error',message:'userId is required!'});
    }
    req.body.action="Edit"; 
    var obj = objUser.saveUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 
  
router.get('/getUsers',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
    if(req.query.teamId=='' || req.query.teamId==undefined  ){
      req.query.teamId=0;
    }
    if(req.query.email=='' || req.query.email==undefined  ){
      req.query.search="";
    } 
    if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
      req.query.count=10;
    } 
    if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
      req.query.offset=0;
    }  
    if(req.query.firstName=='' || req.query.firstName==undefined  ){
      req.query.firstName="";
    } 
    if(req.query.lastName=='' || req.query.lastName==undefined  ){
      req.query.lastName="";
    } 
    if(req.query.companyName=='' || req.query.companyName==undefined  ){
      req.query.companyName="";
    } 

    if(req.query.userRole=='' || req.query.userRole==undefined  ){
      req.query.userRole="";
    } 
    if(req.query.isActive=='' || req.query.isActive==undefined  ){
      req.query.isActive="";
    } 
     
    var obj = objUser.getUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 

router.get('/getUserById',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
    if(req.query.userId=='' || req.query.userId==undefined  ){
      return res.status(403).json({status:'Error',message:'userId is required!'});
    } 
      req.query.search="";
   req.query.createdBy=req.query.userId;
    var obj = objUser.getUserById(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 

router.delete('/deleteUser',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
    if(req.query.userId=='' || req.query.userId==undefined  ){
      return res.status(403).json({status:'Error',message:'userId is required!'});
    } 
    if(req.query.isActive=='' || req.query.isActive==undefined  ){
      return res.status(403).json({status:'Error',message:'isActive is required!'});
    } 
     
    var obj = objUser.deleteUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  

router.put('/updatePassword',jwtAuth.VerifyToken, function(req, res,next) {
  try { 
 
    if(req.body.email=='' ||req.body.email==undefined ){
      return res.status(403).json({status:'Error',message:'Email is required!'});
    }
    if(req.body.oldPassword=='' ||req.body.oldPassword==undefined ){
      return res.status(403).json({status:'Error',message:'OldPassword is required!'});
    } 
   
    if(req.body.newPassword=='' ||req.body.newPassword==undefined ){
      return res.status(403).json({status:'Error',message:'NewPassword is required!'});
    }  
    req.body.oldOriginalPassword=req.body.oldPassword;
    req.body.newOriginalPassword=req.body.newPassword;
    
    req.body.oldPassword=objCommon.encryptString(req.body.oldPassword);
    req.body.newPassword=objCommon.encryptString(req.body.newPassword);
 
    var obj = objUser.updatePassword(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  

router.put('/forGetPassword',function(req, res,next) {
  try { 
 
    if(req.body.email=='' ||req.body.email==undefined ){
      return res.status(403).json({status:'Error',message:'Email is required!'});
    }
    var newPassword=objCommon.generatePassword();
    req.body.password=objCommon.encryptString(newPassword); 
    req.body.newPassword=newPassword;
 
    var obj = objUser.forGetPassword(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          var result = { status: 'Success', message: 'Sent password to registered email.' };
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  


router.put('/verifyCustomerEmail', function(req, res,next) {
  try { 
 
    if(req.body.email=='' ||req.body.email==undefined ){
      return res.status(403).json({status:'Error',message:'Email is required!'});
    }
    if(req.body.hashKey=='' ||req.body.hashKey==undefined ){
      return res.status(403).json({status:'Error',message:'hashKey is required!'});
    } 
   
    var obj = objUser.verifyCustomerEmail(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  

router.post('/generateOTP', function(req, res,next) {
  try {  
    if(req.body.otpType=='' ||req.body.otpType==undefined ){
      return res.status(403).json({status:'Error',message:'otpType is required!'});
    } 
   
    if(req.body.otpTo=='' ||req.body.otpTo==undefined ){
      return res.status(403).json({status:'Error',message:'otpTo is required!'});
    }  
    if(req.body.countryCode=='' ||req.body.countryCode==undefined ){
      return res.status(403).json({status:'Error',message:'countryCode is required!'});
    }  
    
     
 req.body.otpValue=objCommon.generateOTP();
    var obj = objUser.generateOTP(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});

router.put('/verifyOTP',  function(req, res,next) {
  try {  
    if(req.body.otpType=='' ||req.body.otpType==undefined ){
      return res.status(403).json({status:'Error',message:'otpType is required!'});
    }
    if(req.body.otpValue=='' ||req.body.otpValue==undefined ){
      return res.status(403).json({status:'Error',message:'otpValue is required!'});
    } 
   
    if(req.body.otpTo=='' ||req.body.otpTo==undefined ){
      return res.status(403).json({status:'Error',message:'otpTo is required!'});
    }  
    if(req.body.countryCode=='' ||req.body.countryCode==undefined ){
      return res.status(403).json({status:'Error',message:'countryCode is required!'});
    }  
     
    
 
    var obj = objUser.verifyOTP(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 


router.put('/forGetPasswordForPhone',function(req, res,next) {
  try { 
 
    if(req.body.phoneNumber=='' ||req.body.phoneNumber==undefined ){
      return res.status(403).json({status:'Error',message:'phoneNumber is required!'});
    }
    if(req.body.countryCode=='' ||req.body.countryCode==undefined ){
      return res.status(403).json({status:'Error',message:'countryCode is required!'});
    }
    var newPassword=objCommon.generatePassword();
    req.body.password=objCommon.encryptString(newPassword); 
    req.body.newPassword=newPassword;
 
    var obj = objUser.forGetPasswordForPhone(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          var result = { status: 'Success', message: 'Sent password to registered phone number.' };
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});  

router.put('/signOut',jwtAuth.VerifyToken, function(req, res,next) {
  try { 
 
    if(req.body.userId <=0 ){
      return res.status(403).json({status:'Error',message:'userId is required!'});
    }
 
    var obj = objUser.signOut(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 

router.get('/getEntityUser',jwtAuth.VerifyToken, function(req, res,next) {
  try {  
   
    if(req.query.teamId=='' || req.query.teamId==undefined || req.query.teamId <=0 ){
      return res.status(403).json({status:'Error',message:'teamId is required!'});
    }
    if(req.query.email=='' || req.query.email==undefined  ){
      req.query.search="";
    } 
    if(req.query.count=='' || req.query.count==undefined || req.query.count<=0 ){
      req.query.count=10;
    } 
    if(req.query.offset=='' || req.query.offset==undefined || req.query.offset<=0 ){
      req.query.offset=0;
    }  
    if(req.query.entityType=='' || req.query.entityType==undefined  ){
      req.query.entityType="";
    } 
     
    var obj = objUser.getEntityUser(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
}); 


router.get('/checkIsNewSupplier', function(req, res,next) {
  try {   
    if(req.query.email=='' || req.query.email==undefined  ){
      return res.status(403).json({status:'Error',message:'email is required!'});
    } 
      
    var obj = objUser.checkIsNewSupplier(req, res, next);
    obj.then(
      function (result) {
        if (result.status === 'Error') {
          return res.status(403).json(result);
        }
        else {
          return res.status(200).json(result);
        }
      },
      function (err) {
        var result = { status: 'Error', message: err.message };
        return res.status(500).json(result);
      }
    );

  } catch (ex) {
     var jsonResponse = { status: 'Error', message: ex.message };
    return res.status(500).json(jsonResponse);
  } 
});


module.exports = router;