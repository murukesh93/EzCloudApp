var express = require('express');
var http = require('http');
var path = require('path');
var app = express();
var cors = require('cors');
var bodyparser = require('body-parser');
var swaggerUi = require('swagger-ui-express');
var swaggerJSDoc = require('swagger-jsdoc');
var methodOverride = require('method-override'); 


const swaggerDefinition = {
  info: {
    title: 'ezCloud V3',
    version: '1.0.0',
    description: 'Endpoints to test the user registration routes'
  },

 //live
  // host:'apiv3.ezcloud.co',
  //host: 'localhost:3002',
  //dev
 host:'dev-api-v3.ezcloud123.io',
  basePath: '/',
  securityDefinitions: {
    bearerAuth: {
      type: 'apiKey',
      name: 'authorization',
      scheme: 'bearer',
      in: 'header',
    },
  },

};

const options = {
  swaggerDefinition,
  apis: ['./routes/controller/*.js']
};

var user = require('./routes/controller/user');
var invoice = require('./routes/controller/invoice');
var team=require('./routes/controller/team');
var uploadFile=require('./routes/controller/uploadFile');
var dashboard=require('./routes/controller/dashboard');
var supplier=require('./routes/controller/supplier');
var report=require('./routes/controller/report');
var comment=require('./routes/controller/comment');

app.use(cors());
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());
app.use(methodOverride()); 
app.use(express.static(path.join(__dirname, 'public')));


app.use('/user', user);
app.use('/invoice',invoice);
app.use('/team',team);
app.use('/uploadFile',uploadFile);
app.use('/dashboard',dashboard);
app.use('/supplier',supplier);
app.use('/report',report);
app.use('/comment',comment);

const swaggerSpec = swaggerJSDoc(options);
app.get('/swagger.json', function(req, res) {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
}); 

app.use('/', swaggerUi.serve, swaggerUi.setup(swaggerSpec)); 

app.get('/', (req, res) => {
  res.send('404-Page Not Found');
});

app.use((req, res, next) => {
  const err = new Error('Not Found');
  err.status = 404;
  next(err);
});

//all other requests are not implemented.
app.use((err, req, res) => {
  res.status(err.status || 501);
  res.json({
    error: {
      code: err.status || 501,
      message: err.message
    }
  });
});

module.exports = app;

const port = process.env.port || 3002;

//Create server with exported express app
const server = http.createServer(app);
server.listen(port);

